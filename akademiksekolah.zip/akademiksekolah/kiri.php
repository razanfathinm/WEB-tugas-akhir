<?php
if ($_GET['module']=='home'){
		echo '<div class=weteng>
				
					<h3>Berita Terbaru</h3><br/>
					';


					$dataPerPage = 5;  //jumlah perhalam bro
					if(isset($_GET['hal']))
					{ 
					  $noPage = $_GET['hal'];
					}else{  
					  $noPage = 1;
					}
					$offset   = ($noPage - 1) * $dataPerPage;
					$terkini=mysql_query("SELECT * FROM berita where id_kategori = 11127 order by id_berita desc limit $offset, $dataPerPage");
					$hitung_record = mysql_query("SELECT COUNT(*) AS jumData FROM berita where id_kategori = 11127");
					$data          = mysql_fetch_array($hitung_record);
					$jumData       = $data['jumData'];
					$jumPage  = ceil($jumData/$dataPerPage);

					
						while($t=mysql_fetch_array($terkini)){

						echo "<img src='gambar_berita/$t[foto_berita]' 
						width=100 hspace=5 align=left style='padding:15px;'> ";
						echo "<h3 style='padding:5px;'> $t[jdl_berita] </h3>";
						echo "<p style='text-align:justify;'>";
						echo substr($t['isi_berita'], 0, 200);
						echo "</p>";
						echo "<p> <a href='baca_view.php?link=bacatampil.php&id=$t[id_berita]'>Baca Selengkapnya</a> 
							        </p>";
						echo "<hr>";
						}

						echo "
						    <div class='pagination pagination-centered'>
						    <ul>";

						    $link = "media.php?module=home&hal=";
						    # menampilkan link previous
						    if ($noPage > 1) echo  "<li><a href='".$link."".($noPage-1)."'>&larr; Prev</a></li>";
						    # memunculkan nomor halaman dan linknya
						    for($jml_hal = 1; $jml_hal <= $jumPage; $jml_hal++)
						    {
						      if($noPage == $jml_hal){
						        echo "<li class='disabled'><a href='#' style='cursor'>".$jml_hal."</a></li> ";
						      }else{
						        echo "<li><a href='".$link."".$jml_hal."'>".$jml_hal."</a></li> ";}
						    }
						    # menampilkan link next
						    if ($noPage < $jumPage) echo "<li><a href='".$link."".($noPage+1)."'>Next &rarr;</a></li>";
						echo "
						</ul>
						</div>
						";
						echo '
				</div> <!-- END Left Column -->	

				<div class=weteng_right>
					<h3>Info Sekolah</h3> <br>
						';
					$info= mysql_query("SELECT * FROM berita where id_kategori = 11130
						order by id_berita desc limit 10");
						while($r=mysql_fetch_array($info)){
						echo " <a href='baca_view.php?link=bacatampil.php&id=$r[id_berita]'><h4> $r[jdl_berita] </h4></a> 
							        ";
						echo "<hr>";
						}
						echo '
					<a style=float:right; href="info">Arsip Info</a>
				</div>

					';  
}elseif ($_GET['module']=='jurusan'){
		echo '<div id="latest">
			
					<h3>JURUSAN SMKN 2 TEBO</h3><br/>
					';

					$dataPerPage = 5;  //jumlah perhalam bro
					if(isset($_GET['hal']))
					{ 
					  $noPage = $_GET['hal'];
					}else{  
					  $noPage = 1;
					}
					$offset   = ($noPage - 1) * $dataPerPage;
					$terkini=mysql_query("SELECT * FROM berita where id_kategori = 11128 order by id_berita desc limit $offset, $dataPerPage");
					$hitung_record = mysql_query("SELECT COUNT(*) AS jumData FROM berita");
					$data          = mysql_fetch_array($hitung_record);
					$jumData       = $data['jumData'];
					$jumPage  = ceil($jumData/$dataPerPage);

					
						while($t=mysql_fetch_array($terkini)){

						echo "<img src='gambar_berita/$t[foto_berita]' 
						width=100 hspace=5 align=left style='padding:15px;'> ";
						echo "<h3 style='padding:5px;'> $t[jdl_berita] </h3>";
						echo "<p style='text-align:justify;'>";
						echo substr($t['isi_berita'], 0, 430);
						echo "</p>";
						echo "<p> <a href='baca_view.php?link=bacatampil.php&id=$t[id_berita]'>Baca Selengkapnya</a> 
							        </p>";
						echo "<hr>";
						}

						echo "
						    <div class='pagination pagination-centered'>
						    <ul>";

						    $link = "media.php?module=jurusan&hal=";
						    # menampilkan link previous
						    if ($noPage > 1) echo  "<li><a href='".$link."".($noPage-1)."'>&larr; Prev</a></li>";
						    # memunculkan nomor halaman dan linknya
						    for($jml_hal = 1; $jml_hal <= $jumPage; $jml_hal++)
						    {
						      if($noPage == $jml_hal){
						        echo "<li class='disabled'><a href='#' style='cursor'>".$jml_hal."</a></li> ";
						      }else{
						        echo "<li><a href='".$link."".$jml_hal."'>".$jml_hal."</a></li> ";}
						    }
						    # menampilkan link next
						    if ($noPage < $jumPage) echo "<li><a href='".$link."".($noPage+1)."'>Next &rarr;</a></li>";
						echo "
						</ul>
						</div>
						
			</div>";  
}elseif ($_GET['module']=='kegiatan'){
		echo '<div id="latest">
			
					<h3>KEGIATAN SMKN 2 TEBO</h3><br/>
					';


					$dataPerPage = 5;  //jumlah perhalam bro
					if(isset($_GET['hal']))
					{ 
					  $noPage = $_GET['hal'];
					}else{  
					  $noPage = 1;
					}
					$offset   = ($noPage - 1) * $dataPerPage;
					$terkini=mysql_query("SELECT * FROM berita where id_kategori = 11129 order by id_berita desc limit $offset, $dataPerPage");
					$hitung_record = mysql_query("SELECT COUNT(*) AS jumData FROM berita");
					$data          = mysql_fetch_array($hitung_record);
					$jumData       = $data['jumData'];
					$jumPage  = ceil($jumData/$dataPerPage);

					
						while($t=mysql_fetch_array($terkini)){

						echo "<img src='gambar_berita/$t[foto_berita]' 
						width=100 hspace=5 align=left style='padding:15px;'> ";
						echo "<h3 style='padding:5px;'> $t[jdl_berita] </h3>";
						echo "<p style='text-align:justify;'>";
						echo substr($t['isi_berita'], 0, 430);
						echo "</p>";
						echo "<p> <a href='baca_view.php?link=bacatampil.php&id=$t[id_berita]'>Baca Selengkapnya</a> 
							        </p>";
						echo "<hr>";
						}

						echo "
						    <div class='pagination pagination-centered'>
						    <ul>";

						    $link = "media.php?module=kegiatan&hal=";
						    # menampilkan link previous
						    if ($noPage > 1) echo  "<li><a href='".$link."".($noPage-1)."'>&larr; Prev</a></li>";
						    # memunculkan nomor halaman dan linknya
						    for($jml_hal = 1; $jml_hal <= $jumPage; $jml_hal++)
						    {
						      if($noPage == $jml_hal){
						        echo "<li class='disabled'><a href='#' style='cursor'>".$jml_hal."</a></li> ";
						      }else{
						        echo "<li><a href='".$link."".$jml_hal."'>".$jml_hal."</a></li> ";}
						    }
						    # menampilkan link next
						    if ($noPage < $jumPage) echo "<li><a href='".$link."".($noPage+1)."'>Next &rarr;</a></li>";
						echo "
						</ul>
						</div>
						
			</div>";  
}elseif ($_GET['module']=='info'){
		echo '<div id="latest">
			
					<h3>INFO SMKN 2 TEBO</h3><br/>
					';


					$dataPerPage = 5;  //jumlah perhalam bro
					if(isset($_GET['hal']))
					{ 
					  $noPage = $_GET['hal'];
					}else{  
					  $noPage = 1;
					}
					$offset   = ($noPage - 1) * $dataPerPage;
					$terkini=mysql_query("SELECT * FROM berita where id_kategori = 11130 order by id_berita desc limit $offset, $dataPerPage");
					$hitung_record = mysql_query("SELECT COUNT(*) AS jumData FROM berita");
					$data          = mysql_fetch_array($hitung_record);
					$jumData       = $data['jumData'];
					$jumPage  = ceil($jumData/$dataPerPage);

					
						while($t=mysql_fetch_array($terkini)){

						echo "<h3 style='padding:5px;'> $t[jdl_berita] </h3>";
						echo "<p style='text-align:justify;'>";
						echo substr($t['isi_berita'], 0, 180);
						echo "</p>";
						echo "<p> <a href='baca_view.php?link=bacatampil.php&id=$t[id_berita]'>Baca Selengkapnya</a> 
							        </p>";
						echo "<hr>";
						}

						echo "
						    <div class='pagination pagination-centered'>
						    <ul>";

						    $link = "media.php?module=kegiatan&hal=";
						    # menampilkan link previous
						    if ($noPage > 1) echo  "<li><a href='".$link."".($noPage-1)."'>&larr; Prev</a></li>";
						    # memunculkan nomor halaman dan linknya
						    for($jml_hal = 1; $jml_hal <= $jumPage; $jml_hal++)
						    {
						      if($noPage == $jml_hal){
						        echo "<li class='disabled'><a href='#' style='cursor'>".$jml_hal."</a></li> ";
						      }else{
						        echo "<li><a href='".$link."".$jml_hal."'>".$jml_hal."</a></li> ";}
						    }
						    # menampilkan link next
						    if ($noPage < $jumPage) echo "<li><a href='".$link."".($noPage+1)."'>Next &rarr;</a></li>";
						echo "
						</ul>
						</div>
						
			</div>";  
}elseif ($_GET['module']=='guru'){ 
                	echo "<div id=latest>";
					echo "<h3>DAFTAR GURU SMKN 2 TEBO</h3><br/>
				          
				        <table border=1 width=100% cellpadding=3 cellspacing=0>
							<tr class=top_tr>
								<td width=30px>No</td>
								<td width=50>PHOTO</td>
								<td width=250>NIP</td>
								<td>NAMA</td>
								<td>JABATAN</td>
								<td align='center' width='100px;'>Action</td>
							</tr>"; 

			                   $dataPerPage = 10;  //jumlah perhalam bro
				if(isset($_GET['hal']))
				{ 
				  $noPage = $_GET['hal'];
				}else{  
				  $noPage = 1;
				}
				$offset   = ($noPage - 1) * $dataPerPage;

				$tampil=mysql_query("SELECT * FROM karyawan ORDER BY nm_karyawan asc limit $offset, $dataPerPage");
				$hitung_record = mysql_query("SELECT COUNT(*) AS jumData FROM berita");
				$data          = mysql_fetch_array($hitung_record);
				$jumData       = $data['jumData'];
				$jumPage  = ceil($jumData/$dataPerPage);

				    $no=1;
				    while($data = mysql_fetch_array($tampil)){
                            if(($no % 2)==0){
								$warna="#ffffff";
							  }
							  else{
								$warna="#E1E1E1";
							  }
					       echo "<tr bgcolor=$warna>
					       			<td>$no</td>
					       			<td class=teng><img class=photo src='foto_karyawan/$data[foto_karyawan]'></td>
									<td>$data[nip]</td>
									<td>$data[nm_karyawan]</td>
									<td>$data[jabatan]</td>
									<td><a href=baca_view.php?link=bacaguru.php&id=$data[id_karyawan]>Detail Guru</a></td>
								</tr>";
				      $no++;
				    }
				    echo "</table>";
				    echo "</div>";
				    echo "
				    <div class='pagination pagination-centered'>
				    <ul>";

				    $link = "media.php?module=guru&hal=";
				    # menampilkan link previous
				    if ($noPage > 1) echo  "<li><a href='".$link."".($noPage-1)."'>&larr; Prev</a></li>";
				    # memunculkan nomor halaman dan linknya
				    for($jml_hal = 1; $jml_hal <= $jumPage; $jml_hal++)
				    {
				      if($noPage == $jml_hal){
				        echo "<li class='disabled'><a href='#' style='cursor'>".$jml_hal."</a></li> ";
				      }else{
				        echo "<li><a href='".$link."".$jml_hal."'>".$jml_hal."</a></li> ";}
				    }
				    # menampilkan link next
				    if ($noPage < $jumPage) echo "<li><a href='".$link."".($noPage+1)."'>Next &rarr;</a></li>";
				echo "
				</ul>
				</div>
				";

}elseif ($_GET['module']=='learning'){ 
                	echo "<div id=latest>";
					echo "<h3>DAFTAR E-Learning SMKN 2 TEBO</h3><br/>

				          <table border=1 width=100% cellpadding=3 cellspacing=0>
							<tr class=top_tr>
								<td width=30px>No</td>
								<td>NAMA</td>
								<td align='center' width='130px;'>Action</td>
							</tr>"; 

				$dataPerPage = 10;  //jumlah perhalam bro
				if(isset($_GET['hal']))
				{ 
				  $noPage = $_GET['hal'];
				}else{  
				  $noPage = 1;
				}
				$offset   = ($noPage - 1) * $dataPerPage;

				$tampil=mysql_query("SELECT * FROM learning ORDER BY nm_learning asc limit $offset, $dataPerPage");
				$hitung_record = mysql_query("SELECT COUNT(*) AS jumData FROM berita");
				$data          = mysql_fetch_array($hitung_record);
				$jumData       = $data['jumData'];
				$jumPage  = ceil($jumData/$dataPerPage);

				    $no=1;
				    while($data = mysql_fetch_assoc($tampil)){
				    	if (empty($_SESSION['namauser'])) {
				    		 echo "<script> 
                              onload = function(){
                              	alert('Login Dulu ya!');
                              }</script>\n";
				    	}else{
                        $file = 'file_learning/'.$data['file_learning'].'';
                        }
					       echo "<tr>
					       			<td>$no</td>
									<td>$data[nm_learning]</td>
									<td><a href='$file'>Download File</a></td>
								</tr>";
				      $no++;
				    }
				    echo "</table>";
				    echo "</div>";
				    echo "
				    <div class='pagination pagination-centered'>
				    <ul>";

				    $link = "media.php?module=guru&hal=";
				    # menampilkan link previous
				    if ($noPage > 1) echo  "<li><a href='".$link."".($noPage-1)."'>&larr; Prev</a></li>";
				    # memunculkan nomor halaman dan linknya
				    for($jml_hal = 1; $jml_hal <= $jumPage; $jml_hal++)
				    {
				      if($noPage == $jml_hal){
				        echo "<li class='disabled'><a href='#' style='cursor'>".$jml_hal."</a></li> ";
				      }else{
				        echo "<li><a href='".$link."".$jml_hal."'>".$jml_hal."</a></li> ";}
				    }
				    # menampilkan link next
				    if ($noPage < $jumPage) echo "<li><a href='".$link."".($noPage+1)."'>Next &rarr;</a></li>";
				echo "
				</ul>
				</div>
				";
}elseif ($_GET['module']=='learning_guru'){ 
                	echo "<div id=latest>";
					echo "<h3>DAFTAR E-Learning SMKN 2 TEBO</h3><br/>

				          <table border=1 width=100% cellpadding=3 cellspacing=0>
							<tr class=top_tr>
								<td width=30px>No</td>
								<td>NAMA</td>
								<td align='center' width='130px;'>Action</td>
							</tr>"; 

				$dataPerPage = 10;  //jumlah perhalam bro
				if(isset($_GET['hal']))
				{ 
				  $noPage = $_GET['hal'];
				}else{  
				  $noPage = 1;
				}
				$offset   = ($noPage - 1) * $dataPerPage;

				$tampil=mysql_query("SELECT * from karyawan b
                            join learning a
                            on b.id_karyawan = a.id_karyawan
                            where a.id_karyawan = $_GET[id] ORDER BY nm_learning desc limit $offset, $dataPerPage");
				$hitung_record = mysql_query("SELECT COUNT(*) AS jumData FROM berita");
				$data          = mysql_fetch_array($hitung_record);
				$jumData       = $data['jumData'];
				$jumPage  = ceil($jumData/$dataPerPage);

				    $no=1;
				    while($data = mysql_fetch_assoc($tampil)){
				    	if (empty($_SESSION['namauser'])) {
				    		 echo "<script> 
                              onload = function(){
                              	alert('Login Dulu ya!');
                              }</script>\n";
				    	}else{
                        $file = 'file_learning/'.$data['file_learning'].'';
                        }
					       echo "<tr>
					       			<td>$no</td>
									<td>$data[nm_learning]</td>
									<td><a href='$file'>Download File</a></td>
								</tr>";
				      $no++;
				    }
				    echo "</table>";
				    echo "</div>";
				    echo "
				    <div class='pagination pagination-centered'>
				    <ul>";

				    $link = "media.php?module=guru&hal=";
				    # menampilkan link previous
				    if ($noPage > 1) echo  "<li><a href='".$link."".($noPage-1)."'>&larr; Prev</a></li>";
				    # memunculkan nomor halaman dan linknya
				    for($jml_hal = 1; $jml_hal <= $jumPage; $jml_hal++)
				    {
				      if($noPage == $jml_hal){
				        echo "<li class='disabled'><a href='#' style='cursor'>".$jml_hal."</a></li> ";
				      }else{
				        echo "<li><a href='".$link."".$jml_hal."'>".$jml_hal."</a></li> ";}
				    }
				    # menampilkan link next
				    if ($noPage < $jumPage) echo "<li><a href='".$link."".($noPage+1)."'>Next &rarr;</a></li>";
				echo "
				</ul>
				</div>
				";
}
?>