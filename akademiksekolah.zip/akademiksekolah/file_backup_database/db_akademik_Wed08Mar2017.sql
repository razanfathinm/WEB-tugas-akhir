DROP TABLE IF EXISTS alumni;

CREATE TABLE `alumni` (
  `id_alumni` int(10) NOT NULL AUTO_INCREMENT,
  `nisn_alumni` varchar(10) NOT NULL,
  `nm_alumni` varchar(30) NOT NULL,
  `foto_alumni` varchar(250) DEFAULT NULL,
  `kelamin_alumni` char(1) DEFAULT NULL,
  `email_alumni` varchar(100) DEFAULT NULL,
  `no_telp_alumni` varchar(13) DEFAULT NULL,
  `tmplhr_alumni` varchar(50) DEFAULT NULL,
  `tgllhr_alumni` date DEFAULT NULL,
  `agama_alumni` varchar(20) DEFAULT NULL,
  `alamat_alumni` text,
  `status_alumni` varchar(50) DEFAULT NULL,
  `keterangan_alumni` text,
  PRIMARY KEY (`id_alumni`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO alumni VALUES("33","3456345643","sdghsd","","L","adisus10@gmail.com","56745656","","2004-01-08","0","asfga","0","");
INSERT INTO alumni VALUES("34","7845674567","fgsdhfgsh","","L","","","","1900-01-01","0","","0","");
INSERT INTO alumni VALUES("35","4356345634","gdhsd","","P","asdf@fgsf.com","4356345","w23e423","2005-03-03","Islam","afhasdg","Kuliah","asdf");
INSERT INTO alumni VALUES("36","5464567346","Adi Susanto","about-logolock.png","P","adisus10@gmail.com","98456","asdfas","2006-03-14","Islam","asdgasdg","Kerja","ashgsadg");
INSERT INTO alumni VALUES("37","1111111111","afsasd","","L","","","","0000-00-00","0","","0","");



DROP TABLE IF EXISTS berita;

CREATE TABLE `berita` (
  `id_berita` int(5) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(5) NOT NULL,
  `jdl_berita` varchar(50) NOT NULL,
  `penulis` varchar(30) DEFAULT NULL,
  `tgl_berita` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `foto_berita` varchar(250) NOT NULL,
  `isi_berita` text,
  PRIMARY KEY (`id_berita`),
  KEY `id_kategori` (`id_kategori`)
) ENGINE=MyISAM AUTO_INCREMENT=11160 DEFAULT CHARSET=latin1;

INSERT INTO berita VALUES("11153","11129","Marching Band","admin345","2017-01-22 06:18:46","KJIKJI.jpg","Dimulai pada tanggal 02 Mei awal perdana SMKN2 Tebo menampilkan marching band . 2mei? Iya hari pendidikan adalah hari dimana team GPM.DRUM COORPS SMKN2 TEBO baru saja launching pertama kali,melatih mental tampil sederhana mungkin dan seadanya mungkin karena team kami baru saja dibentuk tanggal 15 Febuari 2016 dan 3bulan setelah menjalankan latihan setiap hari rabu dan sabtu kami harus tampil di hari pendidikan.\n\nTanggal 17 Agustus? Kami hanya bisa menguji mental kami di penurunan bendera , Tanggal 18 Agustus? Kami mencoba uji mental di Kabupaten Tebo, tampil pertama kali di depan bupati beserta ibu, memakai costum baru,menunjukan inilah team baru kami, inilah team kami yang ada di SMKN2 Kab.Tebo\n\n20 agustus? Kami mengikuti pawai di Rimbo Bujang,memakai costum baru,dan berusaha tampil semaksimal mungkin dan sebagus mungkin,hanya 1 pikiran kami di team \"TIDAK AKAN BIKIN MALU NAMA SEKOLAH\"\n\n Pada acara karnaval memperingati hari kemerdekaan tepat nya pada tanggal 20 Agustus 2016 SMKN 2 TEBO  berhasil merebutkan juara pertama tingkat kecamatan . tentu saja itu membuat Kami dan  semua masyarakat yang ada di SMKN 2 TEBOmerasa bangga. Semangat terusss... ");
INSERT INTO berita VALUES("11152","11130","Ayo Magang Ke Jepang!","admin","2017-01-22 06:03:04","camera.png"," Magang Jepang adalah suatu program belajar sambil praktek kerja yang di lakukan bagi para lulusan SMK sederajat di Negara  Jepang. Program ini dilaksanakan oleh kerjasama antara Pemerintah Republik Indonesia dengan Pemerintah Jepang yang disebut dengan Program IM JAPAN  yang di selenggarakan oleh Disosnakertrans  propinsi di seluruh Indonesia. Program pemagangan ini pun dilaksanakan oleh Perusahaan-perusahaan dan atau LPK (Lembaga Pelatihan Kerja) swasta yang sudah mendapatkan izin dari Kementerian RI Bidang Lattas Pemagangan, dalam hal ini LPK KANTANNA SAKURA yang personil  kepengurusannya  adalah alumni Japan dan beberapa pendidik di SMK N 2 Kab.Tebo Siap memberangkatkan para alumnus SMK  untuk ikut magang. Perusahaan ataupun  LPK yang bisa mengirimkan Pemagang Ke Jepang biasa di sebut dengan Sending Organization (SO). Dan di Indonesia ini selain Dinsosnakertrans RI ada juga sekitar 92 Sending Organization (SO) yang bisa mendidik dan mengirimkan  anda ke Jepang Sebagai Pemagang (Trainee) \n\nPERSYARATAN  DAN PROSEDUR PROGRAM MAGANG JEPANG\n\n• PERSYARATAN UMUM CALON TRAINEE JAPAN\n\n1. USIA ANTARA 19-27 TAHUN,\n\nUsia produktif menurut perusahaan jepang adalah antara 20-27 tahun, akan tetapi kesempatan untuk ke jepang sudah bisa di raih dari umur 18 tahun, dan bagi umur 30 tahun ke atas pada dasarnya masih ada kesempatan untuk magang ke jepang,  tetapi  mungkin agak kecil kesempatan tersebut, karena sebagian besar perusahaan jepang biasanya lebih cenderung mengambil yang usianya masih muda. Maka bagi teman-teman yang merasa usianya masih produktif alangkah baiknya tidak menyia-nyiakan kesempatan yang ada. Dan bagi yang usianya lebih pun tetap ada kesempatan.\n\n2. FISIK JASMANI/KESEMAPTAAN/KESEHATAN\n\nUntuk mengikuti program magang ke Jepang , fisik yang sempurna adalah syarat mutlak yang harus di miliki oleh calon pemagang. Badan anda adalah aset yang sangat besar yang bisa membuat anda mendapatkan hasil yang cukup besar. Maka jagalah dan sayangilah badan anda yang bagus dan sempurna itu. Jangan sampai karena kecerobohan-kecerobohan yang di lakukan membuat anda merusak fisik anda menjadi cacat yang akhirnya akan menjadikan penyesalan yang tiada arti. Masa muda memang terkadang adalah masa yang labil, dimana di situ faktor lingkungan menjadi penentu sikap anda, maka pandai-pandailah menyikapi keadaan sehingga dalam lingkungan seperti apapun anda harus menjadi yang terbaik dan bisa menjaga diri.\n\nContoh kecilnya adalah : tatto dan tindik..\n\nKarena Dalam syarat menjadi pemagang Jepang tatto dan tindik tidaklah di perbolehkan, maka sayangilah badan anda,,,Selanjutnya di samping fisik yang kuat dan sempurna, yang tidak kalah pentingnya adalah kesehatan. Dalam program magang  jepang tidak mungkin mau menerima orang yang sakit baik jasmani maupun rohani, terutama adalah penyakit yang menular.  Karena dalam program ini di bagian medical cek up nya akan sangat teliti. Jadi sebisa mungkin jagalah kesehatan anda. Janganlah mengkonsumsi makanan atau minuman atau obat-obatan yang anda sendiri sudah tau kalau itu tidak baik dan malah akan merusak. Bahkan akan menimbulkan penyakit, contoh seperti narkoba, minuman keras dll. Jadi intinya, sayangilah diri anda untuk menggapai masa depan yang cerah…\n\n \n\n3. DOKUMEN PRIBADI HARUS LENGKAP\n\n• Ijazah Minimal SMK Sederajat/Kejar Paket C\n\n• Dokumen pribadi seperti KTP, KK, AKTE, IJAZAH dan dokumen yang lain harus sama dalam penulisan Nama, Tanggal Lahir, Dan Tempat Lahir. Tidak boleh ada perbedaan baik huruf atau pun angka di dalam dokumen tersebut, karena dokumen tersebut adalah dasar yang di pakai untuk pengurusan Pasport, Visa, Dan Dokument Yang Lain untuk syarat ke Jepang. Jadi harus benar-benar fix dan tidak boleh ada kesalahan. Maka bagi temen-teman yang ingin magang ke Jepang, dari sekarang silahkan cek seluruh Dokumen pribadi anda dan pastikan  semua singkron dan tidak ada kesalahan.\n\n• PROSEDUR UMUM MAGANG KE JEPANG\n\n1. SELEKSI AWAL MELIPUTI  :\n\n• Seleksi Administrasi (Dokument Pribadi)\n\nSetelah mendaftarkan diri , yang pertama di perhatikan adalah kelengkapan dokument pribadi  anda seperti yg telah di jelaskan di atas, semua dokumen  pribadi anda harus lengkap dan singkron satu sama lain, seperti KTP, KK, AKTE, IJAZAH dll.\n\n•  Pemeriksaan Kesemaptaan Tubuh\n\nMeliputi pemeriksaan FISIK yang meliputi Tinggi Badan, Berat Badan, Cacat Tubuh, Fungsi Organ Tubuh. Di sinilah anda akan merasa bahwa tubuh anda adalah aset yang sangat berharga, maka sayangilah dan peliharalah dengan baik.\n\n• Test Bahasa Jepang Dasar\n\nDi sinilah fungsi LPK KANTANNA SAKURA akan terasa karena untuk mengikuti seleksi Program Magang Jepang  paling tidak siswa harus sudah mengetahui dasar dari bahasa jepang dan kebudayaan jepang.\n\n• Test Psiko Dan Matematika\n\nTugas LPK KANTANNA SAKURA bukan hanya mengajari bahasa jepang saja tapi termasuk semua hal yang berkaitan dengan Program Magang Jepang , dan di LPK KANTANNA SAKURA yang ada di SMKN 2 Tebo semua di ajarkan termasuk psikotest dan matematika.\n\n• Wawancara Dengan User Dari Jepang\n\nNah.. seleksi yang ini lumayan harus memerlukan persiapan yang prima untuk menghadapinya, karena di sini bisa jadi adalah penentu keberhasilan anda. Pihak perusahaan penerima dari jepang akan langsung memilih anda sebagai pemagang di Perusahaanya,  oleh karena itu anda harus benar-benar maksimal di hadapan mereka. Dan itupun akan kita latih selama di LPK supaya tidak terlalu nerves dalam melaksanakan seleksi di tahap ini.  Semangat….\n\n• Kesehatan (Medical Ceck Up)\n\nIni adalah test terakhir dan penentu keberhasilan anda, mau sebagus apapun hasil test sebelumnya,  kalau di medicalnya jelek pasti akan gagal, karena tidak mungkin pihak perusahaan pengirim(sending organisasi) akan mengirimkan orang yang sakit untuk sampai ke Jepang. Karena sangat beresiko, maka jagalah kesehatan anda dari sekarang…\n\nContok penyakit yang sulit untuk di tolerir biasanya penyakit yang menular seperti : Hepatitis, tbc, aids dan penyakit menular yang lain….\n\n2. MASA PENDIDIKAN PRA PEMBERANGKATAN KE JEPANG\n\nSetelah semua seleksi terlewati dan hasilnya adalah ok/lolos.., maka tahap berikutnya ada masa pendidikan pra-pemberangkatan di daerah (untuk program IM JAPAN) ataupun di Perusahaan Pengirim ke Jepang (sending organisasi). Di sini adalah masa pemantapan bahasa Jepang dan sikap anda. Jadi jangan senang dulu setelah lolos seleksi awal, karena di masa ini kemampuan anda benar-benar di pertaruhkan. Dan sikap anda juga benar-benar di perhatikan. Kalau di masa ini anda tidak  bisa mengikuti pendidikan bahasa Jepang dengan baik ataupun sikap anda di anggap jelek maka konsekwensinya adalah bisa di cancel  ataupun di pulangkan kembali ke tahap awal. Maka harus tetap hati-hati dan semangat dalam belajar dan harus menjaga sikap sebaik mungkin dan meminimalisasi kesalahan .\n\n3. TERBANG KE JEPANG\n\nInilah masa yang paling indah dan masa paling di tunggu tentunya “terbang ke negeri sakura”, wah.. semua calon pemagang jepang pasti mendambakan masa ini ya..  Tapi ingat, jangan senang dulu. di sini adalah babak awal  anda untuk meraih masa depan yang bagus, tetapi di balik itu ternyata anda punya tanggung jawab yang sangat besar di sini, yaitu untuk menjaga nama baik lembaga yang mendidik anda, perusahaan yang memberangkatkan anda dan tentunya menjaga nama baik negara tercinta kita ini. Maka tetaplah santun dan jaga ketenangan ya..  tunjukkan bahwa negara kita adalah negara yang santun dan berwibawa… semangat. Ganbatte minna san.....(Sβ) ");
INSERT INTO berita VALUES("11150","11127","Diklat Moda Daring Online","admin345","2017-01-22 06:15:36","diklat.png","Berdasarkan hasil rapat koordinasi dengan Dinas Pendidikan Bidang PPTK hari Kamis, 25 Agustus 2016 perihal Guru Pembelajar, berkaitan dengan hal tersebut maka kami beritahukan sebagai berikut :\n \n1. Kepada para Guru yang Nilai Merah 1 – 5 mengikuti Diklat Moda Daring (Online ), Nilai Merah 6 – 7 mengikuti Diklat Model Campuran (Moda Daring dan Tatap Muka ).\n3. Berkenaan dengan ini maka masing-masing guru untuk mempersiapkan diri dengan berlatih TIK ( Teknologi\n4. Informasi Komputer ) dan Mempersiapkan perangkat TIK yaitu PC/Laptop yang ada web camnya, atau Smart Phone Android/ios (front Camera) yang bisa digunakan untuk model streaming atau video call serta jaringan pendukungnya.\n5. Diklat ini rencananya di laksanakan tanggal 7 September 2016.\n6. Jadwal akan tertera pada akun GPO nya masing-masing PTK atau Guru setelah login (belum punya akun? silahkan klik disini untuk membuat akun GP).\n7. Mengingat waktu yang sudah mendesak mohon setiap PTK untuk segera berlatih login akunnya masing-masing dan pastikan setiap PTK sudah memegang akun GPO nya sendiri-sendiri apabila belum memiliki akun segera menghubungi koordinator Gugusnya masing-masing. Bila Koordinator Gugus/KKG mengalami kesulitan bisa konsultasi langsung ke UPTD.\n8. Kepada Guru yang Nilainya Merah 8-10 akan mengikuti diklat Tatap Muka penuh (jadwal menyusul) ");
INSERT INTO berita VALUES("11151","11127","Gebyar TIK 2016","admin345","2017-01-22 06:01:15","Gebyar TIK 2016.jpg","Gebyar TIK diselenggarakan sebagai bentuk apresiasi dan penghargaan kepada Sekolah dan Guru SD/MI, SMP/MTs, SMA/MA/SMK yang berdedikasi memajukan pendidikan di Kabupaten Tebo pada khususnya dan di Provinsi Jambi pada umumnya dengan mengembangkan dan memanfaatkan TIK untuk pendidikan pada pendidikan dasar dan menengah. Adapun gelar Gebyar TIK yang pada puncak final di selenggarakan di Provinsi Jambi mulai pada tanggal 5 s.d. 8 September 2016 ini bertujuan untuk mengaplikasikan Teknologi TIK dalam bidang Pendidikan, wadah kreatifitas dan unjuk potensi TIK Guru/Sekolah se-Provinsi Jambi, mendorong dan meningkatkan pengembangan dan pemanfaatan TIK di Sekolah, serta menumbuhkan kesadaran pendayagunaan teknologi yang tepat-guna.\n\nUntuk seleksi calon peserta lomba ini diselenggarakan di Dinas Dikbudpora Kabupaten Tebo yang mana akan dipilih 17 (tujuh belas) orang yang terdiri dari guru dan peserta didik terbaik yang akan dikirimkan untuk mengikuti final Gebyar TIK Jambi tahun 2016 yang terbagi dalam beberapa kategori lomba sebagai berikut:\n1. Blog Guru Guru SD-SMA (1 peserta)\n2. Blog Siswa Siswa SMA Sederajat (1 peserta)\n3. Media Animasi Guru SD-SMA (1 peserta)\n4.  Media Presentasi Guru SD-SMA (1 peserta)\n5. Media Video Guru SD-SMA (1 peserta)\n6. Media Mobile Edukasi Guru SD-SMA (1 peserta)\n7. Web SD SD (1 peserta)\n8. Web SMP SMP (1 peserta)\n9. Web SMA SMA (1 peserta)\n10. Kuis Kihajar SD Siswa SD Sederajat (1 peserta)\n11. Kuis Kihajar SMP Siswa SMP / Sederajat (1 peserta)\n12. Kuis Kihajar SMA Siswa SMA / Sederajat (1 peserta)\n13. Film Pendek Guru Guru SD-SMA (2 peserta dalam 1 kelompok)\n14. Film Pendek Siswa Siswa SMA / Sederajat (2 peserta dalam 1 kelompok)\n15. Seminar - Guru TIK SMA/SMK (1 peserta)\n \nUntuk download surat edaran Dinas Dikbudpora Tebo serta formulir pendaftaran danpetunjuk teknis seleksi Gebyar TIK Kabupaten Tebo Tahun 2016 dapat diunduh pada Menu E-Learning. Formulir pendaftaran yang telah diisi lengkap dan telah ditandatangani oleh Kepala Sekolah serta bahan lomba disampaikan kepada Panitia Seleksi Gebyar TIK Kabupaten Tebo Tahun 2016, Bidang Dikmen Dinas Dikbudpora Tebo (Bpk. Guruh Puji Raharjo, S.Pd) diterima paling lambat sampai dengan hari Kamis, 31 Agustus 2016. Demikian informasi yang kami sampaikan atas perhatiannya diucapkan terimakasih.");



DROP TABLE IF EXISTS detail_kelas;

CREATE TABLE `detail_kelas` (
  `id_kelas` int(5) DEFAULT NULL,
  `id_siswa` int(10) DEFAULT NULL,
  KEY `id_kelas` (`id_kelas`),
  KEY `id_siswa` (`id_siswa`),
  CONSTRAINT `detail_kelas_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_kelas_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO detail_kelas VALUES("5","12");
INSERT INTO detail_kelas VALUES("5","31");



DROP TABLE IF EXISTS detail_mapel;

CREATE TABLE `detail_mapel` (
  `id_karyawan` int(5) DEFAULT NULL,
  `id_mapel` int(5) DEFAULT NULL,
  KEY `id_karyawan` (`id_karyawan`),
  KEY `id_mapel` (`id_mapel`),
  CONSTRAINT `detail_mapel_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_mapel_ibfk_2` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO detail_mapel VALUES("8","11");
INSERT INTO detail_mapel VALUES("9","16");



DROP TABLE IF EXISTS jadwal;

CREATE TABLE `jadwal` (
  `id_jadwal` int(5) NOT NULL AUTO_INCREMENT,
  `id_karyawan` int(5) DEFAULT NULL,
  `id_kelas` int(5) DEFAULT NULL,
  `id_mapel` int(5) DEFAULT NULL,
  `hari` varchar(20) DEFAULT NULL,
  `jam` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_jadwal`),
  KEY `id_karyawan` (`id_karyawan`),
  KEY `id_kelas` (`id_kelas`),
  KEY `id_mapel` (`id_mapel`),
  CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jadwal_ibfk_2` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jadwal_ibfk_3` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

INSERT INTO jadwal VALUES("39","8","6","11","Selasa","07:00 - 08:00 ");
INSERT INTO jadwal VALUES("40","8","6","18","Rabu","07:00 - 08:00 ");
INSERT INTO jadwal VALUES("41","9","6","16","Kamis","11:05 - 13:05 ");
INSERT INTO jadwal VALUES("42","9","5","16","Senin","07:00 - 08:00 ");
INSERT INTO jadwal VALUES("45","8","5","11","Senin","08:00 - 10:00 ");



DROP TABLE IF EXISTS jurusan;

CREATE TABLE `jurusan` (
  `id_jurusan` int(5) NOT NULL AUTO_INCREMENT,
  `nm_jurusan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jurusan`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO jurusan VALUES("2","Multimedia");
INSERT INTO jurusan VALUES("3","Akutansi");
INSERT INTO jurusan VALUES("6","Administrasi Perkantoran");
INSERT INTO jurusan VALUES("7","Teknik Mesin");
INSERT INTO jurusan VALUES("8","Teknik Sepeda Motor");
INSERT INTO jurusan VALUES("9","Teknik Kendaraan Ringan");



DROP TABLE IF EXISTS karyawan;

CREATE TABLE `karyawan` (
  `id_karyawan` int(5) NOT NULL AUTO_INCREMENT,
  `nip` varchar(20) DEFAULT NULL,
  `nm_karyawan` varchar(30) DEFAULT NULL,
  `foto_karyawan` varchar(250) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `jabatan` varchar(150) NOT NULL,
  `email_karyawan` varchar(100) DEFAULT NULL,
  `no_telp_karyawan` varchar(13) DEFAULT NULL,
  `agama_karyawan` varchar(30) DEFAULT NULL,
  `pend_karyawan` varchar(100) DEFAULT NULL,
  `jenis_kel_karyawan` char(1) DEFAULT NULL,
  `tmp_lhr_karyawan` varchar(50) DEFAULT NULL,
  `tgl_lhr_karyawan` date DEFAULT NULL,
  `alamat_karyawan` text,
  `pass_karyawan` varchar(8) NOT NULL,
  PRIMARY KEY (`id_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO karyawan VALUES("8","31246235757342354215","Jhon Susanto","adi.jpg","guru","Wali Kelas","adisus10@gmail.com","082372394930","Islam","S1 Teknik Matematika","P","Medan","1990-10-17","Condongcatur medan surakarta","dadanice");
INSERT INTO karyawan VALUES("9","34563456456345643564","Santoso","dokter-1.jpg","guru","Guru Biasa","ari@gmail.com","0831243255","Islam","","P","","1900-01-01","","45643564");
INSERT INTO karyawan VALUES("10","67854673456234513123","Tuti Ira Wati","","tu","","tuti@ymail.com","081232","0","","P","","1900-01-01","","34513123");
INSERT INTO karyawan VALUES("12","11111111111111111111","afsd","","0","","","","0","","L","","0000-00-00","","11111111");



DROP TABLE IF EXISTS kategori;

CREATE TABLE `kategori` (
  `id_kategori` int(5) NOT NULL AUTO_INCREMENT,
  `nm_kategori` varchar(30) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM AUTO_INCREMENT=11136 DEFAULT CHARSET=latin1;

INSERT INTO kategori VALUES("11127","berita");
INSERT INTO kategori VALUES("11128","jurusan");
INSERT INTO kategori VALUES("11129","kegiatan");
INSERT INTO kategori VALUES("11130","info sekolah");



DROP TABLE IF EXISTS kelas;

CREATE TABLE `kelas` (
  `id_kelas` int(5) NOT NULL AUTO_INCREMENT,
  `nm_kelas` varchar(50) NOT NULL,
  `id_jurusan` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_kelas`),
  KEY `id_jurusan` (`id_jurusan`),
  CONSTRAINT `kelas_ibfk_1` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO kelas VALUES("5","X Akutansi 1","3");
INSERT INTO kelas VALUES("6","X Multimedia 2","2");
INSERT INTO kelas VALUES("7","X Akutansi 2","3");
INSERT INTO kelas VALUES("11","XI Akutansi 1","3");
INSERT INTO kelas VALUES("12","XII Akutansi 1","3");



DROP TABLE IF EXISTS khs;

CREATE TABLE `khs` (
  `id_khs` int(10) NOT NULL AUTO_INCREMENT,
  `id_mapel` int(5) DEFAULT NULL,
  `id_jurusan` int(5) DEFAULT NULL,
  `id_siswa` int(10) DEFAULT NULL,
  `id_kelas` int(5) DEFAULT NULL,
  `semester` varchar(10) DEFAULT NULL,
  `thn_ajaran` varchar(10) DEFAULT NULL,
  `nilai` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id_khs`),
  KEY `id_mapel` (`id_mapel`),
  KEY `id_jurusan` (`id_jurusan`),
  KEY `id_siswa` (`id_siswa`),
  KEY `id_kelas` (`id_kelas`),
  CONSTRAINT `khs_ibfk_1` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `khs_ibfk_2` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `khs_ibfk_3` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `khs_ibfk_4` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO khs VALUES("8","11","3","12","5","genap","2011-2012","89");
INSERT INTO khs VALUES("9","15","3","12","5","genap","2011-2012","80");
INSERT INTO khs VALUES("10","16","3","31","5","ganjil","2012-2013","90");
INSERT INTO khs VALUES("11","16","3","31","5","ganjil","2011-2012","20");



DROP TABLE IF EXISTS learning;

CREATE TABLE `learning` (
  `id_learning` int(10) NOT NULL AUTO_INCREMENT,
  `nm_learning` varchar(50) DEFAULT NULL,
  `file_learning` varchar(250) DEFAULT NULL,
  `id_karyawan` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_learning`),
  KEY `id_karyawan` (`id_karyawan`),
  CONSTRAINT `learning_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO learning VALUES("3","bahasa itu indah","krs.pdf","8");
INSERT INTO learning VALUES("4","Corel Draw Itu Keren","aji scan.pdf","8");



DROP TABLE IF EXISTS mapel;

CREATE TABLE `mapel` (
  `id_mapel` int(5) NOT NULL AUTO_INCREMENT,
  `nm_mapel` varchar(50) NOT NULL,
  PRIMARY KEY (`id_mapel`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO mapel VALUES("11","Matematika");
INSERT INTO mapel VALUES("15","Bahasa Indonesia");
INSERT INTO mapel VALUES("16","Design Grafis");
INSERT INTO mapel VALUES("17","IPS");
INSERT INTO mapel VALUES("18","Bahasa Inggris");
INSERT INTO mapel VALUES("22","IPA");



DROP TABLE IF EXISTS pendaftaran;

CREATE TABLE `pendaftaran` (
  `id_pendaftaran` int(10) NOT NULL AUTO_INCREMENT,
  `nm_pendaftaran` varchar(30) DEFAULT NULL,
  `nisn_pendaftaran` varchar(10) DEFAULT NULL,
  `foto_pendaftaran` varchar(250) DEFAULT NULL,
  `no_ijazah` varchar(20) DEFAULT NULL,
  `no_skhu` varchar(20) DEFAULT NULL,
  `no_ujian` varchar(20) DEFAULT NULL,
  `jk_pendaftaran` char(1) DEFAULT NULL,
  `tl_pendafataran` varchar(50) DEFAULT NULL,
  `tt_pendafataran` date DEFAULT NULL,
  `agama_pendaftaran` varchar(20) DEFAULT NULL,
  `telp_pendaftaran` varchar(13) DEFAULT NULL,
  `email_pendaftaran` varchar(100) DEFAULT NULL,
  `trans_pendaftaran` varchar(50) DEFAULT NULL,
  `tinggi_pendaftaran` varchar(3) DEFAULT NULL,
  `berat_pendaftaran` varchar(3) DEFAULT NULL,
  `jml_saudara` varchar(2) DEFAULT NULL,
  `alamat_pendaftaran` text,
  `nm_ayah_pendftaran` varchar(30) DEFAULT NULL,
  `pekerjaan_ayah_pendaftaran` varchar(50) DEFAULT NULL,
  `penghasilan_ayah_pendaftaran` varchar(10) DEFAULT NULL,
  `nm_ibu_pendftaran` varchar(30) DEFAULT NULL,
  `pekerjaan_ibu_pendaftaran` varchar(50) DEFAULT NULL,
  `nm_wali_pendftaran` varchar(30) DEFAULT NULL,
  `pekerjaan_wali_pendaftaran` varchar(50) DEFAULT NULL,
  `penghasilan_wali_pendaftaran` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_pendaftaran`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS siswa;

CREATE TABLE `siswa` (
  `id_siswa` int(10) NOT NULL AUTO_INCREMENT,
  `nisn_siswa` varchar(10) DEFAULT NULL,
  `nm_siswa` varchar(30) DEFAULT NULL,
  `foto_siswa` varchar(250) NOT NULL,
  `jenis_kelamin` char(1) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `tempat_lhr` varchar(50) DEFAULT NULL,
  `agama` varchar(20) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `hobby` varchar(30) DEFAULT NULL,
  `ket_hobi` text NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `alamat` text,
  `transportasi` varchar(30) DEFAULT NULL,
  `gol_darah` char(1) DEFAULT NULL,
  `tinggi` int(3) DEFAULT NULL,
  `berat` int(3) DEFAULT NULL,
  `anak_ke` char(2) DEFAULT NULL,
  `nm_ayah` varchar(30) DEFAULT NULL,
  `tgl_lhr_ayah` date DEFAULT NULL,
  `tmp_lhr_ayah` varchar(20) NOT NULL,
  `agama_ayah` varchar(20) DEFAULT NULL,
  `pendidikan_ayah` varchar(50) DEFAULT NULL,
  `pekerjaan_ayah` varchar(50) DEFAULT NULL,
  `penghasilan_ayah` varchar(20) DEFAULT NULL,
  `alamat_ayah` text,
  `status_hidup_ayah` varchar(20) DEFAULT NULL,
  `no_telp_ayah` varchar(13) DEFAULT NULL,
  `nm_ibu` varchar(30) DEFAULT NULL,
  `tgl_lhr_ibu` date DEFAULT NULL,
  `tmp_lhr_ibu` varchar(50) DEFAULT NULL,
  `agama_ibu` varchar(20) DEFAULT NULL,
  `pendidikan_ibu` varchar(50) DEFAULT NULL,
  `pekerjaan_ibu` varchar(50) DEFAULT NULL,
  `penghasilan_ibu` varchar(20) DEFAULT NULL,
  `alamat_ibu` text NOT NULL,
  `nm_wali` varchar(30) DEFAULT NULL,
  `tgl_lhr_wali` date DEFAULT NULL,
  `tmp_lhr_wali` varchar(100) DEFAULT NULL,
  `agama_wali` varchar(20) DEFAULT NULL,
  `pendidikan_wali` varchar(50) DEFAULT NULL,
  `pekerjaan_wali` varchar(50) DEFAULT NULL,
  `penghasilan_wali` varchar(20) DEFAULT NULL,
  `alamat_wali` text,
  `no_telp_wali` varchar(13) DEFAULT NULL,
  `pass_siswa` varchar(8) NOT NULL,
  `status_siswa` varchar(10) NOT NULL,
  PRIMARY KEY (`id_siswa`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO siswa VALUES("12","3456673567","Adi Susanto","adi.jpg","L","1997-01-01","dhjdf","Islam","3462","Kesenian","sdgfsd","adisus10@gmail.com","sdhsdhdf","sdfhg","A","123","232","3","dfshsd","2002-02-07","sdfh","Islam","sarjanbna","asfg","Rp. 2.333","sdfhsdf","Hidup","34542","","0000-00-00","","selected","","","Rp. 333.333","","sdfsdfg","2001-02-01","asdfas","Islam","sarjana","asfga","Rp. 4.354","dsfhgsdg","23452322","dada345","aktif");
INSERT INTO siswa VALUES("31","1111111111","Ridwan Mas","dokter.jpg","P","1998-11-11","Medan","Islam","081231231321","Kesenian","Tari Jaipong","adisus10@gmail.com","Masjid Rumahan","Mobil Merci","O","156","157","2","Mas Aji","1991-03-07","Jawa Tengah","0","S1 Tehnik Pertambangan","Tani","100000","Medan","Meninggal","0812323","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Ri111111","aktif");



DROP TABLE IF EXISTS user;

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `nama_lengkap` varchar(20) NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` varchar(20) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","admin","Administrator","dada123","admin");



