DROP TABLE IF EXISTS alumni;

CREATE TABLE `alumni` (
  `id_alumni` int(10) NOT NULL AUTO_INCREMENT,
  `nisn_alumni` varchar(10) NOT NULL,
  `nm_alumni` varchar(30) NOT NULL,
  `foto_alumni` varchar(250) DEFAULT NULL,
  `kelamin_alumni` char(1) DEFAULT NULL,
  `email_alumni` varchar(100) DEFAULT NULL,
  `no_telp_alumni` varchar(13) DEFAULT NULL,
  `tmplhr_alumni` varchar(50) DEFAULT NULL,
  `tgllhr_alumni` date DEFAULT NULL,
  `agama_alumni` varchar(20) DEFAULT NULL,
  `alamat_alumni` text,
  `status_alumni` varchar(50) DEFAULT NULL,
  `keterangan_alumni` text,
  PRIMARY KEY (`id_alumni`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO alumni VALUES("33","3456345643","sdghsd","","L","adisus10@gmail.com","56745656","","2004-01-08","0","asfga","0","");
INSERT INTO alumni VALUES("34","7845674567","fgsdhfgsh","","L","","","","1900-01-01","0","","0","");
INSERT INTO alumni VALUES("35","4356345634","gdhsd","","P","asdf@fgsf.com","4356345","w23e423","2005-03-03","Islam","afhasdg","Kuliah","asdf");
INSERT INTO alumni VALUES("36","5464567346","Adi Susanto","about-logolock.png","P","adisus10@gmail.com","98456","asdfas","2006-03-14","Islam","asdgasdg","Kerja","ashgsadg");



DROP TABLE IF EXISTS berita;

CREATE TABLE `berita` (
  `id_berita` int(5) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(5) NOT NULL,
  `jdl_berita` varchar(100) NOT NULL,
  `penulis` varchar(30) DEFAULT NULL,
  `tgl_berita` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `foto_berita` varchar(250) NOT NULL,
  `isi_berita` text,
  PRIMARY KEY (`id_berita`),
  KEY `id_kategori` (`id_kategori`)
) ENGINE=MyISAM AUTO_INCREMENT=11172 DEFAULT CHARSET=latin1;

INSERT INTO berita VALUES("11163","11129","OSIS","admin","2017-04-09 01:48:33","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11153","11129","Marching Band","admin345","2017-01-22 06:18:46","KJIKJI.jpg","Dimulai pada tanggal 02 Mei awal perdana SMKN2 Tebo menampilkan marching band . 2mei? Iya hari pendidikan adalah hari dimana team GPM.DRUM COORPS SMKN2 TEBO baru saja launching pertama kali,melatih mental tampil sederhana mungkin dan seadanya mungkin karena team kami baru saja dibentuk tanggal 15 Febuari 2016 dan 3bulan setelah menjalankan latihan setiap hari rabu dan sabtu kami harus tampil di hari pendidikan.\n\nTanggal 17 Agustus? Kami hanya bisa menguji mental kami di penurunan bendera , Tanggal 18 Agustus? Kami mencoba uji mental di Kabupaten Tebo, tampil pertama kali di depan bupati beserta ibu, memakai costum baru,menunjukan inilah team baru kami, inilah team kami yang ada di SMKN2 Kab.Tebo\n\n20 agustus? Kami mengikuti pawai di Rimbo Bujang,memakai costum baru,dan berusaha tampil semaksimal mungkin dan sebagus mungkin,hanya 1 pikiran kami di team \"TIDAK AKAN BIKIN MALU NAMA SEKOLAH\"\n\n Pada acara karnaval memperingati hari kemerdekaan tepat nya pada tanggal 20 Agustus 2016 SMKN 2 TEBO  berhasil merebutkan juara pertama tingkat kecamatan . tentu saja itu membuat Kami dan  semua masyarakat yang ada di SMKN 2 TEBOmerasa bangga. Semangat terusss... ");
INSERT INTO berita VALUES("11164","11129","Mengaji ","admin","2017-04-09 01:48:57","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11152","11130","Ayo Magang Ke Jepang!","admin","2017-01-22 06:03:04","camera.png"," Magang Jepang adalah suatu program belajar sambil praktek kerja yang di lakukan bagi para lulusan SMK sederajat di Negara  Jepang. Program ini dilaksanakan oleh kerjasama antara Pemerintah Republik Indonesia dengan Pemerintah Jepang yang disebut dengan Program IM JAPAN  yang di selenggarakan oleh Disosnakertrans  propinsi di seluruh Indonesia. Program pemagangan ini pun dilaksanakan oleh Perusahaan-perusahaan dan atau LPK (Lembaga Pelatihan Kerja) swasta yang sudah mendapatkan izin dari Kementerian RI Bidang Lattas Pemagangan, dalam hal ini LPK KANTANNA SAKURA yang personil  kepengurusannya  adalah alumni Japan dan beberapa pendidik di SMK N 2 Kab.Tebo Siap memberangkatkan para alumnus SMK  untuk ikut magang. Perusahaan ataupun  LPK yang bisa mengirimkan Pemagang Ke Jepang biasa di sebut dengan Sending Organization (SO). Dan di Indonesia ini selain Dinsosnakertrans RI ada juga sekitar 92 Sending Organization (SO) yang bisa mendidik dan mengirimkan  anda ke Jepang Sebagai Pemagang (Trainee) \n\nPERSYARATAN  DAN PROSEDUR PROGRAM MAGANG JEPANG\n\n• PERSYARATAN UMUM CALON TRAINEE JAPAN\n\n1. USIA ANTARA 19-27 TAHUN,\n\nUsia produktif menurut perusahaan jepang adalah antara 20-27 tahun, akan tetapi kesempatan untuk ke jepang sudah bisa di raih dari umur 18 tahun, dan bagi umur 30 tahun ke atas pada dasarnya masih ada kesempatan untuk magang ke jepang,  tetapi  mungkin agak kecil kesempatan tersebut, karena sebagian besar perusahaan jepang biasanya lebih cenderung mengambil yang usianya masih muda. Maka bagi teman-teman yang merasa usianya masih produktif alangkah baiknya tidak menyia-nyiakan kesempatan yang ada. Dan bagi yang usianya lebih pun tetap ada kesempatan.\n\n2. FISIK JASMANI/KESEMAPTAAN/KESEHATAN\n\nUntuk mengikuti program magang ke Jepang , fisik yang sempurna adalah syarat mutlak yang harus di miliki oleh calon pemagang. Badan anda adalah aset yang sangat besar yang bisa membuat anda mendapatkan hasil yang cukup besar. Maka jagalah dan sayangilah badan anda yang bagus dan sempurna itu. Jangan sampai karena kecerobohan-kecerobohan yang di lakukan membuat anda merusak fisik anda menjadi cacat yang akhirnya akan menjadikan penyesalan yang tiada arti. Masa muda memang terkadang adalah masa yang labil, dimana di situ faktor lingkungan menjadi penentu sikap anda, maka pandai-pandailah menyikapi keadaan sehingga dalam lingkungan seperti apapun anda harus menjadi yang terbaik dan bisa menjaga diri.\n\nContoh kecilnya adalah : tatto dan tindik..\n\nKarena Dalam syarat menjadi pemagang Jepang tatto dan tindik tidaklah di perbolehkan, maka sayangilah badan anda,,,Selanjutnya di samping fisik yang kuat dan sempurna, yang tidak kalah pentingnya adalah kesehatan. Dalam program magang  jepang tidak mungkin mau menerima orang yang sakit baik jasmani maupun rohani, terutama adalah penyakit yang menular.  Karena dalam program ini di bagian medical cek up nya akan sangat teliti. Jadi sebisa mungkin jagalah kesehatan anda. Janganlah mengkonsumsi makanan atau minuman atau obat-obatan yang anda sendiri sudah tau kalau itu tidak baik dan malah akan merusak. Bahkan akan menimbulkan penyakit, contoh seperti narkoba, minuman keras dll. Jadi intinya, sayangilah diri anda untuk menggapai masa depan yang cerah…\n\n \n\n3. DOKUMEN PRIBADI HARUS LENGKAP\n\n• Ijazah Minimal SMK Sederajat/Kejar Paket C\n\n• Dokumen pribadi seperti KTP, KK, AKTE, IJAZAH dan dokumen yang lain harus sama dalam penulisan Nama, Tanggal Lahir, Dan Tempat Lahir. Tidak boleh ada perbedaan baik huruf atau pun angka di dalam dokumen tersebut, karena dokumen tersebut adalah dasar yang di pakai untuk pengurusan Pasport, Visa, Dan Dokument Yang Lain untuk syarat ke Jepang. Jadi harus benar-benar fix dan tidak boleh ada kesalahan. Maka bagi temen-teman yang ingin magang ke Jepang, dari sekarang silahkan cek seluruh Dokumen pribadi anda dan pastikan  semua singkron dan tidak ada kesalahan.\n\n• PROSEDUR UMUM MAGANG KE JEPANG\n\n1. SELEKSI AWAL MELIPUTI  :\n\n• Seleksi Administrasi (Dokument Pribadi)\n\nSetelah mendaftarkan diri , yang pertama di perhatikan adalah kelengkapan dokument pribadi  anda seperti yg telah di jelaskan di atas, semua dokumen  pribadi anda harus lengkap dan singkron satu sama lain, seperti KTP, KK, AKTE, IJAZAH dll.\n\n•  Pemeriksaan Kesemaptaan Tubuh\n\nMeliputi pemeriksaan FISIK yang meliputi Tinggi Badan, Berat Badan, Cacat Tubuh, Fungsi Organ Tubuh. Di sinilah anda akan merasa bahwa tubuh anda adalah aset yang sangat berharga, maka sayangilah dan peliharalah dengan baik.\n\n• Test Bahasa Jepang Dasar\n\nDi sinilah fungsi LPK KANTANNA SAKURA akan terasa karena untuk mengikuti seleksi Program Magang Jepang  paling tidak siswa harus sudah mengetahui dasar dari bahasa jepang dan kebudayaan jepang.\n\n• Test Psiko Dan Matematika\n\nTugas LPK KANTANNA SAKURA bukan hanya mengajari bahasa jepang saja tapi termasuk semua hal yang berkaitan dengan Program Magang Jepang , dan di LPK KANTANNA SAKURA yang ada di SMKN 2 Tebo semua di ajarkan termasuk psikotest dan matematika.\n\n• Wawancara Dengan User Dari Jepang\n\nNah.. seleksi yang ini lumayan harus memerlukan persiapan yang prima untuk menghadapinya, karena di sini bisa jadi adalah penentu keberhasilan anda. Pihak perusahaan penerima dari jepang akan langsung memilih anda sebagai pemagang di Perusahaanya,  oleh karena itu anda harus benar-benar maksimal di hadapan mereka. Dan itupun akan kita latih selama di LPK supaya tidak terlalu nerves dalam melaksanakan seleksi di tahap ini.  Semangat….\n\n• Kesehatan (Medical Ceck Up)\n\nIni adalah test terakhir dan penentu keberhasilan anda, mau sebagus apapun hasil test sebelumnya,  kalau di medicalnya jelek pasti akan gagal, karena tidak mungkin pihak perusahaan pengirim(sending organisasi) akan mengirimkan orang yang sakit untuk sampai ke Jepang. Karena sangat beresiko, maka jagalah kesehatan anda dari sekarang…\n\nContok penyakit yang sulit untuk di tolerir biasanya penyakit yang menular seperti : Hepatitis, tbc, aids dan penyakit menular yang lain….\n\n2. MASA PENDIDIKAN PRA PEMBERANGKATAN KE JEPANG\n\nSetelah semua seleksi terlewati dan hasilnya adalah ok/lolos.., maka tahap berikutnya ada masa pendidikan pra-pemberangkatan di daerah (untuk program IM JAPAN) ataupun di Perusahaan Pengirim ke Jepang (sending organisasi). Di sini adalah masa pemantapan bahasa Jepang dan sikap anda. Jadi jangan senang dulu setelah lolos seleksi awal, karena di masa ini kemampuan anda benar-benar di pertaruhkan. Dan sikap anda juga benar-benar di perhatikan. Kalau di masa ini anda tidak  bisa mengikuti pendidikan bahasa Jepang dengan baik ataupun sikap anda di anggap jelek maka konsekwensinya adalah bisa di cancel  ataupun di pulangkan kembali ke tahap awal. Maka harus tetap hati-hati dan semangat dalam belajar dan harus menjaga sikap sebaik mungkin dan meminimalisasi kesalahan .\n\n3. TERBANG KE JEPANG\n\nInilah masa yang paling indah dan masa paling di tunggu tentunya “terbang ke negeri sakura”, wah.. semua calon pemagang jepang pasti mendambakan masa ini ya..  Tapi ingat, jangan senang dulu. di sini adalah babak awal  anda untuk meraih masa depan yang bagus, tetapi di balik itu ternyata anda punya tanggung jawab yang sangat besar di sini, yaitu untuk menjaga nama baik lembaga yang mendidik anda, perusahaan yang memberangkatkan anda dan tentunya menjaga nama baik negara tercinta kita ini. Maka tetaplah santun dan jaga ketenangan ya..  tunjukkan bahwa negara kita adalah negara yang santun dan berwibawa… semangat. Ganbatte minna san.....(Sβ) ");
INSERT INTO berita VALUES("11150","11127","Diklat Moda Daring Online","admin345","2017-01-22 06:15:36","diklat.png","Berdasarkan hasil rapat koordinasi dengan Dinas Pendidikan Bidang PPTK hari Kamis, 25 Agustus 2016 perihal Guru Pembelajar, berkaitan dengan hal tersebut maka kami beritahukan sebagai berikut :\n \n1. Kepada para Guru yang Nilai Merah 1 – 5 mengikuti Diklat Moda Daring (Online ), Nilai Merah 6 – 7 mengikuti Diklat Model Campuran (Moda Daring dan Tatap Muka ).\n3. Berkenaan dengan ini maka masing-masing guru untuk mempersiapkan diri dengan berlatih TIK ( Teknologi\n4. Informasi Komputer ) dan Mempersiapkan perangkat TIK yaitu PC/Laptop yang ada web camnya, atau Smart Phone Android/ios (front Camera) yang bisa digunakan untuk model streaming atau video call serta jaringan pendukungnya.\n5. Diklat ini rencananya di laksanakan tanggal 7 September 2016.\n6. Jadwal akan tertera pada akun GPO nya masing-masing PTK atau Guru setelah login (belum punya akun? silahkan klik disini untuk membuat akun GP).\n7. Mengingat waktu yang sudah mendesak mohon setiap PTK untuk segera berlatih login akunnya masing-masing dan pastikan setiap PTK sudah memegang akun GPO nya sendiri-sendiri apabila belum memiliki akun segera menghubungi koordinator Gugusnya masing-masing. Bila Koordinator Gugus/KKG mengalami kesulitan bisa konsultasi langsung ke UPTD.\n8. Kepada Guru yang Nilainya Merah 8-10 akan mengikuti diklat Tatap Muka penuh (jadwal menyusul) ");
INSERT INTO berita VALUES("11151","11127","Gebyar TIK 2016","admin345","2017-01-22 06:01:15","Gebyar TIK 2016.jpg","Gebyar TIK diselenggarakan sebagai bentuk apresiasi dan penghargaan kepada Sekolah dan Guru SD/MI, SMP/MTs, SMA/MA/SMK yang berdedikasi memajukan pendidikan di Kabupaten Tebo pada khususnya dan di Provinsi Jambi pada umumnya dengan mengembangkan dan memanfaatkan TIK untuk pendidikan pada pendidikan dasar dan menengah. Adapun gelar Gebyar TIK yang pada puncak final di selenggarakan di Provinsi Jambi mulai pada tanggal 5 s.d. 8 September 2016 ini bertujuan untuk mengaplikasikan Teknologi TIK dalam bidang Pendidikan, wadah kreatifitas dan unjuk potensi TIK Guru/Sekolah se-Provinsi Jambi, mendorong dan meningkatkan pengembangan dan pemanfaatan TIK di Sekolah, serta menumbuhkan kesadaran pendayagunaan teknologi yang tepat-guna.\n\nUntuk seleksi calon peserta lomba ini diselenggarakan di Dinas Dikbudpora Kabupaten Tebo yang mana akan dipilih 17 (tujuh belas) orang yang terdiri dari guru dan peserta didik terbaik yang akan dikirimkan untuk mengikuti final Gebyar TIK Jambi tahun 2016 yang terbagi dalam beberapa kategori lomba sebagai berikut:\n1. Blog Guru Guru SD-SMA (1 peserta)\n2. Blog Siswa Siswa SMA Sederajat (1 peserta)\n3. Media Animasi Guru SD-SMA (1 peserta)\n4.  Media Presentasi Guru SD-SMA (1 peserta)\n5. Media Video Guru SD-SMA (1 peserta)\n6. Media Mobile Edukasi Guru SD-SMA (1 peserta)\n7. Web SD SD (1 peserta)\n8. Web SMP SMP (1 peserta)\n9. Web SMA SMA (1 peserta)\n10. Kuis Kihajar SD Siswa SD Sederajat (1 peserta)\n11. Kuis Kihajar SMP Siswa SMP / Sederajat (1 peserta)\n12. Kuis Kihajar SMA Siswa SMA / Sederajat (1 peserta)\n13. Film Pendek Guru Guru SD-SMA (2 peserta dalam 1 kelompok)\n14. Film Pendek Siswa Siswa SMA / Sederajat (2 peserta dalam 1 kelompok)\n15. Seminar - Guru TIK SMA/SMK (1 peserta)\n \nUntuk download surat edaran Dinas Dikbudpora Tebo serta formulir pendaftaran danpetunjuk teknis seleksi Gebyar TIK Kabupaten Tebo Tahun 2016 dapat diunduh pada Menu E-Learning. Formulir pendaftaran yang telah diisi lengkap dan telah ditandatangani oleh Kepala Sekolah serta bahan lomba disampaikan kepada Panitia Seleksi Gebyar TIK Kabupaten Tebo Tahun 2016, Bidang Dikmen Dinas Dikbudpora Tebo (Bpk. Guruh Puji Raharjo, S.Pd) diterima paling lambat sampai dengan hari Kamis, 31 Agustus 2016. Demikian informasi yang kami sampaikan atas perhatiannya diucapkan terimakasih.");
INSERT INTO berita VALUES("11162","11129","Pramuka","admin","2017-04-09 01:48:11","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11166","11128","Multimedia","admin","2017-04-09 01:50:50","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11167","11128","Akutansi","admin","2017-04-09 01:51:03","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11168","11128","Administrasi Perkantoran","admin","2017-04-09 01:51:31","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11169","11128","Teknik Sepeda Motor","admin","2017-04-09 01:51:50","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11170","11130","Ayo Semangat Kamu Pasti Bisa Karena Kamu Super her","admin","2017-04-09 03:52:44","","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam. ");
INSERT INTO berita VALUES("11171","11127","Artikel Tentang Sekolah","admin","2017-04-11 06:53:24","46145.png","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tristique sem in maximus. Maecenas viverra tortor tincidunt diam accumsan semper. Morbi ullamcorper sagittis tortor sed facilisis. Duis dolor enim, luctus congue facilisis id, pellentesque et dui. Vestibulum malesuada suscipit nibh. Praesent non pulvinar elit. Nullam ac purus vel metus tincidunt ornare. Phasellus pulvinar faucibus dui non commodo. Curabitur commodo augue vel scelerisque euismod. Aenean non pretium risus. Fusce pellentesque nulla non mauris iaculis lobortis. Duis mauris lectus, tincidunt vitae urna non, semper dictum enim. Mauris ut lorem libero. Aenean nec facilisis nisi. Pellentesque nibh enim, viverra at pretium sagittis, consequat ac arcu. Praesent luctus, nulla sed fermentum sodales, lorem leo porttitor odio, et feugiat nisl velit molestie massa. Donec commodo nisi et sem mattis dictum non id ex. Quisque vulputate sem quis turpis dignissim sollicitudin. Aliquam nec fringilla quam. Quisque non pulvinar lacus, et eleifend elit. Sed nunc justo, varius a sodales eget, ullamcorper porttitor ipsum. Morbi lorem orci, vehicula vitae sem in, iaculis ultricies ante. Aenean eget quam eu elit posuere ornare pretium pharetra sapien. Nunc imperdiet ut eros eu fermentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu malesuada mauris. Sed convallis finibus magna, a scelerisque justo mattis eget. Vestibulum quis sollicitudin risus. In massa augue, euismod ullamcorper odio a, tincidunt varius nibh. Aenean semper consectetur consectetur. Integer orci nunc, tincidunt nec lacus sed, euismod egestas enim. Nam orci elit, hendrerit et tortor ac, faucibus tristique mauris. Proin at varius dui. Etiam porta mattis lectus, at auctor lacus eleifend in. Quisque elementum erat vitae dignissim suscipit. Mauris non odio tellus. Nam eu risus enim. Morbi lobortis metus tortor, ac faucibus tortor dignissim et. Integer purus ante, fringilla sed eleifend at, tincidunt nec velit. Cras sed felis venenatis, consequat mi vitae, tempor quam.");



DROP TABLE IF EXISTS detail_kelas;

CREATE TABLE `detail_kelas` (
  `id_kelas` int(5) DEFAULT NULL,
  `id_siswa` int(10) DEFAULT NULL,
  `tahun_ajaran` varchar(10) NOT NULL,
  KEY `id_kelas` (`id_kelas`),
  KEY `id_siswa` (`id_siswa`),
  CONSTRAINT `detail_kelas_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_kelas_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO detail_kelas VALUES("19","64","2017-2018");
INSERT INTO detail_kelas VALUES("19","65","2017-2018");
INSERT INTO detail_kelas VALUES("19","62","2017-2018");
INSERT INTO detail_kelas VALUES("19","68","2017-2018");
INSERT INTO detail_kelas VALUES("19","70","2017-2018");
INSERT INTO detail_kelas VALUES("19","71","2017-2018");
INSERT INTO detail_kelas VALUES("19","72","2017-2018");



DROP TABLE IF EXISTS detail_mapel;

CREATE TABLE `detail_mapel` (
  `id_karyawan` int(5) DEFAULT NULL,
  `id_mapel` int(5) DEFAULT NULL,
  KEY `id_karyawan` (`id_karyawan`),
  KEY `id_mapel` (`id_mapel`),
  CONSTRAINT `detail_mapel_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_mapel_ibfk_2` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO detail_mapel VALUES("27","15");



DROP TABLE IF EXISTS jadwal;

CREATE TABLE `jadwal` (
  `id_jadwal` int(5) NOT NULL AUTO_INCREMENT,
  `id_karyawan` int(5) DEFAULT NULL,
  `id_kelas` int(5) DEFAULT NULL,
  `id_mapel` int(5) DEFAULT NULL,
  `hari` varchar(20) DEFAULT NULL,
  `jam` varchar(30) DEFAULT NULL,
  `t_ajaran` varchar(10) NOT NULL,
  PRIMARY KEY (`id_jadwal`),
  KEY `id_karyawan` (`id_karyawan`),
  KEY `id_kelas` (`id_kelas`),
  KEY `id_mapel` (`id_mapel`),
  CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jadwal_ibfk_2` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jadwal_ibfk_3` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

INSERT INTO jadwal VALUES("56","27","19","15","Senin","07:00 - 08:00 ","2017-2018");



DROP TABLE IF EXISTS jurusan;

CREATE TABLE `jurusan` (
  `id_jurusan` int(5) NOT NULL AUTO_INCREMENT,
  `nm_jurusan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jurusan`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO jurusan VALUES("2","Multimedia");
INSERT INTO jurusan VALUES("3","Akutansi");
INSERT INTO jurusan VALUES("6","Administrasi Perkantoran");
INSERT INTO jurusan VALUES("7","Teknik Mesin");
INSERT INTO jurusan VALUES("8","Teknik Sepeda Motor");
INSERT INTO jurusan VALUES("9","Teknik Kendaraan Ringan");



DROP TABLE IF EXISTS karyawan;

CREATE TABLE `karyawan` (
  `id_karyawan` int(5) NOT NULL AUTO_INCREMENT,
  `nip` varchar(20) DEFAULT NULL,
  `nm_karyawan` varchar(30) DEFAULT NULL,
  `foto_karyawan` varchar(250) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `jabatan` varchar(150) NOT NULL,
  `email_karyawan` varchar(100) DEFAULT NULL,
  `no_telp_karyawan` varchar(13) DEFAULT NULL,
  `agama_karyawan` varchar(30) DEFAULT NULL,
  `pend_karyawan` varchar(100) DEFAULT NULL,
  `jenis_kel_karyawan` char(1) DEFAULT NULL,
  `tmp_lhr_karyawan` varchar(50) DEFAULT NULL,
  `tgl_lhr_karyawan` date DEFAULT NULL,
  `alamat_karyawan` text,
  `pass_karyawan` varchar(8) NOT NULL,
  PRIMARY KEY (`id_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO karyawan VALUES("27","198000501201902017","Jhon Susanto","SMKN2-198000501201902017.png","guru","","","","0","","L","","0000-00-00","","902017");
INSERT INTO karyawan VALUES("28","201700601719920080","Ira Wati Sudarsono","SMKN2-201700601719920080.jpg","tu","","","","0","","L","","0000-00-00","","920080");
INSERT INTO karyawan VALUES("29","201700601401998008","Suratno","","guru","","","","0","","L","","0000-00-00","","998008");



DROP TABLE IF EXISTS kategori;

CREATE TABLE `kategori` (
  `id_kategori` int(5) NOT NULL AUTO_INCREMENT,
  `nm_kategori` varchar(30) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM AUTO_INCREMENT=11139 DEFAULT CHARSET=latin1;

INSERT INTO kategori VALUES("11127","berita");
INSERT INTO kategori VALUES("11128","jurusan");
INSERT INTO kategori VALUES("11129","kegiatan");
INSERT INTO kategori VALUES("11130","info sekolah");



DROP TABLE IF EXISTS kelas;

CREATE TABLE `kelas` (
  `id_kelas` int(5) NOT NULL AUTO_INCREMENT,
  `kd_kelas` int(1) NOT NULL,
  `nm_kelas` varchar(50) NOT NULL,
  `id_jurusan` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_kelas`),
  KEY `id_jurusan` (`id_jurusan`),
  CONSTRAINT `kelas_ibfk_1` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO kelas VALUES("7","1","X Akutansi 2","3");
INSERT INTO kelas VALUES("11","2","XI Akutansi 1","3");
INSERT INTO kelas VALUES("12","3","XII Akutansi 1","3");
INSERT INTO kelas VALUES("13","2","XI Akutansi 2","3");
INSERT INTO kelas VALUES("19","1","X Akutansi 1","3");
INSERT INTO kelas VALUES("20","3","XII Akutansi 2","3");



DROP TABLE IF EXISTS khs;

CREATE TABLE `khs` (
  `id_khs` int(10) NOT NULL AUTO_INCREMENT,
  `id_mapel` int(5) DEFAULT NULL,
  `id_jurusan` int(5) DEFAULT NULL,
  `id_siswa` int(10) DEFAULT NULL,
  `id_kelas` int(5) DEFAULT NULL,
  `semester` varchar(10) DEFAULT NULL,
  `thn_ajaran` varchar(10) DEFAULT NULL,
  `nilai` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id_khs`),
  KEY `id_mapel` (`id_mapel`),
  KEY `id_jurusan` (`id_jurusan`),
  KEY `id_siswa` (`id_siswa`),
  KEY `id_kelas` (`id_kelas`),
  CONSTRAINT `khs_ibfk_1` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `khs_ibfk_2` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `khs_ibfk_3` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `khs_ibfk_4` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO khs VALUES("21","15","3","62","19","ganjil","2017-2018","90");



DROP TABLE IF EXISTS learning;

CREATE TABLE `learning` (
  `id_learning` int(10) NOT NULL AUTO_INCREMENT,
  `nm_learning` varchar(50) DEFAULT NULL,
  `file_learning` varchar(250) DEFAULT NULL,
  `id_karyawan` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_learning`),
  KEY `id_karyawan` (`id_karyawan`),
  CONSTRAINT `learning_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS mapel;

CREATE TABLE `mapel` (
  `id_mapel` int(5) NOT NULL AUTO_INCREMENT,
  `nm_mapel` varchar(50) NOT NULL,
  PRIMARY KEY (`id_mapel`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO mapel VALUES("11","Matematika");
INSERT INTO mapel VALUES("15","Bahasa Indonesia");
INSERT INTO mapel VALUES("16","Design Grafis");
INSERT INTO mapel VALUES("17","IPS");
INSERT INTO mapel VALUES("18","Bahasa Inggris");
INSERT INTO mapel VALUES("22","IPA");



DROP TABLE IF EXISTS siswa;

CREATE TABLE `siswa` (
  `id_siswa` int(10) NOT NULL AUTO_INCREMENT,
  `nisn_siswa` varchar(10) DEFAULT NULL,
  `nm_siswa` varchar(30) DEFAULT NULL,
  `foto_siswa` varchar(250) NOT NULL,
  `jenis_kelamin` char(1) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `tempat_lhr` varchar(50) DEFAULT NULL,
  `agama` varchar(20) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `hobby` varchar(30) DEFAULT NULL,
  `ket_hobi` text NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `alamat` text,
  `transportasi` varchar(30) DEFAULT NULL,
  `gol_darah` char(1) DEFAULT NULL,
  `tinggi` int(3) DEFAULT NULL,
  `berat` int(3) DEFAULT NULL,
  `anak_ke` char(2) DEFAULT NULL,
  `nm_ayah` varchar(30) DEFAULT NULL,
  `tgl_lhr_ayah` date DEFAULT NULL,
  `tmp_lhr_ayah` varchar(20) NOT NULL,
  `agama_ayah` varchar(20) DEFAULT NULL,
  `pendidikan_ayah` varchar(50) DEFAULT NULL,
  `pekerjaan_ayah` varchar(50) DEFAULT NULL,
  `penghasilan_ayah` varchar(20) DEFAULT NULL,
  `alamat_ayah` text,
  `status_hidup_ayah` varchar(20) DEFAULT NULL,
  `no_telp_ayah` varchar(13) DEFAULT NULL,
  `nm_ibu` varchar(30) DEFAULT NULL,
  `tgl_lhr_ibu` date DEFAULT NULL,
  `tmp_lhr_ibu` varchar(50) DEFAULT NULL,
  `agama_ibu` varchar(20) DEFAULT NULL,
  `pendidikan_ibu` varchar(50) DEFAULT NULL,
  `pekerjaan_ibu` varchar(50) DEFAULT NULL,
  `penghasilan_ibu` varchar(20) DEFAULT NULL,
  `alamat_ibu` text NOT NULL,
  `nm_wali` varchar(30) DEFAULT NULL,
  `tgl_lhr_wali` date DEFAULT NULL,
  `tmp_lhr_wali` varchar(100) DEFAULT NULL,
  `agama_wali` varchar(20) DEFAULT NULL,
  `pendidikan_wali` varchar(50) DEFAULT NULL,
  `pekerjaan_wali` varchar(50) DEFAULT NULL,
  `penghasilan_wali` varchar(20) DEFAULT NULL,
  `alamat_wali` text,
  `no_telp_wali` varchar(13) DEFAULT NULL,
  `pass_siswa` varchar(8) NOT NULL,
  `status_siswa` varchar(10) NOT NULL,
  PRIMARY KEY (`id_siswa`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;

INSERT INTO siswa VALUES("62","1995010008","Adi Susanto","SMKN2-1995010008.jpg","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Ad010008","aktif");
INSERT INTO siswa VALUES("64","1995011009","Ridwan Mas","SMKN2-1995011009.png","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Ri011009","aktif");
INSERT INTO siswa VALUES("65","1994003004","Danan Widodo","SMKN2-1994003004.png","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Da003004","aktif");
INSERT INTO siswa VALUES("66","1995012019","Salih Mubarak","SMKN2-1995012019.png","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Sa012019","aktif");
INSERT INTO siswa VALUES("67","1995007028","Faizal Arima","SMKN2-1995007028.png","P","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Fa007028","aktif");
INSERT INTO siswa VALUES("68","1993006014","Ari Supriyadi","","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Ar006014","aktif");
INSERT INTO siswa VALUES("69","1995012003","Reni Ayuni","","P","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Re012003","aktif");
INSERT INTO siswa VALUES("70","1998012009","Sarinah Ambar","","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Sa012009","aktif");
INSERT INTO siswa VALUES("71","1997012012","Rahmansyah","","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Ra012012","aktif");
INSERT INTO siswa VALUES("72","1996010023","Eko Rahman","","L","0000-00-00","","0","","0","","","","0","0","0","0","","","0000-00-00","","0","","","","","Hidup","","","0000-00-00","","0","","","","","","0000-00-00","","0","","","","","","Ek010023","aktif");



DROP TABLE IF EXISTS user;

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `nama_lengkap` varchar(20) NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` varchar(20) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","admin","Administrator","dada123","admin");
INSERT INTO user VALUES("3","hdghsdf","fgdhsasf","sadfhdf","admin");



