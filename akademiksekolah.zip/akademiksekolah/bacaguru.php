<?php
include "/config/koneksi.php";
$ambil_data = mysql_query("select * from karyawan where id_karyawan='$_GET[id]'");
$hasil_data = mysql_fetch_array($ambil_data);
?>
<div id="latest">
	<div style="float:left; padding-right:80px; padding-left:50px">
		<img src='foto_karyawan/<?=$hasil_data['foto_karyawan'];?>' width=270  hspace=10 border=0>
	</div>

	<div style="float:left;">

	<table style="font-weight:bold" width="100%" cellpadding="3" cellspacing="0">

		<tr>
			<td width="200">NIP</td>
			<td><?=$hasil_data['nip'];?></td>
		</tr>

		<tr>
			<td>Nama</td>
			<td><?=$hasil_data['nm_karyawan'];?></td>
		</tr>

		<tr>
			<td>Jabatan</td>
			<td><?=$hasil_data['jabatan'];?></td>
		</tr>

		<tr>
			<td>Jenis Kelamin</td>
			<td><?=$hasil_data['jenis_kel_karyawan'];?></td>
		</tr>

		<tr>
			<td>Email</td>
			<td><?=$hasil_data['email_karyawan'];?></td>
		</tr>

		<tr>
			<td>No. Telp</td>
			<td><?=$hasil_data['no_telp_karyawan'];?></td>
		</tr>

		<tr>
			<td>Alamat</td>
			<td><?=$hasil_data['alamat_karyawan'];?></td>
		</tr>

		<tr>
			<td></td>
			<td> <?php echo "<a href=baca_view.php?module=learning_guru&id=$_GET[id]>Daftar Materi</a>" ?> </td>
		</tr>
	</table>
	</div>
</div>
<div style="clear:both;"></div>
