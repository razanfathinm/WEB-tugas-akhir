<?php  
  session_start();	
  error_reporting(0);
  include "config/koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>	SMKN 2 TEBO</title>
	<link rel="stylesheet" type="text/css" href="style/reset.css" />
	<link rel="stylesheet" type="text/css" href="style/style.css" />
	<link rel="stylesheet" type="text/css" href="style/media-queries.css" />
	<link rel="stylesheet" type="text/css" href="style/colom.css">
	<link rel="stylesheet" type="text/css" href="style/slider.css">
	<link rel="stylesheet" type="text/css" href="style/style_slider.css">
	<link rel="stylesheet" type="text/css" href="style/menu.css">
	<link rel="stylesheet" type="text/css" href="style/paging.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="images/favicon.ico">

</head>

<body id="home">

	<div id="navigasi">
		<div class="menu-kiri">
			<a href="home"><strong> SMKN 2 TEBO</strong></a>
		</div>
       	<ul>
          	<li class="current"><a href="#">Home</a></li>
            <?php 
			if (!$_SESSION['namauser'] == ''){
				echo "
			            <li><a href='#'>Download</a></li>
			            <li><a href='#'>Services</a></li>
			            <li><a href='#'>Contact Us</a></li>
            			<li><a href=logout.php>Logout</a></li>
					  ";
			}else{
				echo " <li><a href=#>Download</a></li>
			            <li><a href=#>Services</a></li>
			            <li><a href=#>Contact Us</a></li>
			            <li><a href=login.html>Login</a></li>";
			}
			
		?>
        </ul>
        
    </div><!-- End Navigasi -->
<div class="clearfix"></div>

<div>
	<div class="cycle-slideshow">
		<span class="cycle-prev">&#9001;</span> <!-- Untuk membuat tanda panah di kiri slider -->
		<span class="cycle-next">&#9002;</span> <!-- Untuk membuat tanda panah di kanan slider -->
		<span class="cycle-pager"></span>  <!-- Untuk membuat tanda bulat atau link pada slider -->
		<img class="slide" src="images/slide1.png" alt="Gambar Pertama">
		<img class="slide" src="images/slide2.png" alt="Gambar Kedua">
		<img class="slide" src="images/slide3.png" alt="Gambar Ketiga">
	</div>
</div>
	

	<nav>
  		<ul>
		    <li><a href="">PSB</a><li>
		    <li><a href="guru">Guru</a><li>
		    <li><a href="">Fasilitas</a><li>
		    <li><a href="learning">E-Learning</a><li>
  		</ul>
	</nav>

	<div class="clearfix"></div>

	<div id="wrapper"> 
		<!-- End Header-->
		<section id="main-content">
			
			<?php
                if (empty($_GET['link'])) {
                    include "kiri.php";
                } else {
                    include($_GET['link']);
                }                     
            ?> 

			 <!-- END Latest -->
			<div class="clearfix"></div>
			
		</section>	

	</div> <!-- END Wrapper -->
	<div class="head">
		<div class="foot">
			<h3>Alamat Sekolah</h3><br>
			<p>JL. M. HATTA, Wirotho Agung, Rimbo Bujang, Kabupaten Tebo, Jambi, Indonesia </p>
			<p>No. Telp : 027-xxxxxx</p>
			<p>Kode Pos : 37553</p>
			<p>Email : yahoo@mail.com</p>
		</div>

		<div class="foot_right">
			<h3>Social Media</h3><br>
			<a href=""> <div class="google"></div></a>
			<a href=""> <div class="twitter"></div></a>
			<a href=""> <div class="fb"></div></a><br><br>
			<p>Website : <a href="smkn2tebo.sch.id">www.smkn2tebo.sch.id</a></p>

		</div>
	</div>
<div class="clearfix"></div>
	<div class="head">
		<footer>
			<p style="font-weight:bold; color:blue;">&copy; 2016 - SMK Negeri 2 Kab. Tebo</p>
		</footer>
	</div>
	
</body>
<script type="text/javascript" src="js/jQuery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/jquery.cycle2.min.js"></script>
</html>