
<?php

if ($_GET[module]=='jadwal'){ 
  echo "<div class='panel-heading'>
                Manajemen Jadwal Pelajaran
                </div>
                <div class='panel-body'>";
	echo " 
            <div align=center>
            <h1><div>Jadwal Pelajaran</div></h1>
            <table class='data' width=100% cellpadding=6>
            <form action=filter_jad.php name=myform method=GET onSubmit='return valid_jad()'>
              <tr align=center>
                <td>Kelas : 
                  <select name=kelas class=field>
                    <option value=0 selected> Pilih Kelas </option>";
                
                      $kat=mysql_query("SELECT * FROM kelas ORDER BY nm_kelas");
                        while($vr=mysql_fetch_array($kat)){
                          echo "<option value=$vr[id_kelas]>$vr[nm_kelas]</option>";
                        }
                      echo "</select>
                      Tahun Ajaran : 
                  <select name=tahun class=field>
                    <option value=0 selected> Pilih Tahun </option>";
                
                      $kat=mysql_query("SELECT DISTINCT t_ajaran from jadwal");
                        while($vr=mysql_fetch_array($kat)){
                          echo "<option value=$vr[t_ajaran]>$vr[t_ajaran]</option>";
                        }
                      echo "</select>";
                      echo " <input class=button-submit type=submit name=submit value='Tampilkan Jadwal'> ";
                     
                      if ($_SESSION['leveluser'] == 'tu' || $_SESSION['leveluser'] == 'admin') {
                        echo "<input style='padding=30px;' class=button-submit type=button value='Tambah Jadwal' 
                        onclick=\"window.location.href='media.php?module=tambahjadwal';\">";
                      }
                      echo "
                        </td>
              </tr>
             </form>
            </table>
            </div></div>";
	
}elseif ($_GET[module]=='tampiljadwal'){ 
    $tam=mysql_query("SELECT * FROM jadwal a 
                        JOIN kelas b ON b.id_kelas=a.id_kelas where a.id_kelas='$_GET[ke]' AND a.t_ajaran='$_GET[ta]'");
    $t = mysql_fetch_array($tam);
    echo "<div class='panel-heading'>
                Manajemen Jadwal Pelajaran
                </div>
                <div class='panel-body'>";
  echo "<div align=center>
            <h1><div>Jadwal Pelajaran $t[nm_kelas]</div></h1>
            <table class='data' width=100% cellpadding=6>
            <form action=filter_jad.php name=myform method=GET onSubmit='return valid_jad()'>
              <tr align=center>
                <td>Kelas : 
                  <select name=kelas class=field>
                    <option value=0 selected> Pilih Kelas </option>";
                            $tampil = mysql_query("SELECT * from kelas order by nm_kelas");
                            while($w=mysql_fetch_array($tampil)){
                              if ($t[id_kelas]==$w[id_kelas]){
                                echo "<option value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                              }
                              else{
                                  echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                              }
                          }
                      echo "</select> 
                      Tahun Ajaran : 
                        <select name=tahun class=kfield>
                          <option value=0 selected> Pilih Tahun </option>";
                          $k = mysql_query("SELECT DISTINCT t_ajaran from jadwal");
                          while($c=mysql_fetch_array($k)){
                            if ($t[t_ajaran]==$c[t_ajaran]){
                              echo "<option value=$c[t_ajaran] selected>$c[t_ajaran]</option>";
                            }
                             else{
                              echo "<option value=$c[t_ajaran]>$c[t_ajaran]</option>";
                            }
                          }
                            echo "
                        </select>
                      <input class=button-submit type=submit name=submit value='Tampilkan Jadwal'> <input class=button-exit type=button value='Kembali' 
          onclick=\"window.location.href='jadwal.html';\">";

          if($_SESSION[leveluser]=='admin' || $_SESSION[leveluser]=='tu'){ 
          echo " <input class=button-submit type=button value='Tambah Jadwal $t[nm_kelas]' 
          onclick=\"window.location.href='media.php?module=tambahkanjadwal&id=$t[id_kelas]&ta=$t[t_ajaran]';\">";
          }
          echo "</td>
              </tr>
             </form>
            </table>
            </div>";
            echo "
            <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>Hari</th>
                  <th class='data'>Mata Pelajaran</th>
                  <th class='data'>Jam Pelajaran</th>
                  <th class='data' width=180px>Guru Pengajar</th>";

                  if($_SESSION[leveluser]=='admin' || $_SESSION[leveluser]=='tu'){ 
                  echo "<th class='data nosorting' width=90px>Action</th>";
                  } echo "  
                </tr>
              </thead>
              <tbody>";
                    $jdl = mysql_query("SELECT * from jadwal a 
                                          join karyawan b ON a.id_karyawan=b.id_karyawan
                                          join mapel c ON a.id_mapel=c.id_mapel where a.id_kelas='$_GET[ke]' AND a.t_ajaran='$_GET[ta]' ORDER BY a.hari DESC");
                  
                    $no = 1;
                    while ($r=mysql_fetch_array($jdl)){
                       echo "<tr class='data'><td class='data'>$no</td>
                            <td class='data'>$r[hari]</td>
                            <td class='data'>$r[nm_mapel]</td>
                            <td class='data'>$r[jam]</td>
                            <td class='data'>$r[nm_karyawan]</td>
                            ";
                            if($_SESSION[leveluser]=='admin' || $_SESSION[leveluser]=='tu'){
                              echo "
                                  <td class='data' align=center><a class=button-action href=media.php?module=editjadwal&id=$r[id_jadwal]>Edit</a> | 
                                     <a class=button-hapus href=media.php?module=hapusjadwal&id=$r[id_jadwal]&kd=$t[id_kelas]&th=$t[t_ajaran] onClick=\"return confirm('Anda yakin menghapus jadwal hari $r[hari] kelas $t[nm_kelas]?')\">Hapus</a>";
                                   }
                   echo "</td>
          </tr>";
          $no++;
        }
        
        echo "</tbody></table></div>";
  
}elseif($_GET[module]=='tambahkanjadwal'){

  $tamp=mysql_query("SELECT * FROM jadwal a 
                        JOIN kelas b ON b.id_kelas=a.id_kelas where a.id_kelas='$_GET[id]' AND a.t_ajaran='$_GET[ta]'");
  $j=mysql_fetch_array($tamp);

  echo "<div class='panel-heading'>
                Tambah Jadwal Pelajaran
                </div>
                <div class='panel-body'>";
echo "<form name='myform' method=POST action='media.php?module=aksitambahjadwal' onSubmit='return validasi_jad()'>
          <table>
          <input type=hidden name=kelas value=$j[id_kelas]>
         <tr>
          <td>Kelas</td><td> <input class=field type=text readonly name=nm_kel value='$j[nm_kelas]'> </td></tr>
          <tr>
          <td>Tahun Ajaran</td><td> <input class=field type=text readonly name=tahun value='$j[t_ajaran]'> </td></tr>
          <tr>
          <td>Mata Pelajaran</td><td> 
              <select name=mapel id=mapel class=field>
                <option value=''> Pilih Mapel </option>";
                  $map=mysql_query("SELECT * FROM mapel ORDER BY nm_mapel");
                    while($mp=mysql_fetch_array($map)){
                      echo "<option value=$mp[id_mapel]>$mp[nm_mapel]</option>";
                    }
                      echo "</select></td></tr>
          <tr>
            <td>Guru</td><td> 
              <select name=guru id=guru class=field>
                <option value=''> Pilih Guru </option>";
                
                  $gur=mysql_query("SELECT * FROM karyawan a
                                      JOIN detail_mapel b ON a.id_karyawan = b.id_karyawan
                                      JOIN mapel c ON c.id_mapel = b.id_mapel ORDER BY a.nm_karyawan");
                    while($gr=mysql_fetch_array($gur)){
                      echo "<option id=guru class=$gr[id_mapel] value=$gr[id_karyawan]>$gr[nm_karyawan]</option>";
                    }
                      echo "</select></td></tr>
          <td>Hari</td><td> 
              <select name=hari class=field>
                <option value=0 selected> Pilih Hari </option>
                <option value=Senin> Senin </option>
                <option value=Selasa> Selasa </option>
                <option value=Rabu> Rabu </option>
                <option value=Kamis> Kamis </option>
                <option value=Jumat> Jumat </option>
                <option value=Sabtu> Sabtu </option>
          </select></td></tr>
          <tr>
            <td>Jam Pelajaran </td>
            <td><select name=jammulai id=jammulai>";
            for($i=7;$i<=17;$i++){
            if($i<=9){$i="0$i";}
            echo "<option>$i</option>";
            }
            echo "</select>
            <select name=menitmulai id=menitmulai>";
            for($i=0;$i<=59;$i++){
            if($i<=9){
            $i="0$i";
            }
            echo "<option>$i</option>";
            }
            echo "</select>
            &nbsp;s/d&nbsp;
            <select name=jamakhir id=jamakhir>";
            for($i=7;$i<=17;$i++){
            if($i<=9){$i="0$i";}
            echo "<option>$i</option>";
            }
            echo "</select>
            <select name=menitakhir id=menitakhir>";
            for($i=0;$i<=59;$i++){
            if($i<=9){
            $i="0$i";
            }
            echo "<option>$i</option>";
            }
            echo "</select>
            </td>
            </tr>
            
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='tambahjadwal'){

  echo "<div class='panel-heading'>
                Tambah Jadwal Pelajaran
                </div>
                <div class='panel-body'>";
echo "<form name='myform' method=POST action='media.php?module=aksitambahjadwal' onSubmit='return validasi_jad()'>
          <table>
         <tr>
          <td>Kelas</td><td> 
              <select name=kelas class=field>";
                $tampil=mysql_query("SELECT * FROM kelas ORDER BY nm_kelas");
                  while($w=mysql_fetch_array($tampil)){
                      echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                  }
                      echo "</select></td></tr>
          <tr>
          <td>Tahun Ajaran</td><td> 
              <select name=tahun class=field>";
                $ju=mysql_query("SELECT DISTINCT tahun_ajaran from detail_kelas");
                  while($g=mysql_fetch_array($ju)){
                      echo "<option value=$g[tahun_ajaran]>$g[tahun_ajaran]</option>";
                  }
                      echo "</select></td></tr>
          <tr>
          <td>Mata Pelajaran</td><td> 
              <select name=mapel id=mapel class=field>
                <option value=''> Pilih Mapel </option>";
                  $map=mysql_query("SELECT * FROM mapel ORDER BY nm_mapel");
                    while($mp=mysql_fetch_array($map)){
                      echo "<option value=$mp[id_mapel]>$mp[nm_mapel]</option>";
                    }
                      echo "</select></td></tr>
          <tr>
            <td>Guru</td><td> 
              <select name=guru id=guru class=field>
                <option value=''> Pilih Guru </option>";
                
                  $gur=mysql_query("SELECT * FROM karyawan a
                                      JOIN detail_mapel b ON a.id_karyawan = b.id_karyawan
                                      JOIN mapel c ON c.id_mapel = b.id_mapel ORDER BY a.nm_karyawan");
                    while($gr=mysql_fetch_array($gur)){
                      echo "<option id=guru class=$gr[id_mapel] value=$gr[id_karyawan]>$gr[nm_karyawan]</option>";
                    }
                      echo "</select></td></tr>
          <td>Hari</td><td> 
              <select name=hari class=field>
                <option value=0 selected> Pilih Hari </option>
                <option value=Senin> Senin </option>
                <option value=Selasa> Selasa </option>
                <option value=Rabu> Rabu </option>
                <option value=Kamis> Kamis </option>
                <option value=Jumat> Jumat </option>
                <option value=Sabtu> Sabtu </option>
          </select></td></tr>
          <tr>
            <td>Jam Pelajaran </td>
            <td><select name=jammulai id=jammulai>";
            for($i=7;$i<=17;$i++){
            if($i<=9){$i="0$i";}
            echo "<option>$i</option>";
            }
            echo "</select>
            <select name=menitmulai id=menitmulai>";
            for($i=0;$i<=59;$i++){
            if($i<=9){
            $i="0$i";
            }
            echo "<option>$i</option>";
            }
            echo "</select>
            &nbsp;s/d&nbsp;
            <select name=jamakhir id=jamakhir>";
            for($i=7;$i<=17;$i++){
            if($i<=9){$i="0$i";}
            echo "<option>$i</option>";
            }
            echo "</select>
            <select name=menitakhir id=menitakhir>";
            for($i=0;$i<=59;$i++){
            if($i<=9){
            $i="0$i";
            }
            echo "<option>$i</option>";
            }
            echo "</select>
            </td>
            </tr>
            
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksitambahjadwal'){
	$kelas = $_POST[kelas];
  $mapel = $_POST[mapel];
  $hari = $_POST[hari];
  $tahun = $_POST[tahun];
  $jam = "$_POST[jammulai]:$_POST[menitmulai] - $_POST[jamakhir]:$_POST[menitakhir] ";
  $guru = $_POST[guru];
  $cekdata = mysql_query("SELECT * from jadwal WHERE id_karyawan='$guru' AND id_mapel='$mapel' AND hari='$hari' AND jam='$jam' AND t_ajaran='$tahun'");
  $cekcek = mysql_query("SELECT * from jadwal WHERE id_kelas='$kelas' AND id_mapel='$mapel' AND hari='$hari' AND jam='$jam' AND t_ajaran='$tahun'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> 
            onload = function(){
              alert('Guru sudah memiliki jadwal silahkan inputkan jadwal lain!');onclick=self.history.back()
            return false;
            }
          </script>\n";
  }elseif (mysql_num_rows($cekcek)>0) {
    echo "<script> 
            onload = function(){
              alert('Kelas sudah memiliki jadwal silahkan inputkan jadwal lain!');onclick=self.history.back()
            return false;
            }
          </script>\n";
  }else{
	$insert = mysql_query("INSERT INTO jadwal(id_karyawan,id_kelas,id_mapel,hari,jam,t_ajaran) 
                                                                VALUES('$guru',
                                                                        '$kelas',
                                                                        '$mapel',
                                                                        '$hari',
                                                                        '$jam',
                                                                        '$tahun')");

    if ($insert) {
      header('location:media.php?module=tampiljadwal');
    }else{
      echo "Data gagal disimpan".mysql_error();
      echo " <input type=button value=Kembali onclick=self.history.back()>";
    }
  }
	
}elseif($_GET[module]=='editjadwal'){
	$edit=mysql_query("SELECT * FROM jadwal WHERE id_jadwal='$_GET[id]'");
    $r=mysql_fetch_array($edit);
    $jammul = substr($r[jam], 0,2);
    $menmul = substr($r[jam], 3,2);
    $jamak = substr($r[jam], 8,2);
    $menak = substr($r[jam], 11,2);

    echo "<div class='panel-heading'>
                Edit Jadwal Pelajaran
                </div>
                <div class='panel-body'>";
    echo "<form name='myform' method=POST action='media.php?module=aksieditjadwal' onSubmit='return validasi_jad()'>
          <input type=hidden name=id value='$r[id_jadwal]'>
          <table>
         <tr><td>Kelas</td><td> <select name=kelas class=field>";
            $tampil=mysql_query("SELECT * FROM kelas ORDER BY nm_kelas");
              while($w=mysql_fetch_array($tampil)){
                if ($r[id_kelas]==$w[id_kelas]){
                  echo "<option value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                }
                else{
                  echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                }
              }
            echo "</select></td></tr>
          <tr><td>Tahun Ajaran</td><td> <select name=tahun class=field>";
            $tampilta=mysql_query("SELECT DISTINCT tahun_ajaran from detail_kelas");
              while($f=mysql_fetch_array($tampilta)){
                if ($r[t_ajaran]==$f[tahun_ajaran]){
                  echo "<option value=$f[tahun_ajaran] selected>$f[tahun_ajaran]</option>";
                }
                else{
                  echo "<option value=$f[tahun_ajaran]>$f[tahun_ajaran]</option>";
                }
              }
            echo "</select></td></tr>
          <tr><td>Mapel</td><td> <select id=mapel name=mapel class=field>";
            $tampilmap=mysql_query("SELECT * FROM mapel ORDER BY nm_mapel");
              while($w=mysql_fetch_array($tampilmap)){
                if ($r[id_mapel]==$w[id_mapel]){
                  echo "<option value=$w[id_mapel] selected>$w[nm_mapel]</option>";
                }
                else{
                  echo "<option value=$w[id_mapel]>$w[nm_mapel]</option>";
                }
              }
            echo "</select></td></tr>
          <td>Hari</td><td> 
              <select name=hari class=field>
                <option value=$r[hari] selected> $r[hari] </option>
                <option value=Senin> Senin </option>
                <option value=Selasa> Selasa </option>
                <option value=Rabu> Rabu </option>
                <option value=Kamis> Kamis </option>
                <option value=Jumat> Jumat </option>
                <option value=Sabtu> Sabtu </option>
          </select></td></tr>
          <tr>
            <td>Jam Pelajaran </td>
            <td><select name=jammulai id=jammulai>
            <option value=$jammul selected>$jammul</option>";
            for($i=7;$i<=17;$i++){
            if($i<=9){$i="0$i";}
            echo "<option>$i</option>";
            }
            echo "</select>
            <select name=menitmulai id=menitmulai>
            <option value=$menmul selected>$menmul</option>";
            for($i=0;$i<=59;$i++){
            if($i<=9){
            $i="0$i";
            }
            echo "<option>$i</option>";
            }
            echo "</select>
            &nbsp;s/d&nbsp;
            <select name=jamakhir id=jamakhir>
            <option value=$jamak selected>$jamak</option>";
            for($i=7;$i<=17;$i++){
            if($i<=9){$i="0$i";}
            echo "<option>$i</option>";
            }
            echo "</select>
            <select name=menitakhir id=menitakhir>
            <option value=$menak selected>$menak</option>";
            for($i=0;$i<=59;$i++){
            if($i<=9){
            $i="0$i";
            }
            echo "<option>$i</option>";
            }
            echo "</select>
            </td>
            </tr>
            <tr><td>Guru</td><td> <select id=guru name=guru class=field>";
            $tampilgur=mysql_query("SELECT * FROM karyawan a
                                      JOIN detail_mapel b ON a.id_karyawan = b.id_karyawan
                                      JOIN mapel c ON c.id_mapel = b.id_mapel ORDER BY a.nm_karyawan");
              while($w=mysql_fetch_array($tampilgur)){
                if ($r[id_karyawan]==$w[id_karyawan]){
                  echo "<option class=$w[id_mapel] value=$w[id_karyawan] selected>$w[nm_karyawan]</option>";
                }
                else{
                  echo "<option class=$w[id_mapel] value=$w[id_karyawan]>$w[nm_karyawan]</option>";
                }
              }
            echo "</select></td></tr>
          <tr><td></td><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksieditjadwal'){
  $kelas = $_POST[kelas];
  $mapel = $_POST[mapel];
  $hari = $_POST[hari];
  $tahun = $_POST[tahun];
  $jam = "$_POST[jammulai]:$_POST[menitmulai] - $_POST[jamakhir]:$_POST[menitakhir] ";
  $guru = $_POST[guru];
	$ubah = mysql_query("UPDATE jadwal SET id_karyawan = '$guru', id_kelas = '$kelas', id_mapel = '$mapel', hari = '$hari', jam = '$jam', t_ajaran = '$tahun' WHERE id_jadwal = '$_POST[id]'");
  

  if ($ubah) {
    header('location:media.php?module=tampiljadwal');
  }else{
    echo "Data gagal diubah".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif($_GET[module]=='hapusjadwal'){
  mysql_query("DELETE FROM jadwal WHERE id_jadwal='$_GET[id]' and id_kelas='$_GET[kd]'");
  echo "<script> alert('Data Berhasil dihapus');window.location='media.php?module=tampiljadwal&ke=$_GET[kd]&ta=$_GET[th]'</script>\n";
}

?>