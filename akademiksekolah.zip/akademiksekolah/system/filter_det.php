<?php
  $kel=$_GET['kelas'];
  $tah=$_GET['tahun'];

    header("location:media.php?module=detail_kelas&ke=$kel&ta=$tah");
?>