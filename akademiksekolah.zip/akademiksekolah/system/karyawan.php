
<?php

if ($_GET[module]=='karyawan'){ 
  echo "<div class='panel-heading'>
                Manajemen Data Karyawan atau Guru
                </div>
                <div class='panel-body'>";
  echo " <input class=button-submit type=button value='Tambah Karyawan' 
          onclick=\"window.location.href='media.php?module=tambahkaryawan';\">

          <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>NIP</th>
                  <th class='data'>Nama Karyawan</th>
                  <th class='data nosorting' width=130px>Action</th>
                </tr>
              </thead>
              <tbody>";
                    $sql = mysql_query("SELECT * FROM karyawan ORDER BY id_karyawan desc");
                    $no = 1;
                    while ($r=mysql_fetch_array($sql)){
          
            echo "<tr class='data'><td class='data'>$no</td>
            <td class='data'>$r[nip]</td>
            <td class='data'>$r[nm_karyawan]</td>
            <td class='data' align=center><a class=button-action href=media.php?module=editkaryawan&id=$r[id_karyawan]>Edit</a> | <a class=button-hapus href=media.php?module=hapuskaryawan&id=$r[id_karyawan] onClick=\"return confirm('Anda yakin menghapus $r[nm_karyawan]?')\">Hapus</a> | <a class=button-cetak href='cetakkaryawan.php?id=$r[id_karyawan]' target='_blank'>Cetak</a>
            </td>
          </tr>";
          $no++;
        }
        
        echo "</tbody></table></div>";

  
}elseif($_GET[module]=='tambahkaryawan'){
echo "<div class='panel-heading'>
                Tambah Data Karyawan atau Guru
                </div>
                <div class='panel-body'>";
echo "<form name='myform' method=POST action='media.php?module=aksitambahkaryawan' onSubmit='return validasi_kar()' enctype='multipart/form-data'>
          
          <table>
          <tr><td>NIP Karyawan</td><td> : <input class=field type=text name='nip' maxlength='18' onkeypress='return hanyaAngka(event)' placeholder='Masukan NIP Karyawan/Guru'></td>
          </tr>

          <tr><td>Nama Karyawan</td><td> : <input class=field type=text name='nama' maxlength='30' placeholder='Masukan Nama Karyawan/Guru'></td></tr>
          
          <tr><td>Status Sebagai</td>
          <td>: <select name='status'  class=field>
          <option value=0 selected> Pilih </option>
          <option value=guru> Guru </option>
          <option value=tu> Tata Usaha </option>
          </select></td></tr>
          
          <tr><td>Jabatan</td> <td>: <input class=field type=text name=jabatan></td></tr>
          <tr><td></td><td>: <img id=preview src=../images/camera.png width=100px></td></tr>
          <tr><td>Foto Karyawan</td><td> : <input type=file id=fupload name=fupload class=input accept='.jpg, .png'  onchange=tampilkanPreview(this,'preview') /></td></tr>
          
          <tr><td>Jenis Kelamin</td><td> : <input type=radio name=jenis value='L' checked>Laki-Laki
                                          <input type=radio name=jenis value='P'>Perempuan</td></tr>
          
          <tr><td>No Telp</td><td> : <input type=text name=telepon class=field maxlength=12 onkeypress='return hanyaAngka(event)' placeholder='Ex.08xxxxxxx'></td></tr>
          
          <tr><td>Email</td><td> : <input type=email name=email class=field placeholder='example@email.com'></td></tr>
          
          <tr><td>Pendidikan</td> <td>: <input type=text name='pendidikan' class=field placeholder='Ex. S1 Teknik Informatika'></td></tr>
          <tr><td>Agama</td>
          <td>: <select name='agama' class=field>
          <option value=0 selected> Pilih Agama</option>
          <option value=Islam>Islam</option>
          <option value=Kristen>Kristen</option>
          <option value=Hindu>Hindu</option>
          <option value=Budha>Budha</option>
          </select></td></tr>
          <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir'></td></tr>
          <tr><td>Tanggal Lahir</td><td>: <input class=field type=text readonly id=tgl_kar name='tgl_lahir'></td></tr> </td></tr>
          <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=4></textarea></td></tr>
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksitambahkaryawan'){
  $nip = $_POST[nip];
  $pass = substr($_POST[nip], 12,8);
  $nama = $_POST[nama];
  $status = $_POST[status];
  $jabatan = $_POST[jabatan];
  $file_size  = $_FILES[fupload][size];
  $max_size = 1000000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_f   = $_FILES[fupload][name];

  $acak      = "SMKN2-";
  $nama_file = ($acak.$nip.substr($nama_f, -4));
  
  $jenis = $_POST[jenis];
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];

  $tgl = $_POST[tgl_lahir];
  $pendidikan = $_POST[pendidikan];
  
  $alamat = $_POST[alamat];

  $eror   = false;
  //type file yang bisa diupload
  $file_type  = array('jpg','png');
  //cari extensi file dengan menggunakan fungsi explode
  $explode  = explode('.',$nama_file);
  $extensi  = $explode[count($explode)-1];

  $cekdata = mysql_query("SELECT nip from karyawan WHERE nip='$nip'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('NIP Sudah Ada Didalam Database');window.location='media.php?module=tambahkaryawan'</script>\n";
  }else{
  if (empty($lokasi_file)) {
      $insert = mysql_query("INSERT INTO karyawan(nip, 
                                              nm_karyawan, 
                                              status, 
                                              jabatan,
                                              email_karyawan,
                                              no_telp_karyawan,
                                              agama_karyawan,
                                              pend_karyawan,
                                              jenis_kel_karyawan,
                                              tmp_lhr_karyawan,
                                              tgl_lhr_karyawan,
                                              alamat_karyawan,
                                              pass_karyawan) 
                                              VALUES('$nip', 
                                                     '$nama', 
                                                     '$status',
                                                     '$jabatan', 
                                                     '$email',
                                                     '$tel',
                                                     '$agama',
                                                     '$pendidikan',
                                                     '$jenis',
                                                     '$tempat_lahir',
                                                     '$tgl',
                                                     '$alamat',
                                                     '$pass')");
  }/*elseif($file_size > $max_size){
    echo "<script>";
    echo "window.alert('File Gambar Terlalu Besar');window.location='media.php?module=tambahkaryawan'";
    echo "</script>";
  }*/
  //check apakah type file sudah sesuai
  if(!in_array($extensi,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai, file harus bertipe jpg, png';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo "<script> 
            onload = function(){
              alert('$pesan');onclick=self.history.back()
            return false;
            }
          </script>\n";
    //echo '<div id="eror">'.$pesan.'</div>';
  }
  else {
    move_uploaded_file($lokasi_file,"../foto_karyawan/$nama_file");
      $insert = mysql_query("INSERT INTO karyawan(nip, 
                                              nm_karyawan, 
                                              foto_karyawan,
                                              status, 
                                              jabatan,
                                              email_karyawan,
                                              no_telp_karyawan,
                                              agama_karyawan,
                                              pend_karyawan,
                                              jenis_kel_karyawan,
                                              tmp_lhr_karyawan,
                                              tgl_lhr_karyawan,
                                              alamat_karyawan,
                                              pass_karyawan)
                                                VALUES('$nip', 
                                                     '$nama', 
                                                     '$nama_file',
                                                     '$status',
                                                     '$jabatan', 
                                                     '$email',
                                                     '$tel',
                                                     '$agama',
                                                     '$pendidikan',
                                                     '$jenis',
                                                     '$tempat_lahir',
                                                     '$tgl',
                                                     '$alamat',
                                                     '$pass')");
  }

  if ($insert) {
    header('location:karyawan.html'); 
  }else{
    echo "Data gagal disimpan".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  }
  
}elseif($_GET[module]=='editkaryawan'){
  $edit=mysql_query("SELECT * FROM karyawan WHERE id_karyawan='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit Data Karyawan atau Guru
                </div>
                <div class='panel-body'>";
    echo "<form name='myform' method=POST action='media.php?module=aksieditkaryawan' onSubmit='return validasi_kar()' enctype='multipart/form-data'>
          <input type=hidden name=id value='$r[id_karyawan]'>
          <table>

          <tr><td>NIP karyawan</td><td> : <input class=field type=text name='nip' maxlength='18' value='$r[nip]' onkeypress='return hanyaAngka(event)'></td></tr>
          <tr><td>Nama karyawan</td><td> : <input class=field type=text name='nama' maxlength='30' value='$r[nm_karyawan]'></td></tr>
          <tr><td></td><td> : <img id=preview src='../foto_karyawan/$r[foto_karyawan]' width=100 height=50></td></tr>
          <tr><td>Foto karyawan</td><td> : <input type=file name=fupload class=input accept='.jpg, .png'  onchange=tampilkanPreview(this,'preview')> * kosongkan jika tidak ingin diubah</td></tr>
          <tr><td>Status</td>
          <td>: <select name='status' class=field>
          <option value=$r[status] selected> $r[status]</option>
          <option value=tu>Tata Usaha</option>
          <option value=guru>Guru</option>
          </select></td></tr>
          <tr><td>Jabatan</td><td> : <input class=field type=text name=jabatan value='$r[jabatan]'> </td></tr>";

            if ($r[jenis_kel_karyawan]=='L'){
              echo "<tr><td valign='top'>Jenis Kelamin</td>
                    <td> : <input type=radio name='jenis' value='L' checked>Laki-Laki
                         <input type=radio name='jenis' value='P'> Perempuan</td></tr>";
            }
            else{
              echo "<tr><td valign='top'>Jenis Kelamin</td>
                    <td> : <input type=radio name='jenis' value='L'>Laki-Laki  
                         <input type=radio name='jenis' value='P' checked>Perempuan</td></tr>";
            }

          echo "
          <tr><td>No Telp</td><td> : <input class=field type=text name=telepon value='$r[no_telp_karyawan]' onkeypress='return hanyaAngka(event)'></td></tr>
          <tr><td>Email</td><td> : <input class=field type=email name=email value='$r[email_karyawan]'></td></tr>
          <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan value='$r[pend_karyawan]'></td></tr>
          <tr><td>Agama</td>
          <td>: <select name='agama' class=field>
          <option value=$r[agama_karyawan] selected> $r[agama_karyawan]</option>
          <option value=Islam>Islam</option>
          <option value=Kristen>Kristen</option>
          <option value=Hindu>Hindu</option>
          <option value=Budha>Budha</option>
          </select></td></tr>
          <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir' value='$r[tmp_lhr_karyawan]'></td></tr>

          <tr><td>Tanggal Lahir</td><td> : <input class=field type=text readonly name='tgl_lahir' id=tgl_kar value='$r[tgl_lhr_karyawan]'> </td></tr>

          <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=4>$r[alamat_karyawan]</textarea></td></tr>
          <tr><td colspan=2><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksieditkaryawan'){
  $nip = $_POST[nip];
  $pass = substr($_POST[nip], 12,8);
  $nama = $_POST[nama];
  $status = $_POST[status];
  $jabatan = $_POST[jabatan];
  $file_size  = $_FILES[fupload][size];
  $max_size = 1000000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_f   = $_FILES[fupload][name];

  $acak      = "SMKN2-";
  $nama_file = ($acak.$nip.substr($nama_f, -4));

  $jenis = $_POST[jenis];
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];

  $tgl = $_POST[tgl_lahir];
  $pendidikan = $_POST[pendidikan];
  
  $alamat = $_POST[alamat];

  $eror   = false;
  //type file yang bisa diupload
  $file_type  = array('jpg','png');
  //cari extensi file dengan menggunakan fungsi explode
  $explod  = explode('.',$nama_file);
  $extens  = $explod[count($explod)-1];

  if (empty($lokasi_file)) {
    $ubah = mysql_query("UPDATE karyawan SET nip = '$nip', 
                                           nm_karyawan = '$nama', 
                                           status = '$status',
                                           jabatan = '$jabatan', 
                                           email_karyawan = '$email', 
                                           no_telp_karyawan = '$tel',  
                                           agama_karyawan = '$agama',
                                           pend_karyawan = '$pendidikan',
                                           jenis_kel_karyawan = '$jenis', 
                                           tmp_lhr_karyawan = '$tempat_lahir', 
                                           tgl_lhr_karyawan = '$tgl',
                                           alamat_karyawan = '$alamat',
                                           pass_karyawan = '$pass' 
                                           WHERE id_karyawan = '$_POST[id]'");
  }if(!in_array($extens,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai file harus bertipe jpg atau png<br />';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum<br />';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo '<div id="eror">'.$pesan.'</div>';
  }else {
      $d = '../foto_karyawan/'.$nama_file;
      unlink ("$d");
    move_uploaded_file($lokasi_file,"../foto_karyawan/$nama_file");
    $ubah = mysql_query("UPDATE karyawan SET 
                                          nip = '$nip', 
                                           nm_karyawan = '$nama', 
                                           foto_karyawan = '$nama_file',
                                           status = '$status',
                                           jabatan = '$jabatan', 
                                           email_karyawan = '$email', 
                                           no_telp_karyawan = '$tel',  
                                           agama_karyawan = '$agama',
                                           pend_karyawan = '$pendidikan',
                                           jenis_kel_karyawan = '$jenis', 
                                           tmp_lhr_karyawan = '$tempat_lahir', 
                                           tgl_lhr_karyawan = '$tgl',
                                           alamat_karyawan = '$alamat',
                                           pass_karyawan = '$pass' 
                                           WHERE id_karyawan = '$_POST[id]'");
  }

  if ($ubah) {
    header('location:karyawan.html'); 
  }else{
    echo "Data gagal diubah".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif($_GET[module]=='hapuskaryawan'){
  $hapus=mysql_query("SELECT * FROM karyawan WHERE id_karyawan='$_GET[id]'");
    $r=mysql_fetch_array($hapus);
  $d = '../foto_karyawan/'.$r[foto_karyawan];
  unlink ("$d");
  mysql_query("DELETE FROM karyawan WHERE id_karyawan='$_GET[id]'");
  header('location:karyawan.html');
}

?>
