<?php

if ($_GET[module]=='detail_kelas'){ 
$khs=mysql_query("SELECT * FROM detail_kelas a
                    JOIN kelas b ON a.id_kelas=b.id_kelas
                    JOIN jurusan c ON c.id_jurusan=b.id_jurusan where a.id_kelas=$_GET[ke] AND a.tahun_ajaran='$_GET[ta]'");
    $r = mysql_fetch_array($khs);
    echo "<div class='panel-heading'>
                Manajemen Kelas Siswa
                </div>
                <div class='panel-body'>";
  echo "<span style='float:left'>
          <input class=button-exit style='padding=30px;' type=button value='Tambah Siswa Ke Kelas' 
          onclick=\"window.location.href='media.php?module=tambah_siswa_kelas';\">

          <input class=button-submit style='padding=30px;' type=button value='Tambah Siswa Naik Kelas' 
          onclick=\"window.location.href='media.php?module=siswa_naik';\">

          <input class=button-exit style='padding=30px;' type=button value='Tambah Siswa Tidak Naik Kelas' 
          onclick=\"window.location.href='media.php?module=siswa_tidak_naik';\">
          </span><br>
            <div align=center style='padding-top:20px;'>
            <table class='data' width=100% cellpadding=6>
            <form action='filter_det.php' name=myform method=GET onSubmit='return valid_det()'>
            
              <tr align=center>
                <td>
                Jurusan : 
                  <select name=jurusan id=jursis class=kfield>
                    <option value=0 selected> Pilih jurusan </option>";
                    $kel = mysql_query("SELECT * from jurusan order by nm_jurusan");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_jurusan]==$w[id_jurusan]){
                        echo "<option value=$w[id_jurusan] selected>$w[nm_jurusan]</option>";
                      }
                       else{
                        echo "<option value=$w[id_jurusan]>$w[nm_jurusan]</option>";
                      }
                    }
                      echo "
                  </select>
                Kelas : 
                  <select name=kelas id=kelsis class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan ORDER BY a.nm_kelas");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_kelas]==$w[id_kelas]){
                        echo "<option class=$w[id_jurusan] value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                      }
                       else{
                        echo "<option class=$w[id_jurusan] value=$w[id_kelas]>$w[nm_kelas]</option>";
                      }
                    }
                      echo "
                  </select>
                  Tahun Ajaran : 
                  <select name=tahun class=kfield>
                    <option value=0 selected> Pilih Tahun </option>";
                    $k = mysql_query("SELECT DISTINCT tahun_ajaran from detail_kelas");
                    while($c=mysql_fetch_array($k)){
                      if ($r[tahun_ajaran]==$c[tahun_ajaran]){
                        echo "<option value=$c[tahun_ajaran] selected>$c[tahun_ajaran]</option>";
                      }
                       else{
                        echo "<option value=$c[tahun_ajaran]>$c[tahun_ajaran]</option>";
                      }
                    }
                      echo "
                  </select> 
                  <input class=button-hapus type=submit name=submit value='Tampilkan'>
                  </td>
                  
              </tr>
             </form>
            </table>
            </div>";
            echo "
              <input class=button-hapus type=button value='Cetak Kelas' 
                  onclick=\"window.open('cetakkelas.php?id=$_GET[ke]&th=$_GET[ta]');\">
            <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>NISN</th>
                  <th class='data'>Nama Siswa</th>
                  <th class='data nosorting' width=90px>Action</th> 
                </tr>
              </thead>
              <tbody>";
                    $kas = mysql_query("SELECT * from siswa a
                                          JOIN detail_kelas b ON b.id_siswa=a.id_siswa  where b.id_kelas=$_GET[ke] AND b.tahun_ajaran='$_GET[ta]' order by a.nm_siswa asc");
                    
                    $no = 1;
                    while ($i=mysql_fetch_array($kas)){
                       echo "<tr class='data'><td class='data'>$no</td>
                            <td class='data'>$i[nisn_siswa]</td>
                            <td class='data'>$i[nm_siswa]</td>
                            <td class='data' align=center><a class=button-action href=media.php?module=hapus_detail_kelas&id=$i[id_siswa]&kd=$i[id_kelas]&th=$i[tahun_ajaran]>Hapus</a>
            </td>
          </tr>";
          $no++;
        }
        echo "</tbody></table></div>";
}elseif ($_GET[module]=='tambah_siswa_kelas'){ 
  $i = date('Y');
  $a = $i+1;
  echo "<div class='panel-heading'>
                Manajemen Detail Kelas
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='' onSubmit='return valid_naik()'>
          <table>
            <tr>
            <td> Jurusan </td>
                  <td><select name=jurusan id=jursis class=kfield>
                    <option value=0 selected> Pilih jurusan </option>";
                    $kel = mysql_query("SELECT * from jurusan");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_jurusan]==$w[id_jurusan]){
                        echo "<option value=$w[id_jurusan] selected>$w[nm_jurusan]</option>";
                      }
                       else{
                        echo "<option value=$w[id_jurusan]>$w[nm_jurusan]</option>";
                      }
                    }
                      echo "
                  </select></td>

            <td> Kelas </td>
            <td> <select name=kelas id=kelsis class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan ORDER BY a.nm_kelas");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_kelas]==$w[id_kelas]){
                        echo "<option class=$w[id_jurusan] value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                      }
                       else{
                        echo "<option class=$w[id_jurusan] value=$w[id_kelas]>$w[nm_kelas]</option>";
                      }
                    }
                      echo "
                  </select></td>

            <td>Tahun Ajaran </td> <td> <input type=text readonly name=tahun class=kfield value=$i-$a></td></tr>
          </table>
          <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=15px>No</th>
                  <th class='data' width=80px>CEK</th>
                  <th class='data'>NISN Siswa</th>
                  <th class='data'>Nama Siswa</th>
                  <th class='data'>Kelas</th>
                </tr>
              </thead>
              <tbody>";
                $tampil=mysql_query("SELECT * from siswa where id_siswa not in
                                        (select id_siswa from detail_kelas)");
                $no = 1;
                    while ($r=mysql_fetch_array($tampil)){
                       echo "<tr class='data'><td class='data'>$no</td>
                          <td class='data'><input type='checkbox' name='no_id[]' value='$r[id_siswa]' /></td>
                          <td class='data'>$r[nisn_siswa]</td>
                          <td class='data'>$r[nm_siswa]</td>
                          <td class='data'>$r[nm_kelas]</td>
                        </tr>";
          $no++;
        }
        echo "</tbody><tr><td></td><td> <input type=checkbox name='' onclick=toggle(this);>Pilih Semua </td><td></td><td></td><td></td></tr>
                      <tr><td colspan=3><input class=button-submit type=submit name=submit value=Simpan>
                                        <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
                      </table></form></div>";

          if(isset($_POST['submit'])){
              $id_siswa=$_POST['no_id'];
                
                  foreach($id_siswa as $id){
                  $sql = "INSERT INTO detail_kelas(id_kelas, id_siswa, tahun_ajaran) values ('$_POST[kelas]', '{$id}', '$_POST[tahun]')";
                  mysql_query($sql) or die("Gagal Menyimpan Data".mysql_error());
                  echo "<script type='text/javascript'>
                document.location='detail_kelas.html';
                </script>";
                  }
            }
  
}elseif ($_GET[module]=='siswa_naik'){ 
$khs=mysql_query("SELECT * FROM detail_kelas a
                    JOIN kelas b ON a.id_kelas=b.id_kelas
                    JOIN jurusan c ON c.id_jurusan=b.id_jurusan where a.id_kelas=$_POST[kelas] AND a.tahun_ajaran='$_POST[tahun]'");
    $r = mysql_fetch_array($khs);
    echo "<div class='panel-heading'>
                Manajemen Kelas Siswa
                </div>
                <div class='panel-body'>";
  echo "<div align=center style='padding-top:20px;'>
            <table class='data' width=100% cellpadding=6>
            <form action='filter.php' name=myform method=GET onSubmit='return valid_det()'>
            
              <tr align=center>
                <td>
                Jurusan : 
                  <select name=jurusan id=jursis class=kfield>
                    <option value=0 selected> Pilih jurusan </option>";
                    $kel = mysql_query("SELECT * from jurusan order by nm_jurusan");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_jurusan]==$w[id_jurusan]){
                        echo "<option value=$w[id_jurusan] selected>$w[nm_jurusan]</option>";
                      }
                       else{
                        echo "<option value=$w[id_jurusan]>$w[nm_jurusan]</option>";
                      }
                    }
                      echo "
                  </select>
                Kelas : 
                  <select name=kelas id=kelsis class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan ORDER BY a.nm_kelas");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_kelas]==$w[id_kelas]){
                        echo "<option class=$w[id_jurusan] value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                      }
                       else{
                        echo "<option class=$w[id_jurusan] value=$w[id_kelas]>$w[nm_kelas]</option>";
                      }
                    }
                      echo "
                  </select>
                  Tahun Ajaran : 
                  <select name=tahun class=kfield>
                    <option value=0 selected> Pilih Tahun </option>";
                    $k = mysql_query("SELECT DISTINCT tahun_ajaran from detail_kelas");
                    while($c=mysql_fetch_array($k)){
                      if ($r[tahun_ajaran]==$c[tahun_ajaran]){
                        echo "<option value=$c[tahun_ajaran] selected>$c[tahun_ajaran]</option>";
                      }
                       else{
                        echo "<option value=$c[tahun_ajaran]>$c[tahun_ajaran]</option>";
                      }
                    }
                      echo "
                  </select> 
                  <input class=button-cetak type=submit name=tampil value='Tampilkan Siswa'></td>
              </tr>
             </form>
            </table>
            </div>";
            echo "</div>";
}elseif ($_GET[module]=='siswa_tidak_naik'){ 
    echo "<div class='panel-heading'>
                Manajemen Kelas Siswa
                </div>
                <div class='panel-body'>";
  echo "<div align=center style='padding-top:20px;'>
            <table class='data' width=100% cellpadding=6>
            <form action='filter_tidak.php' name=myform method=GET onSubmit='return valid_det()'>
            
              <tr align=center>
                <td>
                Jurusan : 
                  <select name=jurusan id=jursis class=kfield>
                    <option value=0 selected> Pilih jurusan </option>";
                    $kel = mysql_query("SELECT * from jurusan");
                    while($w=mysql_fetch_array($kel)){
                        echo "<option value=$w[id_jurusan]>$w[nm_jurusan]</option>";
                    }
                      echo "
                  </select>
                Kelas : 
                  <select name=kelas id=kelsis class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan ORDER BY a.nm_kelas");
                    while($w=mysql_fetch_array($kel)){
                        echo "<option class=$w[id_jurusan] value=$w[id_kelas]>$w[nm_kelas]</option>";
                    }
                      echo "
                  </select>
                  Tahun Ajaran : 
                  <select name=tahun class=kfield>
                    <option value=0 selected> Pilih Tahun </option>";
                    $k = mysql_query("SELECT DISTINCT tahun_ajaran from detail_kelas");
                    while($c=mysql_fetch_array($k)){
                        echo "<option value=$c[tahun_ajaran]>$c[tahun_ajaran]</option>";
                    }
                      echo "
                  </select> 
                  <input class=button-cetak type=submit name=tampil value='Tampilkan Siswa'></td>
              </tr>
             </form>
            </table>
            </div>";
            echo "</div>";
}elseif ($_GET[module]=='siswa_tidak_naik_kelas'){ 
$khs=mysql_query("SELECT * FROM kelas where id_kelas=$_GET[ke]");
    $r = mysql_fetch_array($khs);

  echo "<div class='panel-heading'>
                Manajemen Kelas Siswa 
                </div>
                <div class='panel-body'>";
  echo " <form action='media.php?module=siswa_tidak_naik_kelas' name=myform method=POST onSubmit='return valid_naik()'>
            
        <table>
              <tr>
                <td> Kelas </td><td>: <select name=kelas class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    if ($r[kd_kelas] == '1') {
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan where b.id_jurusan=$_GET[ju] AND a.kd_kelas=1 ORDER BY a.nm_kelas");
                    }elseif ($r[kd_kelas] == '2') {
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan where b.id_jurusan=$_GET[ju] AND a.kd_kelas=2 ORDER BY a.nm_kelas");
                    }elseif ($r[kd_kelas] == '3') {
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan where b.id_jurusan=$_GET[ju] AND a.kd_kelas=3 ORDER BY a.nm_kelas");
                    }
                    while($w=mysql_fetch_array($kel)){
                        echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                    }
                      echo "
                  </select>
                  </td></tr>
                  
                  <tr> <td> Tahun Ajaran </td><td>: <select name=tahun class=kfield>
                  <option value=0>-Pilih-</option>";
                      $i = substr($_GET[ta], 5,4);
                      $a = $i+1; 
                    echo "<option>$i-$a</option>";
                  echo "
                  </select> </td></tr>
            <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=30px>No</th>
                  <th class='data' width=80px>CEK</th>
                  <th class='data'>NISN Siswa</th>
                  <th class='data'>Nama Siswa</th>
                  <th class='data'>Kelas</th>
                </tr>
              </thead>
              <tbody>";
                    $kas = mysql_query("SELECT * from siswa a
                                          JOIN detail_kelas b ON b.id_siswa=a.id_siswa  
                                          JOIN kelas c ON c.id_kelas=b.id_kelas
                                          JOIN jurusan d ON d.id_jurusan=c.id_jurusan where b.id_kelas=$_GET[ke] AND b.tahun_ajaran='$_GET[ta]'");
                    
                    $no = 1;
                    while ($i=mysql_fetch_array($kas)){
                       echo "<tr class='data'><td class='data'>$no</td>
                          <td class='data'><input type='checkbox' name='no_id[]' value='$i[id_siswa]' /></td>
                          <td class='data'>$i[nisn_siswa]</td>
                          <td class='data'>$i[nm_siswa]</td>
                          <td class='data'>$i[nm_kelas]</td>
                        </tr>";
          $no++;
        }
        echo "</tbody>
        <tr><td></td><td> <input type=checkbox name='' onclick=toggle(this);>Pilih Semua </td><td></td><td></td><td></td></tr></table>
        <tr><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
        </table></form></div>";

         if(isset($_POST['submit'])){
              $id_siswa=$_POST['no_id'];
              $kelas=$_POST[kelas];
              $tahun=$_POST[tahun];
                  foreach($id_siswa as $id){ 
                    $cekdata = mysql_query("SELECT * from detail_kelas WHERE id_siswa='{$id}' AND tahun_ajaran='$tahun'");
                      }
                      if (mysql_num_rows($cekdata)>0) {
                        echo "<script> 
                              onload = function(){
                              alert('Siswa telah memiliki kelas ditahun ini $tahun');onclick=self.history.back()
                              return false;
                                  }
                              </script>\n";

                      }else {
                        foreach($id_siswa as $id){  
                              $sql = "INSERT INTO detail_kelas(id_kelas, id_siswa, tahun_ajaran) values ('$_POST[kelas]', '{$id}', '$_POST[tahun]')";
                              mysql_query($sql) or die("Gagal Menyimpan Data".mysql_error());
                              echo "<script type='text/javascript'>
                            document.location='detail_kelas.html';
                            </script>";
                        }
                      }
            }

}elseif ($_GET[module]=='siswa_naik_kelas'){ 
$khs=mysql_query("SELECT * FROM kelas where id_kelas=$_GET[ke]");
    $r = mysql_fetch_array($khs);

  echo "<div class='panel-heading'>
                Manajemen Kelas Siswa 
                </div>
                <div class='panel-body'>";
  echo " <form action='media.php?module=siswa_naik_kelas' name=myform method=POST onSubmit='return valid_naik()'>
            
        <table>
              <tr>
                <td> Kelas </td><td>: <select name=kelas class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    if ($r[kd_kelas] == '1') {
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan where b.id_jurusan=$_GET[ju] AND a.kd_kelas=2 ORDER BY a.nm_kelas");
                    }elseif ($r[kd_kelas] == '2') {
                    $kel = mysql_query("SELECT * from kelas a JOIN jurusan b ON b.id_jurusan = a.id_jurusan where b.id_jurusan=$_GET[ju] AND a.kd_kelas=3 ORDER BY a.nm_kelas");
                    }
                    while($w=mysql_fetch_array($kel)){
                        echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                    }
                      echo "
                  </select>
                  </td></tr>
                  
                  <tr> <td> Tahun Ajaran </td><td>: <select name=tahun class=kfield>
                  <option value=0>-Pilih-</option>";
                      $i = substr($_GET[ta], 5,4);
                      $a = $i+1; 
                    echo "<option>$i-$a</option>";
                  echo "
                  </select> </td></tr>
            <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=15px>No</th>
                  <th class='data' width=80px>CEK</th>
                  <th class='data'>NISN Siswa</th>
                  <th class='data'>Nama Siswa</th>
                  <th class='data'>Kelas</th>
                </tr>
              </thead>
              <tbody>";
                    $kas = mysql_query("SELECT * from siswa a
                                          JOIN detail_kelas b ON b.id_siswa=a.id_siswa  
                                          JOIN kelas c ON c.id_kelas=b.id_kelas
                                          JOIN jurusan d ON d.id_jurusan=c.id_jurusan where b.id_kelas=$_GET[ke] AND b.tahun_ajaran='$_GET[ta]'");
                    
                    $no = 1;
                    while ($i=mysql_fetch_array($kas)){
                       echo "<tr class='data'><td class='data'>$no</td>
                          <td class='data'><input type='checkbox' name='no_id[]' value='$i[id_siswa]' /></td>
                          <td class='data'>$i[nisn_siswa]</td>
                          <td class='data'>$i[nm_siswa]</td>
                          <td class='data'>$i[nm_kelas]</td>
                        </tr>";
          $no++;
        }
        echo "</tbody>
        <tr><td></td><td> <input type=checkbox name='' onclick=toggle(this);>Pilih Semua </td><td></td><td></td><td></td></tr></table>
        <tr><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
        </table></form></div>";

         if(isset($_POST['submit'])){
              $id_siswa=$_POST['no_id'];
              $kelas=$_POST[kelas];
              $tahun=$_POST[tahun];
                  foreach($id_siswa as $id){ 
                    $cekdata = mysql_query("SELECT * from detail_kelas WHERE id_siswa='{$id}' AND tahun_ajaran='$tahun'");
                    $cekd = mysql_query("SELECT * from detail_kelas WHERE id_kelas='$kelas' AND id_siswa='{$id}'");
                      }
                      if (mysql_num_rows($cekdata)>0) {
                        echo "<script> 
                              onload = function(){
                              alert('Siswa telah memiliki kelas ditahun ini $tahun');onclick=self.history.back()
                              return false;
                                  }
                              </script>\n";

                      }elseif (mysql_num_rows($cekd)>0) {
                        echo "<script> 
                              onload = function(){
                              alert('Siswa telah memiliki kelas ini');onclick=self.history.back()
                              return false;
                                  }
                              </script>\n";
                      }else {
                        foreach($id_siswa as $id){  
                              $sql = "INSERT INTO detail_kelas(id_kelas, id_siswa, tahun_ajaran) values ('$_POST[kelas]', '{$id}', '$_POST[tahun]')";
                              mysql_query($sql) or die("Gagal Menyimpan Data".mysql_error());
                              echo "<script type='text/javascript'>
                            document.location='detail_kelas.html';
                            </script>";
                        }
                      }
            }

}elseif($_GET[module]=='hapus_detail_kelas'){
  mysql_query("DELETE FROM detail_kelas WHERE id_siswa='$_GET[id]' and id_kelas='$_GET[kd]' and tahun_ajaran='$_GET[th]'");
  echo "<script> alert('Data Berhasil dihapus');window.location='media.php?module=detail_kelas&ke=$_GET[kd]&ta=$_GET[th]'</script>\n";
}

?>