<script language='javascript'>
    function validasi_kat(){
        var namaValid    = /^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*$/;
        var nama         = myform.nama_kategori.value;
        var pesan = '';
        
        if (nama == '') {
            pesan = '-Nama kategori tidak boleh kosong\n';
        }
        
        if (nama != '' && !nama.match(namaValid)) {
            pesan += '-nama tidak valid\n';
        }
        
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<?php

if ($_GET[module]=='kategori'){ 
  echo "<div class='panel-heading'>
                Manajemen Kategori Untuk Artikel Berita Dan Lain-Lain
                </div>
                <div class='panel-body'>
          <input class=button-submit type=button value='Tambah Kategori' 
          onclick=\"window.location.href='media.php?module=tambahkategori';\">
          <table class='data' width=100% cellpadding=6>
			<tr>
				<th class='data' width=30px>No</th>
				<th class='data'>Nama Kategori</th>
				<th class='data' align='center' width='110px;'>Action</th>
			</tr>"; 
    $tampil=mysql_query("SELECT * FROM kategori ORDER BY id_kategori DESC");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
	if(($no % 2)==0){
			$warna="#ffffff";
		  }
		  else{
			$warna="#E1E1E1";
		  }
       echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
				<td class='data'>$r[nm_kategori]</td>
				<td class='data' align=center><a class=button-action href=media.php?module=editkategori&id=$r[id_kategori]>Edit</a> | 
	               <a class=button-hapus href=media.php?module=hapuskategori&id=$r[id_kategori] onClick=\"return confirm('Anda yakin menghapus $r[nm_kategori]?')\">Hapus</a>
				</td>
			</tr>";
      $no++;
    }
    echo "</table></div>";
	
}elseif($_GET[module]=='tambahkategori'){
  echo "<div class='panel-heading'>
                Tambah Kategori
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksitambahkategori' onSubmit='return validasi_kat()'>
          <table>
          <tr><td>Nama Kategori</td><td> : <input class=field type=text name='nama_kategori'></td></tr>
          <tr><td></td><td colspan=2><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksitambahkategori'){
	$testing = $_POST[nama_kategori];
  $cekdata = mysql_query("SELECT nm_kategori from kategori WHERE nm_kategori='$testing'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('Data Sudah Ada Didalam Database');window.location='media.php?module=tambahkategori'</script>\n";
  }else{
	mysql_query("INSERT INTO kategori(nm_kategori) VALUES('$testing')");
	header('location:kategori.html');
	}
}elseif($_GET[module]=='editkategori'){
	$edit=mysql_query("SELECT * FROM kategori WHERE id_kategori='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit Kategori
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksieditkategori' onSubmit='return validasi_kat()'>
          <input type=hidden name=id value='$r[id_kategori]'>
          <table>
          <tr><td>Nama Kategori</td><td> <input class=field type=text name='nama_kategori' value='$r[nm_kategori]'></td></tr>
          <tr><td></td><td colspan=2><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksieditkategori'){
	mysql_query("UPDATE kategori SET nm_kategori = '$_POST[nama_kategori]' WHERE id_kategori = '$_POST[id]'");
  echo "<script> alert('Data berhasil diubah');window.location='kategori.html'</script>\n";
  
}elseif($_GET[module]=='hapuskategori'){
	mysql_query("DELETE FROM kategori WHERE id_kategori='$_GET[id]'");
  header('location:kategori.html');
}

?>