<?php
if($_GET[module]=='data_siswa'){
  $ed=mysql_query("SELECT * FROM siswa a
                    JOIN detail_kelas b ON b.id_siswa=a.id_siswa 
                    JOIN kelas c ON c.id_kelas=b.id_kelas WHERE a.id_siswa='$_SESSION[id]'");
    $r=mysql_fetch_array($ed);
    $stat = substr($r[nm_kelas], 0,3);

    echo "<div class='panel-heading'>
                Data Siswa
                </div>
                <div class='panel-bod'>";
    echo "<form name='myform' method=POST action='media.php?module=aksidataeditsiswa' onSubmit='return validasi_sis()' enctype='multipart/form-data'>

          <input type=hidden name=id value='$r[id_siswa]'>
            <div class='row'>
              <div class='col-lg-6'>
                    <table>
                      <tr><td>NISN siswa</td><td> : <input class=field type=text name='nisn' maxlength='10' value='$r[nisn_siswa]'></td></tr>
                      <tr><td>Nama siswa</td><td> : <input class=field type=text name='nama' maxlength='30' value='$r[nm_siswa]'></td></tr>
                      
                      <tr><td>No Telp</td><td> : <input class=field type=text name=telepon value='$r[no_telp]' maxlength=12 onkeypress='return hanyaAngka(event)'></td></tr>
                      <tr><td>Email</td><td> : <input class=field type=email name=email value='$r[email]'></td></tr>
                      <tr><td>Agama</td>
                      <td>: <select name='agama' class=field>
                      <option value=$r[agama] selected> $r[agama]</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir' value='$r[tempat_lhr]'></td></tr>

                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text readonly id='tanggal_siswa' name=tgl_siswa value='$r[tgl_lahir]'></td></tr>
                      <tr><td>Hobi</td>
                      <td>: <select name='hobi' class=field>
                      <option value=$r[hobby] selected> $r[hobby] </option>
                      <option value=Kesenian>Kesenian</option>
                      <option value=Olahraga>Olahraga</option>
                      <option value=Organisasi>Organisasi</option>
                      <option value=Lain-Lain>Lain-Lain</option>
                      </select></td></tr>
                      <tr><td>Ket. Kegemaran</td><td> : <input class=field type=text name=kegemaran value='$r[ket_hobi]'></td></tr>

                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=3>$r[alamat]</textarea></td></tr>
                      
                      <tr><td>Transportasi Ke Sekolah</td>
                      <td>: <select name='trans' class=field>
                      <option value=$r[transportasi] selected> $r[transportasi] </option>
                      <option value=Umum>Transportasi Umum</option>
                      <option value=Pribadi>Transportasi Pribadi</option>
                      </select></td></tr>
                      
                      <tr><td>Tinggi Badan</td><td> : <input class=tfield type=text name=tinggi maxlength=3 value='$r[tinggi]' onkeypress='return hanyaAngka(event)'></td></tr>
                      
                      <tr><td>Berat Badan</td><td> : <input class=tfield type=text name=berat maxlength=3 value='$r[berat]' onkeypress='return hanyaAngka(event)'></td></tr>
                      
                      <tr><td>Anak Ke</td><td> : <input class=tfield type=text name=anak maxlength=2 value='$r[anak_ke]' onkeypress='return hanyaAngka(event)'></td></tr>
                      
                      <tr><td>Password Siswa</td><td> : <input style='width: 250px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' class='form-password' type='password' name=pass value='$r[pass_siswa]' maxlength=8></td></tr>
                      <tr><td></td><td><input type='checkbox' class='form-checkbox'> Show password</td></tr>
                    </table>  
              </div>

              <div class='col-lg-4'>
                    <table>
                      <tr><td>Nama Ayah</td><td> : <input class=field type=text name=nm_ayah value='$r[nm_ayah]'></td></tr>
                      
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name=tmp_ayah value='$r[tmp_lhr_ayah]'></td></tr>
                      
                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text readonly id='tanggal' name=tgl_ayah value='$r[tgl_lhr_ayah]'></td></tr>
                      
                      <tr><td>Agama</td>
                      <td>: <select name='agama_ayah' class=field>
                      <option value=$r[agama_ayah] selected> $r[agama_ayah]</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan_ayah value='$r[pendidikan_ayah]'></td></tr>
                      
                      <tr><td>Pekerjaan</td><td> : <input class=field type=text name=pekerjaan_ayah value='$r[pekerjaan_ayah]'></td></tr>
                      
                      <tr><td>Penghasilan</td><td> : <input class=field id=peng_ayah type=text name=penghasilan_ayah value='$r[penghasilan_ayah]'></td></tr>

                      <tr><td>No Telpon</td><td> : <input class=field type=text name=telp_ayah value='$r[no_telp_ayah]' maxlength=12 onkeypress='return hanyaAngka(event)'></td></tr>
                      
                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat_ayah rows=3>$r[alamat_ayah]</textarea></td></tr>

                      <tr><td>Status Hidup</td>
                      <td>: <select name='status_ayah' class=field>
                      <option value=$r[status_hidup_ayah] selected> $r[status_hidup_ayah]</option>
                      <option value=Meniggal>Meninggal</option>
                      <option value=Hidup>Hidup</option>
                      </select></td></tr>

                    </table>
                     
                </div>
            </div>

              <table width=100% cellpadding=0>
                    <tr><td><input class=button-submit type=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
              </table>
            </form></div>";
      
}elseif($_GET[module]=='aksidataeditsiswa'){
   $nisn = $_POST[nisn];
  $nama = $_POST[nama];
  
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];
  $pass = $_POST[pass];

  $tgl=$_POST[tgl_siswa];
  
  $alamat = $_POST[alamat];
  $hobi = $_POST[hobi];
  $ket_hobi = $_POST[kegemaran];
  $trans = $_POST[trans];
  $tinggi = $_POST[tinggi];
  $berat = $_POST[berat];
  $anak = $_POST[anak];

  $ayah = $_POST[nm_ayah];
  $tmp_ayah = $_POST[tmp_ayah];
  $tgl_ayah = $_POST[tgl_ayah];
  $agama_ayah = $_POST[agama_ayah];
  $pendidikan_ayah = $_POST[pendidikan_ayah];
  $pekerjaan_ayah = $_POST[pekerjaan_ayah];
  $penghasilan_ayah = $_POST[penghasilan_ayah];
  $alamat_ayah = $_POST[alamat_ayah];
  $status_ayah = $_POST[status_ayah];
  $telp_ayah = $_POST[telp_ayah];

 if (empty($lokasi_file)) {
    $ubah = mysql_query("UPDATE siswa SET nisn_siswa = '$nisn', 
                                           nm_siswa = '$nama', 
                                           tgl_lahir = '$tgl', 
                                           tempat_lhr = '$tempat_lahir', 
                                           agama = '$agama', 
                                           no_telp = '$tel', 
                                           hobby = '$hobi', 
                                           ket_hobi = '$ket_hobi', 
                                           email = '$email', 
                                           alamat = '$alamat', 
                                           transportasi = '$trans' , 
                                           tinggi = '$tinggi', 
                                           berat = '$berat', 
                                           anak_ke = '$anak', 
                                           nm_ayah = '$ayah', 
                                           tgl_lhr_ayah = '$tgl_ayah', 
                                           tmp_lhr_ayah = '$tmp_ayah', 
                                           agama_ayah = '$agama_ayah', 
                                           pendidikan_ayah = '$pendidikan_ayah', 
                                           pekerjaan_ayah = '$pekerjaan_ayah', 
                                           penghasilan_ayah = '$penghasilan_ayah', 
                                           alamat_ayah = '$alamat_ayah', 
                                           status_hidup_ayah = '$status_ayah', 
                                           no_telp_ayah = '$telp_ayah',  
                                           no_telp_wali = '$telp_wali', 
                                           pass_siswa = '$pass'
                                           WHERE id_siswa = '$_POST[id]'");
  }elseif($file_size > $max_size){
    echo "<script>";
    echo "window.alert('File Size Gambar Terlalu Besar')";
    echo "</script>";
  }else {
    move_uploaded_file($lokasi_file,"../foto_siswa/$nama_file");
    $ubah = mysql_query("UPDATE siswa SET nisn_siswa = '$nisn', 
                                           nm_siswa = '$nama',  
                                           tgl_lahir = '$tgl', 
                                           tempat_lhr = '$tempat_lahir', 
                                           agama = '$agama', 
                                           no_telp = '$tel', 
                                           hobby = '$hobi', 
                                           ket_hobi = '$ket_hobi', 
                                           email = '$email', 
                                           alamat = '$alamat', 
                                           transportasi = '$trans',  
                                           tinggi = '$tinggi', 
                                           berat = '$berat', 
                                           anak_ke = '$anak', 
                                           nm_ayah = '$ayah', 
                                           tgl_lhr_ayah = '$tgl_ayah', 
                                           tmp_lhr_ayah = '$tmp_ayah', 
                                           agama_ayah = '$agama_ayah', 
                                           pendidikan_ayah = '$pendidikan_ayah', 
                                           pekerjaan_ayah = '$pekerjaan_ayah', 
                                           penghasilan_ayah = '$penghasilan_ayah', 
                                           alamat_ayah = '$alamat_ayah', 
                                           status_hidup_ayah = '$status_ayah', 
                                           no_telp_ayah = '$telp_ayah', 
                                           pass_siswa = '$pass'
                                           WHERE id_siswa = '$_POST[id]'");
  }

  if ($ubah) {
    header('location:data_siswa.html'); 
  }else{
    echo "Data gagal diubah. <br>".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}
?>