<?php
  $kel=$_GET['kelas'];
  $tah=$_GET['tahun'];

    header("location:media.php?module=tambah_khs_siswa&ke=$kel&ta=$tah");
?>