
<?php

if ($_GET[module]=='mapel'){ 
  echo "<div class='panel-heading'>
                Manajemen Mapel
                </div>
                <div class='panel-body'>
          <input class=button-submit type=button value='Tambah Mapel' 
          onclick=\"window.location.href='media.php?module=tambahmapel';\">
          <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <th class='data' width=30px>No</th>
                <th class='data'>Nama Mapel</th>
                <th class='data nosorting' align='center' width='180px;'>Action</th>
              </thead>
              <tbody>"; 
              $tampil=mysql_query("SELECT * FROM mapel ORDER BY nm_mapel");
              $no=1;
              while ($r=mysql_fetch_array($tampil)){
            if(($no % 2)==0){
                $warna="#ffffff";
                }
                else{
                $warna="#E1E1E1";
                }
                 echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
                  <td class='data'>$r[nm_mapel]</td>
                  <td class='data' align=center><a class=button-cetak href=media.php?module=lihatgurumapel&id=$r[id_mapel]>Guru Pengajar</a> | 
                                    <a class=button-action href=media.php?module=editmapel&id=$r[id_mapel]>Edit</a> | 
                                      <a class=button-hapus href=media.php?module=hapusmapel&id=$r[id_mapel] onClick=\"return confirm('Anda yakin menghapus $r[nm_mapel]?')\">Hapus</a>
                  </td>
                </tr>";
                $no++;
              }
              echo "</tbody></table></div>";
  
}elseif($_GET[module]=='tambahmapel'){
  echo "<div class='panel-heading'>
                Tambah Mapel
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksitambahmapel' onSubmit='return validasi_map()'>
          <table>
          <tr><td>Nama mapel</td><td> <input class=field type=text name='nama_mapel'></td></tr>
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksitambahmapel'){
  $testing = $_POST[nama_mapel];

  $cekdata = mysql_query("SELECT nm_mapel from mapel WHERE nm_mapel='$testing'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('Data Sudah Ada Didalam Database');window.location='media.php?module=tambahmapel'</script>\n";
  }else{
      mysql_query("INSERT INTO mapel(nm_mapel) VALUES('$testing')");
      echo "<script> alert('Data Berhasi Disimpan');window.location='mapel.html'</script>\n"; 
  }
  
}elseif($_GET[module]=='editmapel'){
  $edit=mysql_query("SELECT * FROM mapel WHERE id_mapel='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit Mapel
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksieditmapel' onSubmit='return validasi_map()'>
          <input type=hidden name=id value='$r[id_mapel]'>
          <table>
          <tr><td>Nama mapel</td><td> <input class=field type=text name='nama_mapel' value='$r[nm_mapel]'></td></tr>
          <tr><td></td><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksieditmapel'){
  $ubah = mysql_query("UPDATE mapel SET nm_mapel = '$_POST[nama_mapel]' WHERE id_mapel = '$_POST[id]'");
  
  if ($ubah) {
    header('location:mapel.html'); 
  }else{
    echo "Data gagal diubah".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif ($_GET[module]=='lihatgurumapel'){ 
  echo "<div class='panel-heading'>
                Manajemen Guru Mapel
                </div>
                <div class='panel-body'>";

            $mpl=mysql_query("SELECT * FROM mapel WHERE id_mapel='$_GET[id]'");
      $y=mysql_fetch_array($mpl);
          echo "
          <input class=button-submit type=button value='Tambah Guru' 
          onclick=\"window.location.href='media.php?module=tambahgurumapel&id=$y[id_mapel]';\">
          <input class=button-exit type=button value='Kembali' 
          onclick=\"window.location.href='mapel.html';\">

          <div align=center style='font-size:18px; font-weight:bold; padding-bottom:10px;'> Mata Pelajaran  : $y[nm_mapel]</div>
          <table class='data' width=100% cellpadding=6>
      <tr>
        <th class='data' width=30px>No</th>
        <th class='data'>NIP</th>
        <th class='data'>Nama Guru</th>
        <th class='data' align='center' width='100px;'>Action</th>
      </tr>"; 

    $tampil=mysql_query("SELECT * from karyawan a
                            join detail_mapel b ON a.id_karyawan = b.id_karyawan
                            join mapel c ON c.id_mapel = b.id_mapel
                            where c.id_mapel = '$_GET[id]' order by c.id_mapel");
    $no=1;
    while ($t=mysql_fetch_array($tampil)){
     if(($no % 2)==0){
      $warna="#ffffff";
      }
      else{
      $warna="#E1E1E1";
      }
       echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
        <td class='data'>$t[nip]</td>
        <td class='data'>$t[nm_karyawan]</td>
        <td class='data' align=center><a class=button-hapus href=media.php?module=hapus_detail_mapel&id=$t[id_karyawan]&kd=$t[id_mapel] onClick=\"return confirm('Anda yakin menghapus $t[nm_karyawan]?')\">Hapus</a>
        </td>
      </tr>";
      $no++;
    }
    echo "</table></div>";
  
}elseif($_GET[module]=='tambahgurumapel'){

  echo "<div class='panel-heading'>
                Manajemen Guru Pengajar
                </div>
                <div class='panel-body'>";

      $add=mysql_query("SELECT * FROM mapel WHERE id_mapel='$_GET[id]'");
      $q=mysql_fetch_array($add);
          echo "
          <div style='font-size:16px; font-weight:bold;'> Tambah Guru Untuk Mata Pelajaran : $q[nm_mapel]</div>
          <form name='myform' method=POST action=''>
          <table class='data' width=100% cellpadding=6>
      <tr>
        <th class='data' width=30px>No</th>
        <th class='data' width=30px>CEK</th>
        <th class='data'>NIP</th>
        <th class='data'>Nama Guru</th>
      </tr>"; 
    $tampil=mysql_query("SELECT * from karyawan where id_karyawan not in
                            (select id_karyawan from detail_mapel where id_mapel='$_GET[id]')
                            AND status = 'guru'");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
     if(($no % 2)==0){
      $warna="#ffffff";
      }
      else{
      $warna="#E1E1E1";
      }
       echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
        <td class='data'><input type='checkbox' name='no_id[]' value='$r[id_karyawan]' /></td>
        <td class='data'>$r[nip]</td>
        <td class='data'>$r[nm_karyawan]</td>
      </tr>";
      $no++;
    }
    echo "<tr><td></td></tr>
          <tr><td colspan=3><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";

          if(isset($_POST['submit'])){
              $id_siswa=$_POST['no_id'];
                if(empty($id_siswa)){
                echo "<script type='text/javascript'>
                onload =function(){
                alert('Tidak ada guru yang dipilih !!');
                }
                </script>";
                }else{
                  foreach($id_siswa as $id){
                  $sql = "INSERT INTO detail_mapel(id_karyawan, id_mapel) values ('{$id}', '$_GET[id]')";
                  mysql_query($sql) or die("Gagal Menyimpan Data".mysql_error());
                  echo "<script type='text/javascript'>
                document.location='media.php?module=lihatgurumapel&id=$_GET[id]';
                </script>";
                  }
                }
            }
      
}elseif($_GET[module]=='hapusmapel'){
  $cekdata = mysql_query("SELECT id_mapel from jadwal WHERE id_mapel='$_GET[id]'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('Mata Pelajaran Ada didalam jadwal, Tidak boleh terhapus');window.location='mapel.html'</script>\n";
  }else{
    mysql_query("DELETE FROM mapel WHERE id_mapel='$_GET[id]'");
    header('location:mapel.html');
    }
}elseif($_GET[module]=='hapus_detail_mapel'){
  mysql_query("DELETE FROM detail_mapel WHERE id_karyawan='$_GET[id]' and id_mapel='$_GET[kd]'");
  echo "<script> alert('Data Berhasil dihapus');window.location='media.php?module=lihatgurumapel&id=$_GET[kd]'</script>\n";
}

?>