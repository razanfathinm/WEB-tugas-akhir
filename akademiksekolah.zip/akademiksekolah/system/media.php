<?php  
  session_start();	
  error_reporting(0);
  include "../config/koneksi.php";
  include "../config/session_admin.php";
  include "../config/session_member.php";
?>
<html>
<head>
<title>Sistem Informasi Akademik</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="../style/admin.css">
	<link rel="stylesheet" type="text/css" href="../style/paging.css">
	<link rel="stylesheet" type="text/css" href="../style/colom.css">
	<link rel="stylesheet" type="text/css" href="../style/media-queries.css" />
	<link type="text/css" rel="stylesheet" href="../js/calender/themes/ui-lightness/ui.all.css" />
	<link rel="stylesheet" type="text/css" href="../style/css/jquery.dataTables.css">
</head>

<body>
<div id="header">
	<div class="inHeader">
		<div class="mosAdmin">
		Hallo, <?php echo "$_SESSION[namauser]"; ?><br>
		<a target='_BLANK' href="#">Help</a> | <a href="../logout.php">Keluar</a>
		</div>
		<div class="clear"></div>
	</div>
</div>

<div id="wrapper">

        <div class='col-lg-2'>
            <div class='panel panel-default'>
                <div class='panel-heading'>
                    Profil
                </div>
        		<div class='panel-body'>
        			<div align="center">
        				<?php
							$nip = $_SESSION[nip];
							$nisn = $_SESSION[nisn];
							$admin = $_SESSION[namauser];
							if ($nip) {	
								$sql=mysql_query("SELECT * FROM karyawan WHERE nip = '$nip'");
								$t=mysql_fetch_array($sql);
								echo "<img src='../foto_karyawan/$t[foto_karyawan]' width=150px/><br>";	
							}elseif ($nisn) {	
								$sql=mysql_query("SELECT * FROM siswa WHERE nisn_siswa = '$nisn'");
								$t=mysql_fetch_array($sql);
								echo "<img src='../foto_siswa/$t[foto_siswa]' width=150px/><br>";	
							}elseif ($admin) {
								echo "<img src=../style/img/admin.ico width=150px><br>";
							}
								?>
        				
        				<h3><?php echo "$_SESSION[namauser]"; ?></h3>
        				<a href="../logout.php">Logout</a>
        			</div>
                      
              	</div>
            </div>

            <div class='panel panel-default'>
                <div class='panel-heading'>
                    Data
                </div>
        		<div class='panel-body'>
        			<div align="left">
        				<div class="menu-kiri">
							<?php
								if ($_SESSION['leveluser'] == 'guru'){
									echo "<ul>
											<li><a href=index.php>Dashboard</a></li>
											<li><a href='data_guru.html'>Data Guru</a></li>
										    <li><a href='learning.html'>Learning</a></li>
										    <li><a href='nilai_siswa.html'>Nilai</a></li>
										  </ul>";
								}elseif ($_SESSION['leveluser'] == 'tu') {
									echo "<ul>
											<li><a href=index.php>Dashboard</a></li>
											<li><a href='data_guru.html'>Data Anda</a></li>
										   <li><a href='mapel.html'>Mapel</a></li>
										</ul>";
								}elseif ($_SESSION['leveluser'] == 'aktif') {
									echo "<ul>
											<li><a href=index.php>Dashboard</a></li>
											<li><a href='data_siswa.html'>Data Siswa</a></li>
										   <li><a href='khs_siswa.html'>KHS</a></li>
										   <li><a href='jadwal.html'>Jadwal Pelajaran</a></li>
										</ul>";
								}else {
									echo "<ul>
											<li><a href=index.php>Dashboard</a></li>
										   <li><a href='kategori.html'>Kategori</a></li>
										   <li><a href='jurusan.html'>Jurusan</a></li>
										   <li><a href='kelas.html'>Kelas</a></li>
										   <li><a href='mapel.html'>Mapel</a></li>
										   <li><a href='user.html'>ADMIN</a></li>
										</ul>";
								}
							?>
        				</div>
        				
        			</div>
                      
              	</div>
            </div>
        </div>

        <div class='col-lg-9'>
            <div class='panel panel-default'>
            		<?php include "kiri.php"; ?>
            </div>
        </div>

        <div class='col-lg-2'>
            
        </div>
 </div>

<?php
/*
	<div id="leftBar">
	<ul>
		<li class="curen"><a href="index.php">Dashboard</a></li>
		<?php 
			if ($_SESSION['leveluser'] == 'admin'){
				echo "<li><a href='siswa.html'>Siswa</a></li>
					   <li><a href='kategori.html'>Kategori</a></li>
					   <li><a href='berita.html'>Berita dan Artikel</a></li>
					   <li><a href='jurusan.html'>Jurusan</a></li>
					   <li><a href='kelas.html'>Kelas</a></li>
					   <li><a href='mapel.html'>Mapel</a></li>
					   <li><a href='alumni.html'>Alumni</a></li>
					   <li><a href='karyawan.html'>Karyawan/Guru</a></li>
					   <li><a href='learning.html'>Learning</a></li>
					  ";
			}elseif ($_SESSION['leveluser'] == 'guru'){
				echo "<li><a href='karyawan.html'>Karyawan/Guru</a></li>
					   <li><a href='learning.html'>Learning</a></li>
					  ";
			}else{
				echo " <li><a href='kategori.html'>Kategori</a></li>
					   <li><a href='berita.html'>Berita dan Artikel</a></li>
					   <li><a href='jurusan.html'>Jurusan</a></li>
					   <li><a href='kelas.html'>Kelas</a></li>
					   <li><a href='mapel.html'>Mapel</a></li>
					   <li><a href='alumni.html'>Alumni</a></li>
					   <li><a href='karyawan.html'>Karyawan</a></li>
					   <li><a href='learning.html'>Learning</a></li>
					   <li><a href='#'>Blalala</a></li>
					   <li><a href='#'>Blalala</a></li>
					   <li><a href='#'>Blalala</a></li>
					   <li><a href='#'>Blalala</a></li>";
			}
			
		?>
		<li><a href="../logout.php">Logout</a></li>
	</ul>
	</div>
	<div id="rightContent">
		<?php include "kiri.php"; ?>
	</div>
</div>
*/
?>
<div class="clear"></div>
	<?php
	include "validasi.php";
	?>
<script src="../style/js/jquery.min.js"></script>
<script src="jquery.maskMoney.min.js"></script>
<script type="text/javascript" src="../style/js/jquery.dataTables.min.js"></script>
<script src="../js/calender/ui/ui.core.js"></script>
<script src="../js/calender/ui/ui.datepicker.js"></script>
<script src="../js/calender/ui/i18n/ui.datepicker-id.js"></script>

<script>
   $(document).ready(function(){
    $("#tanggal").datepicker({
    	dateFormat : "yy-mm-dd",
		changeMonth : true,
		changeYear : true,
		yearRange: "1990:2017"
    });
    $("#tanggal_ibu").datepicker({
    	dateFormat : "yy-mm-dd",
		changeMonth : true,
		changeYear : true,
		yearRange: "1990:2017"
    });
    $("#tanggal_wali").datepicker({
    	dateFormat : "yy-mm-dd",
		changeMonth : true,
		changeYear : true,
		yearRange: "1990:2017"
    });
    $("#tanggal_siswa").datepicker({
    	dateFormat : "yy-mm-dd",
		changeMonth : true,
		changeYear : true,
		yearRange: "1990:2017"
    });
    $("#tgl_kar").datepicker({
    	dateFormat : "yy-mm-dd",
		changeMonth : true,
		changeYear : true,
		yearRange: "1990:2017"
    });
    $("#tgl_al").datepicker({
    	dateFormat : "yy-mm-dd",
		changeMonth : true,
		changeYear : true,
		yearRange: "1990:2017"
    });
   })
   $(document).ready(function() {
       $('#data').DataTable();
    } );

   $(document).ready(function(){
	$('#peng_ayah').maskMoney({prefix:'Rp. ', thousands:'.', decimal:',', precision:0});
	$('#peng_ibu').maskMoney({prefix:'Rp. ', thousands:'.', decimal:',', precision:0});
	$('#peng_wali').maskMoney({prefix:'Rp. ', thousands:'.', decimal:',', precision:0});
	});

   $(document).ready(function(){		
		$('.form-checkbox').click(function(){
			if($(this).is(':checked')){
				$('.form-password').attr('type','text');
			}else{
				$('.form-password').attr('type','password');
			}
		});
	});
  </script>

<script src="jquery.chained.min.js"></script>
<script>
    $("#guru").chained("#mapel");
</script>
<script>
    $("#kelsis").chained("#jursis");
</script>

<script>
	function hanyaAngka(evt) {
		  var charCode = (evt.which) ? evt.which : event.keyCode
		   if (charCode > 31 && (charCode < 48 || charCode > 57))
		    return false;
		  return true;
	}
</script>


</body>

</html>