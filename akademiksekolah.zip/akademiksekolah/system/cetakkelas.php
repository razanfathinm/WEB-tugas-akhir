<?php
define('FPDF_FONTPATH','../fpdf//font/');
require('../fpdf/fpdf.php');

class PDF extends FPDF
{
	
	//Page Content
	function Content()
	{
		//Logo
		$this->Image('logo-tebo.png',10,8);
		//Arial bold 15
		$this->SetFont('Arial','',11);
		//pindah ke posisi ke tengah untuk membuat judul
		$this->Cell(80);
		//judul
		$this->Cell(40,3,'PEMERINTAH KABUPATEN TEBO',0,0,'C');
		$this->ln(5);
		$this->Cell(80);
		$this->Cell(40,3,'DINAS PENDIDIKAN KEBUDAYAAN PEMUDA DAN OLAHRAGA',0,0,'C');
		//pindah baris
		$this->Ln(5);
		$this->SetFont('Arial','B',12);
		$this->Cell(80);
		$this->Cell(40,3,'SMK NEGERI 2 KABUPATEN TEBO',0,0,'C');

		//pindah baris
		$this->ln(5);
		$this->SetFont('Arial','',9);
		$this->Cell(80);
		$this->Cell(40,3,'Jalan M. Hatta, Kel. Wirotho Agung, Kec. Rimbo Bujang, Kab. Tebo, JAMBI Telp/Fax 0747-431895',0,0,'C');
		
		//pindah baris
		$this->Ln(10);
		//buat garis horisontal
		$this->Line(10,32,200,32);
		//pindah baris
		

		//end of header

		include "../config/koneksi.php";
			$Lapor = "SELECT a.nisn_siswa, a.nm_siswa, a.jenis_kelamin, a.tgl_lahir FROM siswa a
						JOIN detail_kelas b ON b.id_siswa=a.id_siswa 
						JOIN kelas c ON c.id_kelas=b.id_kelas
						where b.id_kelas='$_GET[id]' AND b.tahun_ajaran='$_GET[th]' ORDER BY a.nisn_siswa ASC";
			$lap = "SELECT * from kelas where id_kelas='$_GET[id]'";
			$Hasil = mysql_query($Lapor);
			$kelas= mysql_query($lap);
			$Data = array();
			$r = mysql_fetch_array($kelas);
			$t = array($r[1]);
			$i = 0;
 
			 while($d=mysql_fetch_array($Hasil)){
			  $cell[$i][0]=$d[0];
			  $cell[$i][1]=$d[1];
			  $cell[$i][2]=$d[2];
			  $cell[$i][3]=$d[3];
			  $i++;
			 }

		$this->SetFont('Arial','B',12);
		$this->Cell(60);
		$this->Cell(40,3,'Laporan Data Kelas',0,0,'C');
		foreach ($t as $kel){
			$this->Cell(40,3,$kel);
		}
		
		//pindah baris
		$this->Ln(10);

		$this->SetFont('arial','B','11');
		$this->SetFillColor(204,204,200);
		$this->SetTextColor(0);
		$this->setDrawColor(205);
		 $this->Cell(10,8,'No','TB',0,'L',1); 
		   $this->Cell(40,8,'NISN','TB',0,'L',1); 
		   $this->Cell(60,8,'Nama Siswa','TB',0,'L',1); 
		   $this->Cell(30,8,'Jenis Kelamin','TB',0,'L',1);
		   $this->Cell(50,8,'Tanggal Lahir','TB',0,'L',1); 
		$this->Ln();
		//menampilkan data
		$this->SetFont('arial','','9');
		//perulangan untuk membuat tabel
				 for($j=0;$j<$i;$j++){
				  $this->Cell(10,7,$j+1,'B',0,'C');
				  $this->Cell(40,7,$cell[$j][0],'B',0,'L');
				  $this->Cell(60,7,$cell[$j][1],'B',0,'L');
				  $this->Cell(30,7,$cell[$j][2],'B',0,'C');
				  $this->Cell(50,7,$cell[$j][3],'B',0,'L');
				  $this->Ln();
				 }
				
			$this->Ln();
		


	}

	//Page footer
	function Footer()
	{
		//atur posisi 1.5 cm dari bawah
		$this->SetY(-15);
		//buat garis horizontal
		$this->Line(10,$this->GetY(),200,$this->GetY());
		//Arial italic 9
		$this->SetFont('Arial','I',9);
		//nomor halaman
		$this->Cell(0,10,'Halaman '.$this->PageNo().' dari {nb}',0,0,'R');
	}
}

//contoh pemanggilan class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Content();
$pdf->Output();
?>