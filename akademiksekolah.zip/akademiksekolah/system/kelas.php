

<?php

if ($_GET[module]=='kelas'){ 
  echo "<div class='panel-heading'>
                Manajemen Kelas
                </div>
                <div class='panel-body'>
          <input class=button-submit type=button value='Tambah Kelas' 
          onclick=\"window.location.href='media.php?module=tambahkelas';\"> <p style='font-size:18; color:red'> * Peringatan !! jika kelas terhapus maka seluruh data yang berhubungan dengan kelas tersebut akan ikut terhapus</p>
          <table class='data' width=100% cellpadding=6>
			<tr>
				<th class='data' width=30px>No</th>
				<th class='data'>Nama kelas</th>
				<th class='data' align='center' width='100px;'>Action</th>
			</tr>"; 
    $tampil=mysql_query("SELECT * FROM kelas ORDER BY nm_kelas ASC");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
	if(($no % 2)==0){
			$warna="#ffffff";
		  }
		  else{
			$warna="#E1E1E1";
		  }
       echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
				<td class='data'>$r[nm_kelas]</td>
				<td class='data' align=center><a class=button-action href=media.php?module=editkelas&id=$r[id_kelas]>Edit</a> | 
	               <a class=button-hapus href=media.php?module=hapuskelas&id=$r[id_kelas] onClick=\"return confirm('Anda yakin menghapus $r[nm_kelas]?')\">Hapus</a>
				</td>
			</tr>";
      $no++;
    }
    echo "</table></div>";
	
}elseif($_GET[module]=='tambahkelas'){
  echo "<div class='panel-heading'>
                Tambah Kelas
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksitambahkelas' onSubmit='return validasi_kel()'>
          <table>
          <tr><td>Nama kelas</td><td> : <input class=field type=text name='nama_kelas' placeholder='Ex. X Multimedia 1'></td></tr>

          <tr><td>Kode kelas</td><td> : <select name='kd_kelas' class=field >
                      <option value=0 selected> Kode Kelas</option>
                      <option value=1>01 >untuk> Kelas X</option>
                      <option value=2>02 >untuk> Kelas XI</option>
                      <option value=3>03 >untuk> Kelas XII</option>
                      </select></td></tr>
          <tr>
          <td>Jurusan</td><td> 
              : <select name=jurusan  class=field>
                <option value=0 selected> Pilih Jurusan </option>";
                
                  $jur=mysql_query("SELECT * FROM jurusan ORDER BY nm_jurusan");
                    while($vr=mysql_fetch_array($jur)){
                      echo "<option value=$vr[id_jurusan]>$vr[nm_jurusan]</option>";
                    }
                      echo "</select></td></tr>
          <tr><td></td><td colspan=2><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksitambahkelas'){
	$testing = $_POST[nama_kelas];
  $kode = $_POST[kd_kelas];
	$jurusan = $_POST[jurusan];
  $cekdata = mysql_query("SELECT nm_kelas from kelas WHERE nm_kelas='$testing'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('Data Sudah Ada Didalam Database');window.location='media.php?module=tambahkelas'</script>\n";
  }else{
  mysql_query("INSERT INTO kelas(kd_kelas,nm_kelas,id_jurusan) VALUES('$kode','$testing','$jurusan')");
	header('location:kelas.html');
	}
}elseif($_GET[module]=='editkelas'){
	$edit=mysql_query("SELECT * FROM kelas WHERE id_kelas='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit Kelas
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksieditkelas' onSubmit='return validasi_kel()'>
          <input type=hidden name=id value='$r[id_kelas]'>
          <table>
          <tr><td>Nama kelas</td><td> : <input class=field type=text name='nama_kelas' value='$r[nm_kelas]'></td></tr>
          <tr><td>Kode kelas</td><td> : <select name='kd_kelas' class=field >
                      <option value=$r[kd_kelas] selected> $r[kd_kelas]</option>
                      <option value=1>01 >untuk> Kelas X</option>
                      <option value=2>02 >untuk> Kelas XI</option>
                      <option value=3>03 >untuk> Kelas XII</option>
                      </select></td></tr>

          <tr><td>Jurusan</td><td> : <select name=jurusan class=field>";
 
                          $tampil=mysql_query("SELECT * FROM jurusan ORDER BY nm_jurusan");
                            while($w=mysql_fetch_array($tampil)){
                              if ($r[id_jurusan]==$w[id_jurusan]){
                                echo "<option value=$w[id_jurusan] selected>$w[nm_jurusan]</option>";
                              }
                              else{
                                  echo "<option value=$w[id_jurusan]>$w[nm_jurusan]</option>";
                              }
                          }
                  echo "</select></td></tr>
          <tr><td></td><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksieditkelas'){
	mysql_query("UPDATE kelas SET kd_kelas = '$_POST[kd_kelas]', nm_kelas = '$_POST[nama_kelas]', id_jurusan = '$_POST[jurusan]' WHERE id_kelas = '$_POST[id]'");
  header('location:kelas.html');
}elseif($_GET[module]=='hapuskelas'){
	mysql_query("DELETE FROM kelas WHERE id_kelas='$_GET[id]'");
  header('location:kelas.html');
}

?>