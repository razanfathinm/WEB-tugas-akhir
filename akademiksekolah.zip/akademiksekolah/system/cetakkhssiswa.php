<?php
define('FPDF_FONTPATH','../fpdf//font/');
require('../fpdf/fpdf.php');

class PDF extends FPDF
{
	
	//Page Content
	function Content()
	{
		//Logo
		$this->Image('logo-tebo.png',10,8);
		//Arial bold 15
		$this->SetFont('Arial','',11);
		//pindah ke posisi ke tengah untuk membuat judul
		$this->Cell(80);
		//judul
		$this->Cell(40,3,'PEMERINTAH KABUPATEN TEBO',0,0,'C');
		$this->ln(5);
		$this->Cell(80);
		$this->Cell(40,3,'DINAS PENDIDIKAN KEBUDAYAAN PEMUDA DAN OLAHRAGA',0,0,'C');
		//pindah baris
		$this->Ln(5);
		$this->SetFont('Arial','B',12);
		$this->Cell(80);
		$this->Cell(40,3,'SMK NEGERI 2 KABUPATEN TEBO',0,0,'C');

		//pindah baris
		$this->ln(5);
		$this->SetFont('Arial','',9);
		$this->Cell(80);
		$this->Cell(40,3,'Jalan M. Hatta, Kel. Wirotho Agung, Kec. Rimbo Bujang, Kab. Tebo, JAMBI Telp/Fax 0747-431895',0,0,'C');
		
		//pindah baris
		$this->Ln(10);
		//buat garis horisontal
		$this->Line(10,32,200,32);
		//pindah baris
		

		//end of header

		include "../config/koneksi.php";
			$Lapor = "SELECT a.nm_mapel, d.nilai from mapel a 
					JOIN khs d ON d.id_mapel=a.id_mapel where d.id_siswa=$_GET[id] AND d.semester='$_GET[se]' AND d.thn_ajaran='$_GET[th]'";
			$lap = "SELECT a.nisn_siswa, UPPER (a.nm_siswa), UPPER (b.nm_kelas), UPPER(c.nm_jurusan), UPPER(d.semester), d.thn_ajaran from siswa a 
					JOIN detail_kelas e ON e.id_siswa=a.id_siswa
					JOIN kelas b ON b.id_kelas=e.id_kelas
					JOIN jurusan c ON c.id_jurusan=b.id_jurusan
					JOIN khs d ON d.id_siswa=a.id_siswa where d.id_siswa=$_GET[id] AND d.semester='$_GET[se]' AND d.thn_ajaran='$_GET[th]'";
			$rata=mysql_query("SELECT AVG (nilai) AS rata FROM khs WHERE id_siswa=$_GET[id] AND semester='$_GET[se]' AND thn_ajaran='$_GET[th]'");
    		$tara = mysql_fetch_array($rata);
    		$tar = array($tara[0]);

			$Hasil = mysql_query($Lapor);
			$kelas= mysql_query($lap);
			$Data = array();
			$r = mysql_fetch_array($kelas);
			$nisn = array($r[0]);
			$nama = array($r[1]);
			$kelas = array($r[2]);
			$jur = array($r[3]);
			$sem = array($r[4]);
			$th = array($r[5]);
			$i = 0;
 
			 while($d=mysql_fetch_array($Hasil)){
			  $cell[$i][0]=$d[0];
			  $cell[$i][1]=$d[1];
			  $i++;
			 }

		$this->SetFont('Arial','B',12);
		$this->Cell(60);
		$this->Cell(60,3,'Laporan Data KHS',0,0,'C');
		
		//pindah baris
		$this->Ln(10);

		$this->SetFont('Arial','',10);

		$this->Cell(25,3,'Nama',0,0,'L');
		foreach ($nama as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(6);

		$this->Cell(25,3,'NISN',0,0,'L');
		foreach ($nisn as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(6);

		$this->Cell(25,3,'Kelas',0,0,'L');
		foreach ($kelas as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(6);

		$this->Cell(25,3,'Jurusan',0,0,'L');
		foreach ($jur as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(6);

		$this->Cell(25,3,'Semester',0,0,'L');
		foreach ($sem as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(6);

		$this->Cell(25,3,'Tahun Ajaran',0,0,'L');
		foreach ($th as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		//pindah baris
		$this->Ln(10);

		$this->Cell(20);
		$this->SetFont('arial','B','11');
		$this->SetFillColor(204,204,200);
		$this->SetTextColor(0);
		$this->setDrawColor(205);
		 $this->Cell(15,8,'No','TB',0,'C',1); 
		   $this->Cell(100,8,'Mata Pelajaran','TB',0,'C',1); 
		   $this->Cell(30,8,'Nilai','TB',0,'C',1);  
		$this->Ln();
		//menampilkan data
		$this->SetFont('arial','','9');
		//perulangan untuk membuat tabel
				 for($j=0;$j<$i;$j++){
				 	$this->Cell(20);
				  $this->Cell(15,7,$j+1,'B',0,'C');
				  $this->Cell(100,7,$cell[$j][0],'B',0,'L');
				  $this->Cell(30,7,$cell[$j][1],'B',0,'C');
				  $this->Ln();
				 }
				
			$this->Ln();
			$this->Cell(127);
			$this->Cell(20,3,'Rata-Rata',0,0,'L');
				foreach ($tar as $kel){
					$this->Cell(30,3,$kel);
			}
	}


		

	//Page footer
	function Footer()
	{
		//atur posisi 1.5 cm dari bawah
		$this->SetY(-15);
		//buat garis horizontal
		$this->Line(10,$this->GetY(),200,$this->GetY());
		//Arial italic 9
		$this->SetFont('Arial','I',9);
		//nomor halaman
		$this->Cell(0,10,'Halaman '.$this->PageNo().' dari {nb}',0,0,'R');
	}
}

//contoh pemanggilan class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Content();
$pdf->Output();
?>