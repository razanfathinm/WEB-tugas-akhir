<?php
  $jur=$_GET['jurusan'];
  $kel=$_GET['kelas'];
  $tah=$_GET['tahun'];

    header("location:media.php?module=siswa_naik_kelas&ju=$jur&ke=$kel&ta=$tah");
?>