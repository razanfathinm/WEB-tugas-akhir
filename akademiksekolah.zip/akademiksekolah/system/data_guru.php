
<?php

if ($_GET[module]=='data_guru'){ 
  echo "<div class='panel-heading'>
                Data Guru
                </div>
                <div class='panel-body'>";
  $edit=mysql_query("SELECT * FROM karyawan WHERE nip='$_SESSION[nip]'");
    $r=mysql_fetch_array($edit);
    $tgl = substr($r[tgl_lhr_karyawan], 8,2);
    $bulan = substr($r[tgl_lhr_karyawan], 5,2);
    $thn = substr($r[tgl_lhr_karyawan], 0,4);
    echo "<form name='myform' method=POST action='media.php?module=aksieditguru' onSubmit='return validasi_kar()' enctype='multipart/form-data'>
          <input type=hidden name=id value='$r[id_karyawan]'>
          <table>

          <tr><td>NISN karyawan</td><td> : <input class=field type=text name='nip' maxlength='20' value='$r[nip]'></td></tr>
          <tr><td>Nama karyawan</td><td> : <input type=text class=field name='nama' maxlength='30' value='$r[nm_karyawan]'></td></tr>
          <tr><td></td><td> : <img src='../foto_karyawan/$r[foto_karyawan]' width=100 height=50></td></tr>
          <tr><td>Foto karyawan</td><td> : <input type=file name=fupload> * kosongkan jika tidak ingin diubah</td></tr>
          <tr><td>Jabatan</td><td> : <input class=field type=text readonly size=30px name=jabatan value='$r[jabatan]'> </td></tr>";

            if ($r[jenis_kel_karyawan]=='L'){
              echo "<tr><td valign='top'>Jenis Kelamin</td>
                    <td> : <input type=radio name='jenis' value='L' checked>Laki-Laki
                         <input type=radio name='jenis' value='P'> Perempuan</td></tr>";
            }
            else{
              echo "<tr><td valign='top'>Jenis Kelamin</td>
                    <td> : <input type=radio name='jenis' value='L'>Laki-Laki  
                         <input type=radio name='jenis' value='P' checked>Perempuan</td></tr>";
            }

          echo "
          <tr><td>No Telp</td><td> : <input type=text class=field name=telepon value='$r[no_telp_karyawan]'></td></tr>
          <tr><td>Email</td><td> : <input type=email class=field name=email value='$r[email_karyawan]'></td></tr>
          <tr><td>Pendidikan</td><td> : <input type=text class=field name=pendidikan value='$r[pend_karyawan]'></td></tr>
          <tr><td>Agama</td>
          <td>: <select name='agama' class=field>
          <option value=$r[agama_karyawan] selected> $r[agama_karyawan]</option>
          <option value=Islam>Islam</option>
          <option value=Kristen>Kristen</option>
          <option value=Hindu>Hindu</option>
          <option value=Budha>Budha</option>
          </select></td></tr>
          <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir' value='$r[tmp_lhr_karyawan]'></td></tr>

          <tr><td>Tanggal Lahir</td><td> : <input class=field type=text readonly id=tgl_kar name='tgl_lahir' value='$r[tgl_lhr_karyawan]'></td></tr>

          <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=4>$r[alamat_karyawan]</textarea></td></tr>
          <tr><td>Password</td><td> : <input style='width: 250px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' class='form-password' type='password' name=pass value='$r[pass_karyawan]'></td></tr>
                      <tr><td></td><td><input type='checkbox' class='form-checkbox'> Show password</td></tr>
          <tr><td></td><td><input class=button-submit type=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
        echo "</div>";

  
}elseif($_GET[module]=='aksieditguru'){
  $nip = $_POST[nip];
  $pass = $_POST[pass];
  $nama = $_POST[nama];
  $jabatan = $_POST[jabatan];
  $file_size  = $_FILES[fupload][size];
  $max_size = 100000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_file   = $_FILES[fupload][name];
  $jenis = $_POST[jenis];
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];

  $tgl = $_POST[tgl_lahir];
  $pendidikan = $_POST[pendidikan];
  
  $alamat = $_POST[alamat];

 if (empty($lokasi_file)) {
    $ubah = mysql_query("UPDATE karyawan SET nip = '$nip', 
                                           nm_karyawan = '$nama', 
                                           jabatan = '$jabatan', 
                                           email_karyawan = '$email', 
                                           no_telp_karyawan = '$tel',  
                                           agama_karyawan = '$agama',
                                           pend_karyawan = '$pendidikan',
                                           jenis_kel_karyawan = '$jenis', 
                                           tmp_lhr_karyawan = '$tempat_lahir', 
                                           tgl_lhr_karyawan = '$tgl',
                                           alamat_karyawan = '$alamat',
                                           pass_karyawan = '$pass' 
                                           WHERE id_karyawan = '$_POST[id]'");
  }elseif($file_size > $max_size){
    echo "<script>";
    echo "window.alert('File Size Gambar Terlalu Besar')";
    echo "</script>";
  }else {
    move_uploaded_file($lokasi_file,"../foto_karyawan/$nama_file");
    $ubah = mysql_query("UPDATE karyawan SET 
                                          nip = '$nip', 
                                           nm_karyawan = '$nama', 
                                           foto_karyawan = '$nama_file',
                                           jabatan = '$jabatan', 
                                           email_karyawan = '$email', 
                                           no_telp_karyawan = '$tel',  
                                           agama_karyawan = '$agama',
                                           pend_karyawan = '$pendidikan',
                                           jenis_kel_karyawan = '$jenis', 
                                           tmp_lhr_karyawan = '$tempat_lahir', 
                                           tgl_lhr_karyawan = '$tgl',
                                           alamat_karyawan = '$alamat',
                                           pass_karyawan = '$pass' 
                                           WHERE id_karyawan = '$_POST[id]'");
  }

  if ($ubah) {
    header('location:data_guru.html'); 
  }else{
    echo "Data gagal diubah".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}

?>
