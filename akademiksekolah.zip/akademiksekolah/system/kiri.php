<?php

	if ($_GET[module]=='home'){
		echo "<div class='panel-heading'>
                Welcome
                </div>
                <div class='panel-body'>
                    <h1>Selamat Datang $_SESSION[namauser]</h1><hr>";
                if ($_SESSION['leveluser'] == 'admin'){
                		echo "<ul style='display:inline-block; list-style:none; padding:0px;'> 
                				<li style='list-style:none; float:left; text-align:center; padding:15px'> <a href='siswa.html'><img src='../style/img/siswa.png' width=100px><br><strong class=button-submit style='font-size:16px'>siswa</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a  href='berita.html'><img src='../style/img/artikel.png' width=100px><br><strong class=button-submit style='font-size:16px'>Berita dan Artikel</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a href='karyawan.html'><img src='../style/img/kar.png' width=100px><br><strong class=button-submit style='font-size:16px'>Karyawan</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a href='jadwal.html'><img src='../style/img/jadwal.png' width=100px><br><strong class=button-submit style='font-size:16px'>Jadwal Pelajaran</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a href='learning.html'><img src='../style/img/learning.png' width=100px><br><strong class=button-submit style='font-size:16px'>Learning</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a href='detail_kelas.html'><img src='../style/img/learning.png' width=100px><br><strong class=button-submit style='font-size:16px'>Kelas Siswa</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a href='khs.html'><img src='../style/img/learning.png' width=100px><br><strong class=button-submit style='font-size:16px'>KHS</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a href='alumni.html'><img src='../style/img/learning.png' width=100px><br><strong class=button-submit style='font-size:16px'>Alumni</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:15px'><a href='backup.php'><img src='../style/img/backup.png' width=100px><br><strong class=button-submit style='font-size:16px'>Backup dan Restore</strong></a></li>
                				</ul>
                				";
				}elseif ($_SESSION['leveluser'] == 'guru'){
					$tam=mysql_query("SELECT * FROM jadwal where t_ajaran='$_POST[tahun]'");
    				$t = mysql_fetch_array($tam);
				echo "
				<div class='panel-body'>
				<h3 style='padding-bottom:0px;'>Jadwal Mengajar $_SESSION[namauser]</h3>
				<table style='float:right'>
		            <form action='' name=myform method=POST onSubmit='return valid_jad()'>
		              <tr align=center>
		                <td> Tahun Ajaran : 
		                  <select name=tahun class=field>";
		                
		                      $kat=mysql_query("SELECT DISTINCT t_ajaran from jadwal");
		                        while($vr=mysql_fetch_array($kat)){
		                          if ($t[t_ajaran]==$vr[t_ajaran]){
		                              echo "<option value=$vr[t_ajaran] selected>$vr[t_ajaran]</option>";
		                            }
		                             else{
		                              echo "<option value=$vr[t_ajaran]>$vr[t_ajaran]</option>";
		                            }
		                        }
		                      echo "</select>";
		                      echo " <input class=button-submit type=submit name=submit value='Tampilkan Jadwal'> ";
		                      echo "
		                        </td>
		              </tr>
		             </form>
		            </table>
				<table id='data' class='display' width=100% cellpadding=0>
			              <thead>
			                <tr>
			                  <th class='data' width=20px>No</th>
			                  <th class='data'>Hari</th>
			                  <th class='data'>Jam</th>
			                  <th class='data'>Mata Pelajaran</th>
			                  <th class='data'>Kelas</th>
			                </tr>
			              </thead>
			              <tbody>";
			                    $sql = mysql_query("SELECT * from jadwal a 
                                          join karyawan b ON a.id_karyawan=b.id_karyawan
                                          join mapel c ON a.id_mapel=c.id_mapel 
                                          join kelas d ON d.id_kelas=a.id_kelas where b.nip=$_SESSION[nip] AND a.t_ajaran='$_POST[tahun]' ORDER BY a.hari DESC");
			                    $no = 1;
			                    while ($r=mysql_fetch_array($sql)){
			          
			            echo "<tr class='data'><td class='data'>$no</td>
			            <td class='data'>$r[hari]</td>
			            <td class='data'>$r[jam]</td>
			            <td class='data'>$r[nm_mapel]</td>
			            <td class='data'>$r[nm_kelas]</td>
			            </td>
			          </tr>";
			          $no++;
			        }
			        
			        echo "</tbody></table></div>";
				}elseif ($_SESSION['leveluser'] == 'tu'){
                		echo "<ul style='display:inline-block; list-style:none; padding:0px;'> 
                				<li style='list-style:none; float:left; text-align:center; padding:10px'> <a href='siswa.html'><img src='../style/img/siswa.png' width=100px><br><strong style='font-size:16px'>siswa</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:10px'><a href='karyawan.html'><img src='../style/img/kar.png' width=100px><br><strong style='font-size:16px'>Karyawan</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:10px'><a href='detail_kelas.html'><img src='../style/img/learning.png' width=100px><br><strong style='font-size:16px'>Kelas Siswa</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:10px'><a href='jadwal.html'><img src='../style/img/jadwal.png' width=100px><br><strong style='font-size:16px'>Jadwal Pelajaran</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:10px'><a href='khs.html'><img src='../style/img/learning.png' width=100px><br><strong style='font-size:16px'>KHS</strong></a></li>
                				<li style='list-style:none;  float:left; text-align:center; padding:10px'><a href='alumni.html'><img src='../style/img/learning.png' width=100px><br><strong style='font-size:16px'>Alumni</strong></a></li>
                				</ul>
                				";
				}elseif ($_SESSION['leveluser'] == 'aktif'){
                		echo "
                				";
				}else{
					echo " <li><a href='kategori.html'>Kategori</a></li>
						   <li><a href='berita.html'>Berita dan Artikel</a></li>
						   <li><a href='jurusan.html'>Jurusan</a></li>
						   <li><a href='kelas.html'>Kelas</a></li>
						   <li><a href='mapel.html'>Mapel</a></li>
						   <li><a href='alumni.html'>Alumni</a></li>
						   <li><a href='karyawan.html'>Karyawan</a></li>
						   <li><a href='learning.html'>Learning</a></li>
						   <li><a href='#'>Blalala</a></li>
						   <li><a href='#'>Blalala</a></li>
						   <li><a href='#'>Blalala</a></li>
						   <li><a href='#'>Blalala</a></li>";
				}
				echo "</div>";
	}

	include "kategori.php";
	include "berita.php";
	include "jurusan.php";
	include "kelas.php";
	include "mapel.php";
	include "alumni.php";
	include "karyawan.php";
	include "learning.php";
	include "siswa.php";
	include "detail_kelas.php";
	include "jadwal.php";
	include "khs.php";
	include "data_guru.php";
	include "data_siswa.php";
	include "khs_siswa.php";
	include "nilai_siswa.php";
	include "user.php";
?>

