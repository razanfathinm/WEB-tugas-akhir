<script language='javascript'>
    function validasi_use(){
        var nama         = myform.nama_admin.value;
        var user         = myform.nama_user.value;
        var pas         = myform.pass.value;
        var pesan = '';
        
        if (nama == '') {
            pesan = '-Silahkan isi nama terlebih dahulu\n';
        }

        if (pas.length<8) {
            pesan += '-Password Minimal 8 karakter\n';
        }

        if (pas == '') {
            pesan += '-Silahkan isi Password terlebih dahulu\n';
        }

        if (user == '') {
            pesan += '-Silahkan isi user terlebih dahulu\n';
        }
        
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<script language='javascript'>
    function validasi_ber(){
        var judul         = myform.judul.value;
        var kategori         = myform.kategori.value;
        var isi         = myform.isi_berita.value;
        var penulis         = myform.penulis.value;
        var pesan = '';
        
        if (judul == '') {
            pesan = '-Silahkan isi judul terlebih dahulu\n';
        }

        if (isi.length<200) {
            pesan += '-Isi berita atau artikel minimal 200 karakter\n';
        }

        if (kategori == '0') {
            pesan += '-Silahkan pilih kategori terlebih dahulu\n';
        }

        if (penulis == '') {
            pesan += '-Silahkan isi penulis terlebih dahulu\n';
        }
        
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<!-- validasi alumni-->
<script>
    function validasi_al(){
        var namaValid    = /^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*$/;
        var nisn         = myform.nisn.value;
        var numbers      = /^[0-9]+$/;
        var nama         = myform.nama.value;
        var email        = myform.email.value;
        var pesan = '';

        if (nisn == '') {
            pesan = '-NISN alumni tidak boleh kosong\n';
        }

        if (nisn.length<10){
          pesan += '-NISN alumni Tidak lengkap, NISN harus 10 Digit\n';
        }

        if (nama == '') {
            pesan += '-Nama alumni tidak boleh kosong\n';
        }
        
        if (nama != '' && !nama.match(namaValid)) {
            pesan += '-Nama alumni hanya boleh [a-zA-Z]\n';
        }

        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<!-- validasi kelas-->
<script language='javascript'>
    function validasi_kel(){
        var nama         = myform.nama_kelas.value;
        var jur         = myform.jurusan.value;
        var kl         = myform.kd_kelas.value;
        var pesan = '';
        
        if (nama == '') {
            pesan = '-Nama kelas tidak boleh kosong\n';
        }

        if (kl == 0) {
            pesan += '-Kode kelas tidak boleh kosong\n';
        }

        if (jur == 0) {
            pesan += '-jurusan tidak boleh kosong\n';
        }
        
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>



<!-- validasi alumni-->
<script>
    function validasi_sis(){
        var namaValid    = /^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*$/;
        var nisn         = myform.nisn.value;
        var numbers      = /^[0-9]+$/;
        var nama         = myform.nama.value;
        var email        = myform.email.value;
        var tel_ayah     = myform.telp_ayah.value;
        var tel_wali     = myform.telp_wali.value;
        var img          = myform.fupload.value;
        var fup = document.getElementById('fupload');
        var fileName = fup.value;
        var file = document.getElementById('fupload').files[0];
        var pesan = '';

        if (img != '') {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);

            if (ext !='jpg' && ext != 'png') {
            pesan += '-File tipe harus jpg atau png\n';
            }
        }

        if (nisn == '') {
            pesan = '-NISN siswa tidak boleh kosong\n';
        }

        if (nisn.length<10){
          pesan += '-NISN siswa Tidak lengkap, NISN harus 10 Digit\n';
        }

        if (nama == '') {
            pesan += '-Nama siswa tidak boleh kosong\n';
        }
        
        if (nama != '' && !nama.match(namaValid)) {
            pesan += '-Nama siswa hanya boleh [a-zA-Z]\n';
        }

        if(file && file.size > 1000000) {
            pesan += '-File Terlalu besar minimal < 1 mb\n';
        }

        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<!-- validasi karyawan -->
<script>
    function validasi_kar(){
        var namaValid    = /^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*$/;
        var emailValid   = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
        var nip         = myform.nip.value;
        var numbers      = /^[0-9]+$/;
        var nama         = myform.nama.value;
        var email        = myform.email.value;
        var img          = myform.fupload.value;
        var fup = document.getElementById('fupload');
        var fileName = fup.value;
        var file = document.getElementById('fupload').files[0];
        var pesan = '';

        if (img != '') {
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1);

            if (ext !='jpg' && ext != 'png') {
            pesan += '-File tipe harus jpg atau png\n';
            }
        }

        if (nip == '') {
            pesan = '-NIP karyawan tidak boleh kosong\n';
        }

        if (nip.length<18){
          pesan += '-NIP karyawan Tidak lengkap, NIP harus 18 Digit\n';
        }

        if (nama == '') {
            pesan += '-Nama karyawan tidak boleh kosong\n';
        }
        
        if (nama != '' && !nama.match(namaValid)) {
            pesan += '-Nama karyawan hanya boleh [a-zA-Z]\n';
        }
        
        if (email !=''  && !email.match(emailValid)) {
            pesan += '-alamat email tidak valid, ex: email@example.com\n';
        }

        if(file && file.size > 1000000) {
            pesan += '-File Terlalu besar minimal < 1 mb\n';
        }

        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<!-- validasi alumni-->
<script>
    function validasi_el(){
        var nama         = myform.nama.value;
        var pesan = '';

        if (nama == '') {
            pesan = '-Nama Learning tidak boleh kosong\n';
        }

        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<script language='javascript'>
    function validasi_map(){
        var nama         = myform.nama_mapel.value;
        var pesan = '';
        
        if (nama == '') {
            pesan = '-Nama mapel tidak boleh kosong\n';
        }
        
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<script language='javascript'>
function valid_jad(){
var kel = myform.kelas.value;
var tah = myform.tahun.value;
var pesan = '';

        if (kel == 0) {
            pesan = '-Pilih salah satu kelas\n';
        }

        if (tah == 0){
          pesan += '-pilih salah satu tahun ajaran\n';
        }
    
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
                return false;
        }
        return true
}
</script>

<script language='javascript'>
function validasi_jad(){
var kelas = myform.kelas.value;
var mapel = myform.mapel.value;
var guru = myform.guru.value;
var hari = myform.hari.value;
var jammulai = myform.jammulai.value;
var jamakhir = myform.jamakhir.value;
var menitmulai = myform.menitmulai.value;
var menitakhir = myform.menitakhir.value;
var pesan = '';

        if (kelas == '') {
            pesan = '-Pilih salah satu kelas\n';
        }

        if (mapel == ''){
          pesan += '-pilih salah satu mata pelajaran\n';
        }

        if (hari == 0){
          pesan += '-pilih salah satu hari\n';
        }

        if(jammulai==jamakhir && menitmulai==menitakhir){
            pesan += '-jam pelajaran tidak valid ~ jam mulai sama dengan jam akhir\n';
            }

        if(jammulai > jamakhir){
            pesan += '-jam pelajaran tidak valid ~ jam mulai lebih besar dari dari jam akhir\n';
            }
        if (guru == '') {
            pesan += '-pilih salah satu guru pengajar\n';
        }
    
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
                return false;
        }
        return true
}
</script>



<script>
            function tampilkanPreview(gambar,idpreview){
                var gb = gambar.files;
                for (var i = 0; i < gb.length; i++){
                    var gbPreview = gb[i];
                    var imageType = /image.*/;
                    var preview=document.getElementById(idpreview);            
                    var reader = new FileReader();
                    
                    if (gbPreview.type.match(imageType)) {
                        preview.file = gbPreview;
                        reader.onload = (function(element) { 
                            return function(e) { 
                                element.src = e.target.result; 
                            }; 
                        })(preview);
                        reader.readAsDataURL(gbPreview);
                    }else{
                        alert("file yang anda upload tidak sesuai. Khusus mengunakan image.");
                    }
                   
                }    
            }
</script>

<script language='javascript'>
function valid_khs(){
var kel = myform.kelas.value;
var sem = myform.semester.value;
var tah = myform.tahun.value;
var pesan = '';

        if (kel == 0) {
            pesan = '-Pilih salah satu kelas\n';
        }

        if (sem == 0){
          pesan += '-pilih salah satu semester\n';
        }

        if (tah == 0){
          pesan += '-pilih salah satu tahun ajaran\n';
        }
    
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
                return false;
        }
        return true
}
</script>

<script language='javascript'>
function valid_khs_tam(){
var kel = myform.kelas.value;
var tah = myform.tahun.value;
var pesan = '';

        if (kel == 0) {
            pesan = '-Pilih salah satu kelas\n';
        }

        if (tah == 0){
          pesan += '-pilih salah satu tahun ajaran\n';
        }
    
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
                return false;
        }
        return true
}
</script>

<script language='javascript'>
function validasi_khs(){
var tah = myform.tahun.value;
var map = myform.mapel.value;
var nil = myform.nilai.value;
var pesan = '';

        if (tah == 0) {
            pesan = '-Pilih tahun ajaran\n';
        }

        if (map == ''){
          pesan += '-pilih salah satu mata pelajaran\n';
        }

        if (nil == ''){
          pesan += '-Inputkan nilai mata pelajaran\n';
        }
    
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
                return false;
        }
        return true
}
</script>

<script>
    function valid_naik(){
        var kelas         = myform.kelas.value;
        var tahun         = myform.tahun.value;
        var cek           = document.getElementsByName('no_id[]');
        var no_checked    = false;
        var pesan = '';

        for (var i = 0; i < cek.length; i++){
            if (cek[i].checked) {
                no_checked = true;
                break;
            }
        }
            if (no_checked == false){
            pesan += '-Tidak ada siswa yang dipilih\n';
            }

            if (kelas == 0) {
            pesan = '-Tidak ada kelas yang dipilih\n';
            }

            if (tahun == 0){
              pesan += '-Tidak ada tahun yang dipilih\n';
            }

            if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<script>
function toggle(pilih) {
  checkboxes = document.getElementsByName('no_id[]');
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = pilih.checked;
  }
}
</script>

<script language='javascript'>
function valid_det(){
var jur = myform.jurusan.value;
var kel = myform.kelas.value;
var tah = myform.tahun.value;
var pesan = '';

        if (jur == 0) {
            pesan = '-Pilih salah satu jurusan\n';
        }

        if (kel == 0){
          pesan += '-pilih salah satu kelas\n';
        }

        if (tah == 0){
          pesan += '-pilih salah satu tahun ajaran\n';
        }
    
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
                return false;
        }
        return true
}
</script>