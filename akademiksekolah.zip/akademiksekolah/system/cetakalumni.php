<?php
define('FPDF_FONTPATH','../fpdf//font/');
require('../fpdf/fpdf.php');

class PDF extends FPDF
{
	
	//Page Content
	function Content()
	{
		//Logo
		$this->Image('logo-tebo.png',10,8);
		//Arial bold 15
		$this->SetFont('Arial','',11);
		//pindah ke posisi ke tengah untuk membuat judul
		$this->Cell(80);
		//judul
		$this->Cell(40,3,'PEMERINTAH KABUPATEN TEBO',0,0,'C');
		$this->ln(5);
		$this->Cell(80);
		$this->Cell(40,3,'DINAS PENDIDIKAN KEBUDAYAAN PEMUDA DAN OLAHRAGA',0,0,'C');
		//pindah baris
		$this->Ln(5);
		$this->SetFont('Arial','B',12);
		$this->Cell(80);
		$this->Cell(40,3,'SMK NEGERI 2 KABUPATEN TEBO',0,0,'C');

		//pindah baris
		$this->ln(5);
		$this->SetFont('Arial','',9);
		$this->Cell(80);
		$this->Cell(40,3,'Jalan M. Hatta, Kel. Wirotho Agung, Kec. Rimbo Bujang, Kab. Tebo, JAMBI Telp/Fax 0747-431895',0,0,'C');
		
		//pindah baris
		$this->Ln(10);
		//buat garis horisontal
		$this->Line(10,32,200,32);
		//pindah baris
		$this->SetFont('Arial','B',12);
		$this->Cell(80);
		$this->Cell(40,3,'Laporan Data Alumni',0,0,'C');
		//pindah baris
		$this->Ln(10);

		//end of header

		include "../config/koneksi.php";
			$Lapor = "SELECT nisn_alumni, nm_alumni, email_alumni, alamat_alumni, no_telp_alumni FROM alumni ORDER by id_alumni";
			$Hasil = mysql_query($Lapor);
			$Data = array();
			while($row = mysql_fetch_assoc($Hasil)){
				array_push($Data, $row);
		}

		$Header= array(
		array("label"=>"NISN", "length"=>30, "align"=>"L"),
		array("label"=>"Nama Siswa", "length"=>60, "align"=>"L"),
		array("label"=>"Email", "length"=>40, "align"=>"L"),
		array("label"=>"Alamat", "length"=>33, "align"=>"L"),
		array("label"=>"Telepon", "length"=>30, "align"=>"L"),
		);

		$this->SetFont('arial','B','11');
		$this->SetFillColor(204,204,200);
		$this->SetTextColor(0);
		$this->setDrawColor(245);
		foreach ($Header as $Kolom){
			$this->Cell($Kolom['length'], 8, $Kolom['label'], 1, '0', $Kolom['align'], true);
		}
		$this->Ln();
		//menampilkan data
		$this->SetFillColor(244,235,255);
		$this->SettextColor(0);
		$this->SetFont('arial','','9');
		$fill =false;
		foreach ($Data as $Baris){
			$i= 0;
			foreach ($Baris as $Cell){
				$this->Cell ($Header[$i]['length'], 7, $Cell, 2, '0', $Kolom['align'], $fill);
				$i++;
			}
			$fill = !$fill;
			$this->Ln();
		}


	}

	//Page footer
	function Footer()
	{
		//atur posisi 1.5 cm dari bawah
		$this->SetY(-15);
		//buat garis horizontal
		$this->Line(10,$this->GetY(),200,$this->GetY());
		//Arial italic 9
		$this->SetFont('Arial','I',9);
		//nomor halaman
		$this->Cell(0,10,'Halaman '.$this->PageNo().' dari {nb}',0,0,'R');
	}
}

//contoh pemanggilan class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Content();
$pdf->Output();
?>