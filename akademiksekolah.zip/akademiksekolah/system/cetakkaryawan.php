<?php
define('FPDF_FONTPATH','../fpdf//font/');
require('../fpdf/fpdf.php');

class PDF extends FPDF
{
	
	//Page Content
	function Content()
	{
		//Logo
		$this->Image('logo-tebo.png',10,8);
		//Arial bold 15
		$this->SetFont('Arial','',11);
		//pindah ke posisi ke tengah untuk membuat judul
		$this->Cell(80);
		//judul
		$this->Cell(40,3,'PEMERINTAH KABUPATEN TEBO',0,0,'C');
		$this->ln(5);
		$this->Cell(80);
		$this->Cell(40,3,'DINAS PENDIDIKAN KEBUDAYAAN PEMUDA DAN OLAHRAGA',0,0,'C');
		//pindah baris
		$this->Ln(5);
		$this->SetFont('Arial','B',12);
		$this->Cell(80);
		$this->Cell(40,3,'SMK NEGERI 2 KABUPATEN TEBO',0,0,'C');

		//pindah baris
		$this->ln(5);
		$this->SetFont('Arial','',9);
		$this->Cell(80);
		$this->Cell(40,3,'Jalan M. Hatta, Kel. Wirotho Agung, Kec. Rimbo Bujang, Kab. Tebo, JAMBI Telp/Fax 0747-431895',0,0,'C');
		
		//pindah baris
		$this->Ln(10);
		//buat garis horisontal
		$this->Line(10,32,200,32);
		//pindah baris
		

		//end of header

		include "../config/koneksi.php";
			$lap = "SELECT UPPER (nm_karyawan), nip, foto_karyawan, jabatan, email_karyawan, no_telp_karyawan, pend_karyawan, jenis_kel_karyawan, tmp_lhr_karyawan, tgl_lhr_karyawan, alamat_karyawan from karyawan where id_karyawan='$_GET[id]'";
			$kelas= mysql_query($lap);
			$r = mysql_fetch_array($kelas);
			$t = array($r[0]);
			$nip = array($r[1]);
			$foto = array($r[2]);
			$jab = array($r[3]);
			$email = array($r[4]);
			$no = array($r[5]);
			$pen = array($r[6]);
			$jenis = array($r[7]);
			$tmp = array($r[8]);
			$tgl = array($r[9]);
			$alamat = array($r[10]);

		$this->SetFont('Arial','B',12);
		$this->Cell(60);
		$this->Cell(60,3,'Laporan Data Karyawan',0,0,'C');
		
		//pindah baris
		$this->Ln(10);

		$this->SetFont('Arial','B',11);

		$this->Cell(40,3,'Nama',0,0,'L');
		foreach ($t as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}


		foreach ($foto as $kel){
		if (empty($kel)) {
			$this->Image('siswa.png',155,45,25);
		} else{
			$this->Image('../foto_karyawan/'.$kel,155,45,25);
		}
		}
		$this->Ln(7);
		$this->Cell(40,3,'NIP',0,0,'L');
		foreach ($nip as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'Jabatan',0,0,'L');
		foreach ($jab as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'Email',0,0,'L');
		foreach ($email as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'No, Telp',0,0,'L');
		foreach ($no as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'Pendidikan',0,0,'L');
		foreach ($pen as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'Jenis Kelamin',0,0,'L');
		foreach ($jenis as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'Tempat Lahir',0,0,'L');
		foreach ($tmp as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'Tanggal lahir',0,0,'L');
		foreach ($tgl as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		$this->Cell(40,3,'Alamat',0,0,'L');
		foreach ($alamat as $kel){
			$this->Cell(3,3,':',0,0,'L');
			$this->Cell(40,3,$kel);
		}
		$this->Ln(7);

		
		


	}

	//Page footer
	function Footer()
	{
		//atur posisi 1.5 cm dari bawah
		$this->SetY(-15);
		//buat garis horizontal
		$this->Line(10,$this->GetY(),200,$this->GetY());
		//Arial italic 9
		$this->SetFont('Arial','I',9);
		//nomor halaman
		$this->Cell(0,10,'Halaman '.$this->PageNo().' dari {nb}',0,0,'R');
	}
}

//contoh pemanggilan class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Content();
$pdf->Output();
?>