<script language='javascript'>
    function validasi_jur(){
        var nama         = myform.nama_jurusan.value;
        var pesan = '';
        
        if (nama == '') {
            pesan = '-Nama jurusan tidak boleh kosong\n';
        }
        
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>

<?php

if ($_GET[module]=='jurusan'){ 
  echo "<div class='panel-heading'>
                Manajemen Jurusan
                </div>
                <div class='panel-body'>
          <input class=button-submit type=button value='Tambah Jurusan' 
          onclick=\"window.location.href='media.php?module=tambahjurusan';\">
          <table class='data' width=100% cellpadding=6>
			<tr>
				<th class='data' width=30px>No</th>
				<th class='data'>Nama Jurusan</th>
				<th class='data' align='center' width='110px;'>Action</th>
			</tr>"; 
    $tampil=mysql_query("SELECT * FROM jurusan ORDER BY id_jurusan DESC");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
	if(($no % 2)==0){
			$warna="#ffffff";
		  }
		  else{
			$warna="#E1E1E1";
		  }
       echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
				<td class='data'>$r[nm_jurusan]</td>
				<td class='data' align=center><a class=button-action href=media.php?module=editjurusan&id=$r[id_jurusan]>Edit</a> | 
	               <a class=button-hapus href=media.php?module=hapusjurusan&id=$r[id_jurusan] onClick=\"return confirm('Anda yakin menghapus $r[nm_jurusan]?')\">Hapus</a>
				</td>
			</tr>";
      $no++;
    }
    echo "</table></div>";
	
}elseif($_GET[module]=='tambahjurusan'){
  echo "<div class='panel-heading'>
                Tambah Jurusan
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksitambahjurusan' onSubmit='return validasi_jur()'>
          <table>
          <tr><td>Nama jurusan</td><td> <input class=field type=text name='nama_jurusan'></td></tr>
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksitambahjurusan'){
	$testing = $_POST[nama_jurusan];
  $cekdata = mysql_query("SELECT nm_jurusan from jurusan WHERE nm_jurusan='$testing'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('Data Sudah Ada Didalam Database');window.location='media.php?module=tambahjurusan'</script>\n";
  }else{
	mysql_query("INSERT INTO jurusan(nm_jurusan) VALUES('$testing')");
	header('location:jurusan.html');
}
	
}elseif($_GET[module]=='editjurusan'){
	$edit=mysql_query("SELECT * FROM jurusan WHERE id_jurusan='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit Jurusan
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksieditjurusan' onSubmit='return validasi_jur()'>
          <input type=hidden name=id value='$r[id_jurusan]'>
          <table>
          <tr><td>Nama jurusan</td><td> <input class=field type=text name='nama_jurusan' value='$r[nm_jurusan]'></td></tr>
          <tr><td></td><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
		  
}elseif($_GET[module]=='aksieditjurusan'){
	mysql_query("UPDATE jurusan SET nm_jurusan = '$_POST[nama_jurusan]' WHERE id_jurusan = '$_POST[id]'");
  echo "<script> alert('Data Berhasil diubah');window.location='jurusan.html'</script>\n";
  
}elseif($_GET[module]=='hapusjurusan'){
	mysql_query("DELETE FROM jurusan WHERE id_jurusan='$_GET[id]'");
  header('location:jurusan.html');
}

?>