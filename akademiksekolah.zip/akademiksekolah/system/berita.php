
<?php
if ($_GET[module]=='berita'){
  echo "<div class='panel-heading'>
                Manajemen Arikel dan Berita
                </div>
                <div class='panel-body'>"; 
	echo "<input class=button-submit type=button value='Tambah Berita/Artikel' 
          onclick=\"window.location.href='media.php?module=tambahberita';\">

          <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>Judul Berita dan Artikel</th>
                  <th class='data'>Tanggal</th>
                  <th class='data nosorting' width=90px>Action</th>
                </tr>
              </thead>
              <tbody>";
                    $sql = mysql_query("SELECT * FROM berita ORDER BY id_berita desc");
                    $no = 1;
                    while ($r=mysql_fetch_array($sql)){
          
                       echo "<tr class='data'><td class='data'>$no</td>
            <td class='data'>$r[jdl_berita]</td>
            <td class='data'>$r[tgl_berita]</td>
            <td class='data' align=center><a class=button-action href=media.php?module=editberita&id=$r[id_berita]>Edit</a> | 
                     <a class=button-hapus href=media.php?module=hapusberita&id=$r[id_berita] onClick=\"return confirm('Anda yakin menghapus $r[jdl_berita]?')\">Hapus</a>
            </td>
          </tr>";
          $no++;
        }
        
        echo "</tbody></table>";
      echo "</div>";
    
	
}elseif($_GET[module]=='tambahberita'){
  echo "<div class='panel-heading'>
                Tambah Berita Atau Artikel
                </div>
                <div class='panel-bod'>";

echo "<form name='myform' method=POST action='media.php?module=aksitambahberita' enctype='multipart/form-data' onSubmit='return validasi_ber()'>

           <div class='row'>
              <div class='col-lg-8'>
                    <table>
                      <tr>
                        <td><strong>Judul</strong><br> <input style='width: 640px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' type=text name='judul' maxlength=100></td>
                      </tr>
                      <tr>
                        <td valign='top'><strong>Isi Berita</strong><br> <textarea style='width: 640px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' name=isi_berita rows=20></textarea></td>
                      </tr>
                    </table>  
              </div>

              <div class='col-lg-3'>
                <div class='panel panel-default'>
                  <div class='panel-heading'>
                    Kategori
                  </div>
                  <div class='panel-body'>
                    <table>
                      <tr>
                        <td> 
                          <select name=kategori style='width: 230px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;'>
                          <option value=0 selected> Pilih Kategori </option>";
                 
                          $kat=mysql_query("SELECT * FROM kategori ORDER BY nm_kategori");
                            while($vr=mysql_fetch_array($kat)){
                              echo "<option value=$vr[id_kategori]>$vr[nm_kategori]</option>";
                            }
                      echo "</select></td></tr>
                    </table>  
                  </div>
                </div>
              
                <div class='panel panel-default'>
                  <div class='panel-heading'>
                    Penulis
                  </div>
                  <div class='panel-body'>
                    <table>
                      <tr>
                        <td> <input style='width: 230px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' type=text name='penulis'></td>
                      </tr>
                    </table>  
                  </div>
                </div>
              
                <div class='panel panel-default'>
                  <div class='panel-heading'>
                    Gambar
                  </div>
                  <div class='panel-body'>
                    <table>
                      <tr>
                        <td align=center> <img id=preview src=../images/camera.png width=150px> <br>
                        <input type=file name=fupload class=input accept='.jpg, .png'  onchange=tampilkanPreview(this,'preview') /></td>
                      </tr>
                    </table>  
                  </div>
                </div>
              </div>
            </div>
            <tr><td><input class=button-submit type=submit name=submit value=Simpan>
              <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          
    </form>";
		echo "</div>";  
}elseif($_GET[module]=='aksitambahberita'){

$jdl = $_POST[judul];
$kt = $_POST[kategori];
$pen = $_POST[penulis];
$isi = $_POST[isi_berita];
  $file_size  = $_FILES[fupload][size];
  $max_size = 1000000; // 1MB
$lokasi_file = $_FILES[fupload][tmp_name];
$nama_f   = $_FILES[fupload][name];

  $acak      = rand(0,99999);
  $nama_file = ($acak.substr($nama_f, -4));

$eror   = false;
  //type file yang bisa diupload
  $file_type  = array('jpg','png');
  //cari extensi file dengan menggunakan fungsi explode
  $explode  = explode('.',$nama_file);
  $extensi  = $explode[count($explode)-1];

// Apabila tidak ada gambar yang diupload
	if (empty($lokasi_file)) {
		$insert = mysql_query("INSERT INTO berita(jdl_berita, id_kategori, penulis, isi_berita) VALUES('$jdl', '$kt', '$pen', '$isi')");
	}if(!in_array($extensi,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai, file harus bertipe jpg, jpeg, png';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo "<script> 
            onload = function(){
              alert('$pesan');onclick=self.history.back()
            return false;
            }
          </script>\n";
    //echo '<div id="eror">'.$pesan.'</div>';
  }
  else {
		move_uploaded_file($lokasi_file,"../gambar_berita/$nama_file");
  		$insert = mysql_query("INSERT INTO berita(jdl_berita, id_kategori, penulis, foto_berita, isi_berita) VALUES('$jdl', '$kt', '$pen', '$nama_file', '$isi')");
	}

	if ($insert) {
		header('location:berita.html');	
	}else{
		echo "Data gagal disimpan".mysql_error();
	}
	
}elseif($_GET[module]=='editberita'){
	$edit=mysql_query("SELECT * FROM berita WHERE id_berita='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit Berita Atau Artikel
                </div>
                <div class='panel-bod'>";
    echo "<form name='myform' method=POST action='media.php?module=aksieditberita' enctype='multipart/form-data' onSubmit='return validasi_ber()'>
          <input type=hidden name=id value='$r[id_berita]'>
          
          <div class='row'>
              <div class='col-lg-8'>
                    <table>
                      <tr>
                        <td>Judul<br> <input style='width: 640px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' type=text name='judul' value='$r[jdl_berita]' size=100 maxlength=100></td>
                      </tr>
                      <tr>
                        <td valign='top'>Isi Berita<br> <textarea style='width: 640px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' name=isi_berita rows=20>$r[isi_berita]</textarea></td>
                      </tr>
                    </table>  
              </div>

              <div class='col-lg-3'>
                <div class='panel panel-default'>
                  <div class='panel-heading'>
                    Kategori
                  </div>
                  <div class='panel-body'>
                    <table>
                      <tr><td> <select name=kategori style='width: 230px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;'>";
 
                          $tampil=mysql_query("SELECT * FROM kategori ORDER BY nm_kategori");
                            while($w=mysql_fetch_array($tampil)){
                              if ($r[id_kategori]==$w[id_kategori]){
                                echo "<option value=$w[id_kategori] selected>$w[nm_kategori]</option>";
                              }
                              else{
                                  echo "<option value=$w[id_kategori]>$w[nm_kategori]</option>";
                              }
                          }
                  echo "</select></td></tr>
                    </table>  
                  </div>
                </div>
              </div>

              <div class='col-lg-3'>
                <div class='panel panel-default'>
                  <div class='panel-heading'>
                    Penulis
                  </div>
                  <div class='panel-body'>
                    <table>
                      <tr>
                        <td> <input style='width: 230px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' type=text name='penulis' value='$r[penulis]'></td>
                      </tr>
                    </table>  
                  </div>
                </div>
              </div>

              <div class='col-lg-3'>
                <div class='panel panel-default'>
                  <div class='panel-heading'>
                    Gambar
                  </div>
                  <div class='panel-body'>
                    <table>
                      <tr>
                        <td align=center> <img id=preview src='../gambar_berita/$r[foto_berita]' width=150 height=100> <br>
                         <input type=file name=fupload accept='.jpg, .png' onchange=tampilkanPreview(this,'preview')> <br>
                         * kosongkan jika tidak ingin diubah</td>
                      </tr>
                    </table>  
                  </div>
                </div>
              </div>
          </div>
            <tr><td colspan=2><input class=button-submit type=submit value=Update>
             <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          
      </form></div>";
		  
}elseif($_GET[module]=='aksieditberita'){
	$ejdl = $_POST[judul];
	$ekt = $_POST[kategori];
	$epen = $_POST[penulis];
	$eisi = $_POST[isi_berita];
  $file_size  = $_FILES[fupload][size];
  $max_size = 1000000; // 1MB
$lokasi_file = $_FILES[fupload][tmp_name];
$nama_f   = $_FILES[fupload][name];

  $acak      = rand(0,99999);
  $nama_file = ($acak.substr($nama_f, -4));

$eror   = false;
  //type file yang bisa diupload
  $file_type  = array('jpg','png');
  //cari extensi file dengan menggunakan fungsi explode
  $explode  = explode('.',$nama_file);
  $extensi  = $explode[count($explode)-1];

	if (empty($lokasi_file)) {
		$ubah = mysql_query("UPDATE berita SET jdl_berita = '$ejdl', id_kategori = '$ekt', penulis = '$epen', isi_berita = '$eisi' WHERE id_berita = '$_POST[id]'");
	}if(!in_array($extensi,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai, file harus bertipe jpg, jpeg, png';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo "<script> 
            onload = function(){
              alert('$pesan');onclick=self.history.back()
            return false;
            }
          </script>\n";
    //echo '<div id="eror">'.$pesan.'</div>';
  }else {
		move_uploaded_file($lokasi_file,"../gambar_berita/$nama_file");
		$ubah = mysql_query("UPDATE berita SET jdl_berita = '$ejdl', id_kategori = '$ekt', penulis = '$epen', foto_berita = '$nama_file', isi_berita = '$eisi' WHERE id_berita = '$_POST[id]'");
	}

	if ($ubah) {
		header('location:berita.html');	
	}else{
		echo "Data gagal diubah".mysql_error();
	}
  
  
}elseif($_GET[module]=='hapusberita'){
  $hapus=mysql_query("SELECT * FROM berita WHERE id_berita='$_GET[id]'");
    $r=mysql_fetch_array($hapus);
  $d = '../gambar_berita/'.$r[foto_berita];
  unlink ("$d");
	mysql_query("DELETE FROM berita WHERE id_berita='$_GET[id]'");
  header('location:berita.html');
}

?>
