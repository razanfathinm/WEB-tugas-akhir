
<?php

if ($_GET[module]=='alumni'){ 
 echo "<div class='panel-heading'>
                Manajemen Data Alumni
                </div>
                <div class='panel-body'>";
          echo "<input style='padding=30px;' class=button-submit type=button value='Tambah alumni' 
          onclick=\"window.location.href='media.php?module=tambahalumni';\">
          <input style='padding=30px;' class=button-exit type=button value=Export To PDF title=Save as PDF Format onclick=window.open('cetakalumni.php','_blank');>
          <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>NISN</th>
                  <th class='data'>Nama Alumni</th>
                  <th class='data nosorting' width=90px>Action</th>
                </tr>
              </thead>
              <tbody>";
                    $sql = mysql_query("SELECT * FROM alumni order by nisn_alumni ASC");
                    $no = 1;
                    while ($r=mysql_fetch_array($sql)){
          
                       echo "<tr class='data'><td class='data'>$no</td>
            <td class='data'>$r[nisn_alumni]</td>
            <td class='data'>$r[nm_alumni]</td>
            <td class='data'><a class=button-action href=media.php?module=editalumni&id=$r[id_alumni]>Edit</a> | 
                     <a class=button-hapus href=media.php?module=hapusalumni&id=$r[id_alumni] onClick=\"return confirm('Anda yakin menghapus $r[nm_alumni]?')\">Hapus</a>
            </td>
          </tr>";
          $no++;
        }
        
        echo "</tbody></table>";
        echo "</div>";
 
}elseif($_GET[module]=='tambahalumni'){
echo "<div class='panel-heading'>
                Tambah Alumni
                </div>
                <div class='panel-body'>";
echo "<form name='myform' method=POST action='media.php?module=aksitambahalumni' onSubmit='return validasi_al()' enctype='multipart/form-data'>
          <table>
          <tr><td>NISN Alumni</td><td> : <input class=field type=text name='nisn' maxlength='10' onkeypress='return hanyaAngka(event)'></td></tr>
          <tr><td>Nama Alumni</td><td> : <input class=field type=text name='nama' maxlength='30'></td></tr>
          <tr><td>Foto Alumni</td><td> : <input type=file name=fupload></td></tr>
          <tr><td>Jenis Kelamin</td><td> : <input type=radio name=jenis value='L' checked>Laki-Laki
                                          <input type=radio name=jenis value='P'>Perempuan</td></tr>
          <tr><td>No Telp</td><td> : <input class=field type=text name=telepon maxlength=12 onkeypress='return hanyaAngka(event)'></td></tr>
          <tr><td>Email</td><td> : <input class=field type=email name=email></td></tr>
          <tr><td>Agama</td>
          <td>: <select name='agama' class=field>
          <option value=0 selected> Pilih Agama</option>
          <option value=Islam>Islam</option>
          <option value=Kristen>Kristen</option>
          <option value=Hindu>Hindu</option>
          <option value=Budha>Budha</option>
          </select></td></tr>
          <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir'></td></tr>
          <tr><td>Tanggal Lahir</td><td>: <input class=field type=text id=tgl_al name='tgl_lahir'> </td></tr>
          <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=4></textarea></td></tr>
          <tr><td>Status</td>
          <td>: <select name='status' class=field>
          <option value=0 selected> Pilih </option>
          <option value=Kuliah>Kuliah</option>
          <option value=Kerja>Kerja</option>
          <option value=NGANGGUR>NGANGGUR</option>
          <option value=Lain-Lain>Lain-Lain</option>
          </select></td></tr>
          <tr><td valign=top>Keterangan status</td><td>: <textarea class=field name=keterangan rows=3></textarea></td></tr>
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksitambahalumni'){
  $nisn = $_POST[nisn];
  $nama = $_POST[nama];
  $file_size  = $_FILES[fupload][size];
  $max_size = 100000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_file   = $_FILES[fupload][name];
  $jenis = $_POST[jenis];
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];

  $tgl=$_POST[tgl_lahir];
  
  $alamat = $_POST[alamat];
  $status = $_POST[status];
  $ket = $_POST[keterangan];

  $cekdata = mysql_query("SELECT nisn_alumni from alumni WHERE nisn_alumni='$nisn'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('NISN Sudah Ada Didalam Database');window.location='media.php?module=tambahalumni'</script>\n";
  }else{
  if (empty($lokasi_file)) {
      $insert = mysql_query("INSERT INTO alumni(nisn_alumni, 
                                              nm_alumni, 
                                              kelamin_alumni, 
                                              email_alumni,
                                              no_telp_alumni,
                                              tmplhr_alumni,
                                              tgllhr_alumni,
                                              agama_alumni,
                                              alamat_alumni,
                                              status_alumni,
                                              keterangan_alumni) 
                                              VALUES('$nisn', 
                                                     '$nama', 
                                                     '$jenis', 
                                                     '$email',
                                                     '$tel',
                                                     '$tempat_lahir',
                                                     '$tgl',
                                                     '$agama',
                                                     '$alamat',
                                                     '$status',
                                                     '$ket')");
  }elseif($file_size > $max_size){
    echo "<script>";
    echo "window.alert('File Size Gambar Terlalu Besar')";
    echo "</script>";
  }
  else {
    move_uploaded_file($lokasi_file,"../foto_alumni/$nama_file");
      $insert = mysql_query("INSERT INTO alumni(nisn_alumni,
                                                nm_alumni, 
                                                foto_alumni,
                                                kelamin_alumni, 
                                                email_alumni,
                                                no_telp_alumni,
                                                tmplhr_alumni,
                                                tgllhr_alumni,
                                                agama_alumni,
                                                alamat_alumni,
                                                status_alumni,
                                                keterangan_alumni) 
                                                VALUES('$nisn', 
                                                       '$nama', 
                                                       '$nama_file',
                                                       '$jenis', 
                                                       '$email',
                                                       '$tel',
                                                       '$tempat_lahir',
                                                       '$tgl',
                                                       '$agama',
                                                       '$alamat',
                                                       '$status',
                                                       '$ket')");
  }

  if ($insert) {
    header('location:alumni.html'); 
  }else{
    echo "Data gagal disimpan".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  }
}elseif($_GET[module]=='editalumni'){
  $edit=mysql_query("SELECT * FROM alumni WHERE id_alumni='$_GET[id]'");
    $r=mysql_fetch_array($edit);
    echo "<div class='panel-heading'>
                Edit Data Alumni
                </div>
                <div class='panel-body'>";
    echo "<form name='myform' method=POST action='media.php?module=aksieditalumni' onSubmit='return validasi_al()' enctype='multipart/form-data'>
          <input type=hidden name=id value='$r[id_alumni]'>
          <table>

          <tr><td>NISN Alumni</td><td> : <input class=field type=text name='nisn' maxlength='10' value='$r[nisn_alumni]' onkeypress='return hanyaAngka(event)'></td></tr>
          <tr><td>Nama Alumni</td><td> : <input class=field type=text name='nama' maxlength='30' value='$r[nm_alumni]'></td></tr>
          <tr><td></td><td> : <img src='../foto_alumni/$r[foto_alumni]' width=100 height=50></td></tr>
          <tr><td>Foto Alumni</td><td> : <input type=file name=fupload> * kosongkan jika tidak ingin diubah</td></tr>";

            if ($r[kelamin_alumni]=='L'){
              echo "<tr><td valign='top'>Jenis Kelamin</td>
                    <td> : <input type=radio name='jenis' value='L' checked>Laki-Laki
                         <input type=radio name='jenis' value='P'> Perempuan</td></tr>";
            }
            else{
              echo "<tr><td valign='top'>Jenis Kelamin</td>
                    <td> : <input type=radio name='jenis' value='L'>Laki-Laki  
                         <input type=radio name='jenis' value='P' checked>Perempuan</td></tr>";
            }

          echo "
          <tr><td>No Telp</td><td> : <input class=field type=text name=telepon value='$r[no_telp_alumni]' maxlength=12 onkeypress='return hanyaAngka(event)'></td></tr>
          <tr><td>Email</td><td> : <input class=field type=email name=email value='$r[email_alumni]'></td></tr>
          <tr><td>Agama</td>
          <td>: <select name='agama' class=field>
          <option value=$r[agama_alumni] selected> $r[agama_alumni]</option>
          <option value=Islam>Islam</option>
          <option value=Kristen>Kristen</option>
          <option value=Hindu>Hindu</option>
          <option value=Budha>Budha</option>
          </select></td></tr>
          <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir' value='$r[tmplhr_alumni]'></td></tr>

          <tr><td>Tanggal Lahir</td><td>: <input class=field type=text id=tgl_al name='tgl_lahir' value='$r[tgllhr_alumni]'></td></tr>

          <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=4>$r[alamat_alumni]</textarea></td></tr>
          <tr><td>Status</td>
          <td>: <select name='status' class=field>
          <option value=$r[status_alumni] selected> $r[status_alumni] </option>
          <option value=Kuliah>Kuliah</option>
          <option value=Kerja>Kerja</option>
          <option value=NGANGGUR>NGANGGUR</option>
          <option value=Lain-Lain>Lain-Lain</option>
          </select></td></tr>
          <tr><td valign=top>Keterangan status</td><td>: <textarea class=field name=keterangan rows=3>$r[keterangan_alumni]</textarea></td></tr>
          <tr><td></td/><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksieditalumni'){
  $nisn = $_POST[nisn];
  $nama = $_POST[nama];
  $file_size  = $_FILES[fupload][size];
  $max_size = 100000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_file   = $_FILES[fupload][name];
  $jenis = $_POST[jenis];
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];

  $tgl=$_POST[tgl_lahir];
  
  $alamat = $_POST[alamat];
  $status = $_POST[status];
  $ket = $_POST[keterangan];

  if (empty($lokasi_file)) {
    $ubah = mysql_query("UPDATE alumni SET nisn_alumni = '$nisn', 
                                           nm_alumni = '$nama', 
                                           kelamin_alumni = '$jenis', 
                                           email_alumni = '$email', 
                                           no_telp_alumni = '$tel', 
                                           tmplhr_alumni = '$tempat_lahir', 
                                           tgllhr_alumni = '$tgl', 
                                           agama_alumni = '$agama', 
                                           alamat_alumni = '$alamat', 
                                           status_alumni = '$status', 
                                           keterangan_alumni = '$ket' 
                                           WHERE id_alumni = '$_POST[id]'");
  }elseif($file_size > $max_size){
    echo "<script>";
    echo "window.alert('File Size Gambar Terlalu Besar')";
    echo "</script>";
  }else {
    move_uploaded_file($lokasi_file,"../foto_alumni/$nama_file");
    $ubah = mysql_query("UPDATE alumni SET 
                                          nisn_alumni = '$nisn', 
                                          nm_alumni = '$nama', 
                                          foto_alumni = '$nama_file', 
                                          kelamin_alumni = '$jenis', 
                                          email_alumni = '$email', 
                                          no_telp_alumni = '$tel', 
                                          tmplhr_alumni = '$tempat_lahir', 
                                          tgllhr_alumni = '$tgl', 
                                          agama_alumni = '$agama', 
                                          alamat_alumni = '$alamat', 
                                          status_alumni = '$status', 
                                          keterangan_alumni = '$ket' 
                                          WHERE id_alumni = '$_POST[id]'");
  }

  if ($ubah) {
    header('location:alumni.html'); 
  }else{
    echo "Data gagal diubah".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif($_GET[module]=='hapusalumni'){
  mysql_query("DELETE FROM alumni WHERE id_alumni='$_GET[id]'");
  header('location:alumni.html');
}

?>

