
<?php

if ($_GET[module]=='learning'){ 
  if ($_SESSION['leveluser'] == 'guru'){
  echo "<div class='panel-heading'>
                Manajemen Materi atau E-learning
                </div>
                <div class='panel-body'>";
  echo " <input class=button-submit type=button value='Tambah learning' 
          onclick=\"window.location.href='media.php?module=tambahlearning';\">

          <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>Nama Learning</th>
                  <th class='data nosorting' width=90px>Action</th>
                </tr>
              </thead>
              <tbody>";
                    $sql = mysql_query("SELECT * from karyawan b
                            join learning a
                            on b.id_karyawan = a.id_karyawan
                            where nip = $_SESSION[nip] ORDER BY nm_learning desc");
                    $no = 1;
                    while ($r=mysql_fetch_array($sql)){
          
            echo "<tr class='data'><td class='data'>$no</td>
            <td class='data'>$r[nm_learning]</td>
            <td class='data' align=center><a class=button-action href=media.php?module=editlearning&id=$r[id_learning]>Edit</a> | 
                     <a class=button-hapus href=media.php?module=hapuslearning&id=$r[id_learning] onClick=\"return confirm('Anda yakin menghapus $r[nm_learning]?')\">Hapus</a>
            </td>
          </tr>";
          $no++;
        }
        echo "</tbody></table></div>";

  }elseif ($_SESSION['leveluser'] == 'admin'){
    echo "<div class='panel-heading'>
                Manajemen Materi atau E-learning
                </div>
                <div class='panel-body'>";
  echo "  <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>Nama Learning</th>
                  <th class='data nosorting' width=90px>Action</th>
                </tr>
              </thead>
              <tbody>";
                    $sql = mysql_query("SELECT * from learning ORDER BY nm_learning desc");
                    $no = 1;
                    while ($r=mysql_fetch_array($sql)){
          
            echo "<tr class='data'><td class='data'>$no</td>
            <td class='data'>$r[nm_learning]</td>
            <td class='data' align=center><a class=button-action href=media.php?module=editlearning&id=$r[id_learning]>Edit</a> | 
                     <a class=button-hapus href=media.php?module=hapuslearning&id=$r[id_learning] onClick=\"return confirm('Anda yakin menghapus $r[nm_learning]?')\">Hapus</a>
            </td>
          </tr>";
          $no++;
        }
        
        echo "</tbody></table></div>";
  }
  
}elseif($_GET[module]=='tambahlearning'){
echo "<div class='panel-heading'>
                Tambah E-learning
                </div>
                <div class='panel-body'>";
echo "<form name='myform' method=POST action='media.php?module=aksitambahlearning' onSubmit='return validasi_el()' enctype='multipart/form-data'>
          <table>
          <tr><td>Nama Learning</td><td> : <input type=text name='nama' maxlength='50' size='70'></td></tr>
          <tr><td>File Learning</td><td> : <input type=file name=fupload accept='.pdf, .doc, .xls, .ppt'></td></tr>
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksitambahlearning'){
  $nama = $_POST[nama];
  $ses = $_SESSION[id];
  $file_size  = $_FILES[fupload][size];
  $max_size = 3000000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_file   = $_FILES[fupload][name];

  $eror   = false;
  //type file yang bisa diupload
  $file_type  = array('pdf','doc','xls','ppt');
  //cari extensi file dengan menggunakan fungsi explode
  $explode  = explode('.',$nama_file);
  $extensi  = $explode[count($explode)-1];
 

if(!in_array($extensi,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai, file harus bertipe pdf, doc, xls, ppt<br />';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum<br />';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo "<script> 
            onload = function(){
              alert('$pesan');onclick=self.history.back()
            return false;
            }
          </script>\n";
  }
elseif (!empty($lokasi_file)) {
      move_uploaded_file($lokasi_file,"../file_learning/$nama_file");
      $insert = mysql_query("INSERT INTO learning(nm_learning, 
                                                file_learning,
                                                id_karyawan) 
                                                VALUES('$nama', 
                                                       '$nama_file',
                                                       '$ses')");
}
  

  if ($insert) {
    header('location:learning.html'); 
  }else{
    echo "Data gagal disimpan".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif($_GET[module]=='editlearning'){
  $edit=mysql_query("SELECT * FROM learning WHERE id_learning='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit E-learning
                </div>
                <div class='panel-body'>";
    echo "<form name='myform' method=POST action='media.php?module=aksieditlearning' onSubmit='return validasi_el()' enctype='multipart/form-data'>
          <input type=hidden name=id value='$r[id_learning]'>
          <table>

          <tr><td>Nama learning</td><td> <input type=text name='nama' size=70 maxlength='50' value='$r[nm_learning]'></td></tr>
          <tr><td></td><td> $r[nm_learning] </td></tr>
          <tr><td>File learning</td><td> <input type=file name=fupload accept='.pdf, .doc, .xls, .ppt'> * kosongkan jika tidak ingin diubah</td></tr>

           
          <tr><td></td><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksieditlearning'){
  $nama = $_POST[nama];
  $file_size  = $_FILES[fupload][size];
  $max_size = 3000000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_file   = $_FILES[fupload][name];
 
  $eror   = false;
  //type file yang bisa diupload
  $file_type  = array('pdf','doc','xls','ppt');
  //cari extensi file dengan menggunakan fungsi explode
  $explode  = explode('.',$nama_file);
  $extensi  = $explode[count($explode)-1];
 

if (empty($lokasi_file)) {
    $ubah = mysql_query("UPDATE learning SET  
                                          nm_learning = '$nama'
                                          WHERE id_learning = '$_POST[id]'");
  }if(!in_array($extensi,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai, file harus bertipe pdf, doc, xls, ppt <br />';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum<br />';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo "<script> 
            onload = function(){
              alert('$pesan');onclick=self.history.back()
            return false;
            }
          </script>\n";
  }else {
   move_uploaded_file($lokasi_file,"../file_learning/$nama_file");
    $ubah = mysql_query("UPDATE learning SET  
                                          nm_learning = '$nama', 
                                          file_learning = '$nama_file'
                                          WHERE id_learning = '$_POST[id]'");
}

  if ($ubah) {
    header('location:learning.html'); 
  }else{
    echo "Data gagal diubah".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif($_GET[module]=='hapuslearning'){
  mysql_query("DELETE FROM learning WHERE id_learning='$_GET[id]'");
  header('location:learning.html');
}

?>

