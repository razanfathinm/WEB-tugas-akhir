<?php
  $kel=$_GET['kelas'];
  $tahu=$_GET['tahun'];

    header("location:media.php?module=tampiljadwal&ke=$kel&ta=$tahu");
?>