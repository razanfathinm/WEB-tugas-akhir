<?php
if ($_GET[module]=='nilai_siswa'){ 
 
    echo "<div class='panel-heading'>
                Manajemen KHS
                </div>
                <div class='panel-body'>";
  echo "  <div align=center>
            <table class='data' width=100% cellpadding=6>
            <form action='media.php?module=tampilkannilai' name=myform method=POST onSubmit='return valid_khs()'>
            
              <tr align=center>
                <td>
                mapel : 
                  <select name=mapel>
                    <option value=0 selected> Pilih Mapel </option>";
                    $mak = mysql_query("SELECT * from mapel a
                                          JOIN detail_mapel b ON b.id_mapel=a.id_mapel
                                          WHERE b.id_karyawan=$_SESSION[id]");
                    while($m=mysql_fetch_array($mak)){
                        echo "<option value=$m[id_mapel]>$m[nm_mapel]</option>";
                    }
                      echo "
                  </select>
                Kelas : 
                  <select name=kelas>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT DISTINCT a.id_kelas, a.nm_kelas from kelas a
                                          JOIN jadwal b ON b.id_kelas=a.id_kelas
                                          WHERE b.id_karyawan=$_SESSION[id]");
                    while($w=mysql_fetch_array($kel)){
                        echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                    }
                      echo "
                  </select>
                Semester : 
                  <select name=semester>
                    <option value=0 selected> Pilih Semester </option>";
                    $l = mysql_query("SELECT DISTINCT semester from khs");
                    while($d=mysql_fetch_array($l)){
                      echo "<option value=$d[semester]>$d[semester]</option>";
                    }
                      echo "
                  </select> 
                  Tahun Ajaran : 
                  <select name=tahun id=tahun>
                    <option value=0 selected> Pilih Tahun </option>";
                    $k = mysql_query("SELECT DISTINCT thn_ajaran from khs order by thn_ajaran");
                    while($c=mysql_fetch_array($k)){
                        echo "<option value=$c[thn_ajaran]>$c[thn_ajaran]</option>";
                      
                    }
                      echo "
                  </select> 
                  <input class=button-submit type=submit name=submit value='Tampilkan'></td>
              </tr>
             </form>
            </table>
            </div>";
        echo "</tbody></table></div>";
  
}elseif ($_GET[module]=='tampilkannilai'){ 

    $tam=mysql_query("SELECT * FROM mapel a
                        JOIN jadwal b ON b.id_mapel=a.id_mapel
                        JOIN kelas c ON c.id_kelas=b.id_kelas where a.id_mapel=$_POST[mapel] AND c.id_kelas=$_POST[kelas]");
    $t = mysql_fetch_array($tam);
    $rata=mysql_query("SELECT AVG (nilai) AS rata FROM khs WHERE id_mapel=$_POST[mapel] AND id_kelas=$_POST[kelas] AND semester='$_POST[semester]' AND thn_ajaran='$_POST[tahun]'");
    $tara = mysql_fetch_array($rata);
    echo "<div class='panel-heading'>
                KHS Siswa
                </div>
                <div class='panel-body'>";
  echo "<div>
            <div><h3>Mata Pelajaran : $t[nm_mapel]</h3></div>
            <div><h3>Kelas : $t[nm_kelas]</h3></div>
            </div>";
            echo "
          <div align=center>
            <table class='data' width=100% cellpadding=6>
                <tr>
                  <th class='data' width=30px>No</th>
                  <th class='data'>NISN Siswa</th>
                  <th class='data'>Nama Siswa</th>
                  <th class='data' width=100px>Nilai</th>
                </tr>";
                    $kas = mysql_query("SELECT * from khs a
                                          JOIN siswa b ON b.id_siswa=a.id_siswa where a.id_mapel=$_POST[mapel] AND a.id_kelas=$_POST[kelas] AND a.semester='$_POST[semester]' AND a.thn_ajaran='$_POST[tahun]'");
                    
                    $no = 1;
                    while ($r=mysql_fetch_array($kas)){
                       if(($no % 2)==0){
                          $warna="#ffffff";
                          }
                          else{
                          $warna="#E1E1E1";
                          }
                           echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
                            <td class='data'>$r[nisn_siswa]</td>
                            <td class='data'>$r[nm_siswa]</td>
                            <td class='data' align=center>$r[nilai]</td>
            </td>
          </tr>";
          $no++;
        }
        echo "
          <tr>
          <td colspan=3 align=right>Rata-Rata</td> <td align=center>$tara[rata]</td>
          </tr>
        </table>
        </div>
        </div>";
  
}
?>