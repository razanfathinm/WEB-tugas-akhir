
<?php

if ($_GET[module]=='siswa'){ 

  echo "<div class='panel-heading'>
                Manajemen Data Siswa
                </div>
                <div class='panel-body'>";
  echo "<input  class=button-submit type=button value='Tambah siswa' 
          onclick=\"window.location.href='media.php?module=tambahsiswa';\">

          <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>NISN</th>
                  <th class='data'>Nama Siswa</th>
                  <th class='data nosorting' width=130px>Action</th>
                </tr>
              </thead>
              <tbody>";
                    $sql = mysql_query("SELECT * FROM siswa ORDER BY nisn_siswa ASC");
                    $no = 1;
                    while ($r=mysql_fetch_array($sql)){
          
                       echo "<tr class='data'><td class='data'>$no</td>
            <td class='data'>$r[nisn_siswa]</td>
            <td class='data'>$r[nm_siswa]</td>
            <td class='data' align=center><a class=button-action href=media.php?module=editsiswa&id=$r[id_siswa]>Edit</a> | 
                     <a class=button-hapus href=media.php?module=hapussiswa&id=$r[id_siswa] onClick=\"return confirm('Anda yakin menghapus $r[nm_siswa]?')\">Hapus</a> | <a class=button-cetak href='cetaksiswa.php?id=$r[id_siswa]' target='_blank'>Cetak</a>
            </td>
          </tr>";
          $no++;
        }
        
        echo "</tbody></table>";
    echo "</div>";
  
}elseif($_GET[module]=='tambahsiswa'){
  echo "<div class='panel-heading'>
                Tambah Siswa
                </div>
                <div class='panel-bod'>";

echo " <form name='myform' method=POST action='media.php?module=aksitambahsiswa' onSubmit='return validasi_sis()' enctype='multipart/form-data'>
          <div class='row'>
              <div class='col-lg-6'>
                    <table>
                      <tr><td>NISN Siswa</td><td> : <input class=field type=text name='nisn' maxlength='10' placeholder='Masukan NISN Siswa' onkeypress='return hanyaAngka(event)'></td></tr>
                      <tr><td>Nama Siswa</td><td> : <input class=field type=text name='nama' maxlength='30' placeholder='Masukan Nama Siswa'></td></tr>

                      <tr><td></td><td>: <img id=preview src=../images/camera.png width=100px></td></tr>
                      <tr><td>Foto Siswa</td><td> : <input type=file id=fupload name=fupload class=input accept='.jpg, .png'  onchange=tampilkanPreview(this,'preview') /></td></tr>
                      <tr><td></td><td style='color:red'>*File tipe jpg or png</td></tr>
                     
                      <tr><td>Jenis Kelamin</td><td> : <input type=radio name=jenis value='L' checked>Laki-Laki
                                                      <input type=radio name=jenis value='P'>Perempuan</td></tr>
                      <tr><td>No Telp</td><td> : <input class=field type=text name=telepon maxlength=12 onkeypress='return hanyaAngka(event)' placeholder='Ex. 08xxxxxxxx'></td></tr>
                      <tr><td>Email</td><td> : <input class=field type=email name=email placeholder='example@email.com'></td></tr>
                      <tr><td>Agama</td> 
                      <td>: <select name='agama' class=field >
                      <option value=0 selected> Pilih Agama</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      </select></td></tr>
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir'></td></tr>

                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text readonly id='tanggal_siswa' name=tgl_siswa></td></tr>
                      <tr><td>Kegemaran</td>
                      <td>: <select name='hobi' class=field>
                      <option value=0 selected> Pilih </option>
                      <option value=Kesenian>Kesenian</option>
                      <option value=Olahraga>Olahraga</option>
                      <option value=Organisasi>Organisasi</option>
                      <option value=Lain-Lain>Lain-Lain</option>
                      </select></td></tr>
                      <tr><td>Ket. Kegemaran</td><td> : <input class=field type=text name=kegemaran></td></tr>

                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=5></textarea></td></tr>

                      <tr><td>Transportasi Ke Sekolah</td>
                      <td>: <select name='trans' class=field>
                      <option value=0 selected> Pilih </option>
                      <option value=Umum>Transportasi Umum</option>
                      <option value=Pribadi>Transportasi Pribadi</option>
                      </select></td></tr>
                      
                      <tr><td>Golongan Darah</td>
                      <td>: <select name='darah' class=tfield>
                      <option value=0 selected> Pilih </option>
                      <option value=A>A</option>
                      <option value=B>B</option>
                      <option value=AB>AB</option>
                      <option value=O>O</option>
                      </select></td></tr>
                      
                      <tr><td>Tinggi Badan</td><td> : <input class=tfield type=text name=tinggi size=5 maxlength=3 onkeypress='return hanyaAngka(event)'> Cm</td></tr>
                      
                      <tr><td>Berat Badan</td><td> : <input class=tfield type=text name=berat size=5 maxlength=3 onkeypress='return hanyaAngka(event)'> Kg</td></tr>
                      
                      <tr><td>Anak Ke</td><td> : <input class=tfield type=text name=anak size=5 maxlength=2 onkeypress='return hanyaAngka(event)'></td></tr>
                      
                    </table>  
              </div>

              <div class='col-lg-4'>
                    <table>
                      <tr><td>Nama Ayah</td><td> : <input class=field type=text name=nm_ayah maxlength=30 placeholder='Masukan Nama Ayah'></td></tr>
                      
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name=tmp_ayah></td></tr>
                      
                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text readonly id='tanggal' name=tgl_ayah></td></tr>
                      
                      <tr><td>Agama</td>
                      <td>: <select name='agama_ayah' class=field >
                      <option value=0 selected> Pilih Agama</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan_ayah placeholder='Ex. S1 Teknik Informatika'></td></tr>
                      
                      <tr><td>Pekerjaan</td><td> : <input class=field type=text name=pekerjaan_ayah></td></tr>
                      
                      <tr><td>Penghasilan</td><td> : <input class=field type=text name=penghasilan_ayah id=peng_ayah></td></tr>

                      <tr><td>No Telpon</td><td> : <input class=field type=text name=telp_ayah maxlength=12 onkeypress='return hanyaAngka(event)' placeholder='Ex. 08xxxxxxxx'></td></tr>
                      
                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat_ayah rows=4></textarea></td></tr>

                      <tr><td>Status Hidup</td>
                      <td>: <select name='status_ayah' class=field >
                      <option value=Hidup selected> hidup</option>
                      <option value=Meninggal>Meninggal</option>
                      </select></td></tr>
                      </table>

                      <hr>
                      <table>
                      <tr><td>Nama ibu</td><td> : <input class=field type=text name=nm_ibu maxlength=30 placeholder='Masukan Nama Ibu'></td></tr>
                      
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name=tmp_ibu></td></tr>
                      
                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text id='tanggal_ibu' name=tgl_ibu></td></tr>
                      
                      <tr><td>Agama</td>
                      <td>: <select name='agama_ibu' class=field >
                      <option value=0 selected> Pilih Agama</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan_ibu placeholder='Ex. S1 Teknik Informatika'></td></tr>
                      
                      <tr><td>Pekerjaan</td><td> : <input class=field type=text name=pekerjaan_ibu></td></tr>
                      
                      <tr><td>Penghasilan</td><td> : <input class=field type=text name=penghasilan_ibu id=peng_ibu></td></tr>
                      
                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat_ibu rows=4></textarea></td></tr>

                    </table>  

                    <hr>
                      <table>
                      <tr><td>Nama wali</td><td> : <input class=field type=text name=nm_wali maxlength=30 placeholder='Masukan Nama Wali Siswa'></td></tr>
                      
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name=tmp_wali></td></tr>
                      
                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text id='tanggal_wali' name=tgl_wali></td></tr>
                      
                      <tr><td>Agama</td>
                      <td>: <select name='agama_wali' class=field >
                      <option value=0 selected> Pilih Agama</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan_wali placeholder='Ex. S1 Teknik Informatika'></td></tr>
                      
                      <tr><td>Pekerjaan</td><td> : <input class=field type=text name=pekerjaan_wali></td></tr>
                      
                      <tr><td>Penghasilan</td><td> : <input class=field type=text name=penghasilan_wali id=peng_wali></td></tr>
                      
                      <tr><td>No Telpon</td><td> : <input class=field type=text name=telp_wali maxlength=12 onkeypress='return hanyaAngka(event)' placeholder='Ex. 08xxxxxxxx'></td></tr>
                      
                      <tr><td valign=top>Alamat</td><td>: <textarea name=alamat_wali class=field rows=4></textarea></td></tr>

                    </table>
                </div>
            </div>

              <table width=100% cellpadding=0>
                    <tr><td colspan=2><input class=button-submit type=submit value=Simpan>
                            <input type=button class=button-exit value=Batal onclick=self.history.back()></td></tr>
              </table>
              </form></div>";
      
}elseif($_GET[module]=='aksitambahsiswa'){
  $nisn = $_POST[nisn];
  $pass_n = substr($_POST[nisn], 4,6);
  $pass_a = substr($_POST[nama], 0,2);
  $nama = $_POST[nama];
  $file_size  = $_FILES[fupload][size];
  $max_size = 1000000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_f   = $_FILES[fupload][name];

  $acak      = "SMKN2-";
  $nama_file = ($acak.$nisn.substr($nama_f, -4));

  $jenis = $_POST[jenis];
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];

  $tgl=$_POST[tgl_siswa];
  
  $alamat = $_POST[alamat];
  $hobi = $_POST[hobi];
  $ket_hobi = $_POST[kegemaran];
  $trans = $_POST[trans];
  $darah = $_POST[darah];
  $tinggi = $_POST[tinggi];
  $berat = $_POST[berat];
  $anak = $_POST[anak];

  $ayah = $_POST[nm_ayah];
  $tmp_ayah = $_POST[tmp_ayah];
  $tgl_ayah = $_POST[tgl_ayah];
  $agama_ayah = $_POST[agama_ayah];
  $pendidikan_ayah = $_POST[pendidikan_ayah];
  $pekerjaan_ayah = $_POST[pekerjaan_ayah];
  $penghasilan_ayah = $_POST[penghasilan_ayah];
  $alamat_ayah = $_POST[alamat_ayah];
  $status_ayah = $_POST[status_ayah];
  $telp_ayah = $_POST[telp_ayah];

  $ibu = $_POST[nm_ibu];
  $tmp_ibu = $_POST[tmp_ibu];
  $tgl_ibu = $_POST[tgl_ibu];
  $agama_ibu = $_POST[agama_ibu];
  $pendidikan_ibu = $_POST[pendidikan_ibu];
  $pekerjaan_ibu = $_POST[pekerjaan_ibu];
  $penghasilan_ibu = $_POST[penghasilan_ibu];
  $alamat_ibu = $_POST[alamat_ibu];

  $wali = $_POST[nm_wali];
  $tmp_wali = $_POST[tmp_wali];
  $tgl_wali = $_POST[tgl_wali];
  $agama_wali = $_POST[agama_wali];
  $pendidikan_wali = $_POST[pendidikan_wali];
  $pekerjaan_wali = $_POST[pekerjaan_wali];
  $penghasilan_wali = $_POST[penghasilan_wali];
  $alamat_wali = $_POST[alamat_wali];
  $telp_wali = $_POST[telp_wali];

  $eror   = false;
  //type file yang bisa diupload
  $file_type  = array('jpg','png');
  //cari extensi file dengan menggunakan fungsi explode
  $explode  = explode('.',$nama_file);
  $extensi  = $explode[count($explode)-1];

$cekdata = mysql_query("SELECT nisn_siswa from siswa WHERE nisn_siswa='$nisn'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> alert('NISN Sudah Ada Didalam Database');window.location='media.php?module=tambahsiswa'</script>\n";
  }else{

if (empty($lokasi_file)) {
      $insert = mysql_query("INSERT INTO siswa(nisn_siswa,
                                                nm_siswa,
                                                jenis_kelamin,
                                                tgl_lahir,
                                                tempat_lhr,
                                                agama,
                                                no_telp,
                                                hobby,
                                                ket_hobi,
                                                email,
                                                alamat,
                                                transportasi,   
                                                 gol_darah,   
                                                 tinggi,   
                                                 berat,   
                                                 anak_ke,   
                                                 nm_ayah,  
                                                 tgl_lhr_ayah,   
                                                 tmp_lhr_ayah,   
                                                 agama_ayah, 
                                                 pendidikan_ayah,   
                                                 pekerjaan_ayah,  
                                                 penghasilan_ayah,   
                                                 alamat_ayah, 
                                                 status_hidup_ayah,   
                                                 no_telp_ayah,   
                                                 nm_ibu,   
                                                 tgl_lhr_ibu,   
                                                 tmp_lhr_ibu,   
                                                 agama_ibu, 
                                                 pendidikan_ibu,  
                                                 pekerjaan_ibu,  
                                                 penghasilan_ibu,   
                                                 alamat_ibu,   
                                                 nm_wali, 
                                                 tgl_lhr_wali,   
                                                 tmp_lhr_wali,   
                                                 agama_wali, 
                                                 pendidikan_wali,   
                                                 pekerjaan_wali,  
                                                 penghasilan_wali,   
                                                 alamat_wali,   
                                                 no_telp_wali,
                                                 pass_siswa,
                                                 status_siswa) 
                                              VALUES('$nisn', 
                                                     '$nama',
                                                     '$jenis', 
                                                     '$tgl',
                                                     '$tempat_lahir',
                                                     '$agama',
                                                     '$tel',
                                                     '$hobi',
                                                     '$ket_hobi',
                                                     '$email',
                                                     '$alamat',
                                                     '$trans',
                                                     '$darah',
                                                     '$tinggi',
                                                     '$berat',
                                                     '$anak',
                                                     '$ayah',
                                                     '$tgl_ayah',
                                                     '$tmp_ayah',
                                                     '$agama_ayah',
                                                     '$pendidikan_ayah',
                                                     '$pekerjaan_ayah',
                                                     '$penghasilan_ayah',
                                                     '$alamat_ayah',
                                                     '$status_ayah',
                                                     '$telp_ayah',
                                                     '$ibu',
                                                     '$tgl_ibu',
                                                     '$tmp_ibu',
                                                     '$agama_ibu',
                                                     '$pendidikan_ibu',
                                                     '$pekerjaan_ibu',
                                                     '$penghasilan_ibu',
                                                     '$alamat_ibu',
                                                     '$wali',
                                                     '$tgl_wali',
                                                     '$tmp_wali',
                                                     '$agama_wali',
                                                     '$pendidikan_wali',
                                                     '$pekerjaan_wali',
                                                     '$penghasilan_wali',
                                                     '$alamat_wali',
                                                     '$telp_wali',
                                                     '$pass_a$pass_n',
                                                     'aktif')");

  }if(!in_array($extensi,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai file harus bertipe jpg atau png<br />';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum<br />';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo "<script> 
            onload = function(){
              alert('$pesan');onclick=self.history.back()
            return false;
            }
          </script>\n";
  }
  else {
    move_uploaded_file($lokasi_file,"../foto_siswa/$nama_file");
      $insert = mysql_query("INSERT INTO siswa(nisn_siswa,
                                                nm_siswa,
                                                foto_siswa,
                                                jenis_kelamin,
                                                tgl_lahir,
                                                tempat_lhr,
                                                agama,
                                                no_telp,
                                                hobby,
                                                ket_hobi,
                                                email,
                                                alamat, 
                                                 transportasi,   
                                                 gol_darah,   
                                                 tinggi,   
                                                 berat,   
                                                 anak_ke,   
                                                 nm_ayah,  
                                                 tgl_lhr_ayah,   
                                                 tmp_lhr_ayah,   
                                                 agama_ayah, 
                                                 pendidikan_ayah,   
                                                 pekerjaan_ayah,  
                                                 penghasilan_ayah,   
                                                 alamat_ayah, 
                                                 status_hidup_ayah,   
                                                 no_telp_ayah,   
                                                 nm_ibu,   
                                                 tgl_lhr_ibu,   
                                                 tmp_lhr_ibu,   
                                                 agama_ibu, 
                                                 pendidikan_ibu,  
                                                 pekerjaan_ibu,  
                                                 penghasilan_ibu,   
                                                 alamat_ibu,   
                                                 nm_wali, 
                                                 tgl_lhr_wali,   
                                                 tmp_lhr_wali,   
                                                 agama_wali, 
                                                 pendidikan_wali,   
                                                 pekerjaan_wali,  
                                                 penghasilan_wali,   
                                                 alamat_wali,   
                                                 no_telp_wali,
                                                 pass_siswa,
                                                 status_siswa) 
                                              VALUES('$nisn', 
                                                     '$nama',
                                                     '$nama_file', 
                                                     '$jenis', 
                                                     '$tgl',
                                                     '$tempat_lahir',
                                                     '$agama',
                                                     '$tel',
                                                     '$hobi',
                                                     '$ket_hobi',
                                                     '$email',
                                                     '$alamat',
                                                     '$trans',
                                                     '$darah',
                                                     '$tinggi',
                                                     '$berat',
                                                     '$anak',
                                                     '$ayah',
                                                     '$tgl_ayah',
                                                     '$tmp_ayah',
                                                     '$agama_ayah',
                                                     '$pendidikan_ayah',
                                                     '$pekerjaan_ayah',
                                                     '$penghasilan_ayah',
                                                     '$alamat_ayah',
                                                     '$status_ayah',
                                                     '$telp_ayah',
                                                     '$ibu',
                                                     '$tgl_ibu',
                                                     '$tmp_ibu',
                                                     '$agama_ibu',
                                                     '$pendidikan_ibu',
                                                     '$pekerjaan_ibu',
                                                     '$penghasilan_ibu',
                                                     '$alamat_ibu',
                                                     '$wali',
                                                     '$tgl_wali',
                                                     '$tmp_wali',
                                                     '$agama_wali',
                                                     '$pendidikan_wali',
                                                     '$pekerjaan_wali',
                                                     '$penghasilan_wali',
                                                     '$alamat_wali',
                                                     '$telp_wali',
                                                     '$pass_a$pass_n',
                                                     'aktif')");
  
  }
  
    if ($insert) {
      header('location:siswa.html'); 
    }else{
      echo "Data gagal disimpan".mysql_error();
      echo " <input type=button value=Kembali onclick=self.history.back()>";
    }
  }
  
}elseif($_GET[module]=='editsiswa'){
  $edi=mysql_query("SELECT * FROM siswa WHERE id_siswa='$_GET[id]'");
  $ed=mysql_query("SELECT * FROM siswa a
                    JOIN detail_kelas b ON b.id_siswa=a.id_siswa 
                    JOIN kelas c ON c.id_kelas=b.id_kelas WHERE a.id_siswa='$_GET[id]'");
    $r=mysql_fetch_array($edi);
    $u=mysql_fetch_array($ed);
    $stat = substr($u[nm_kelas], 0,3);

    echo "<div class='panel-heading'>
                Edit Siswa
                </div>
                <div class='panel-bod'>";
    echo "<form name='myform' method=POST action='media.php?module=aksieditsiswa' onSubmit='return validasi_sis()' enctype='multipart/form-data'>

          <input type=hidden name=id value='$r[id_siswa]'>
            <div class='row'>
              <div class='col-lg-6'>
                    <table>
                      <tr><td>NISN siswa</td><td> : <input class=field type=text name='nisn' maxlength='10' value='$r[nisn_siswa]' onkeypress='return hanyaAngka(event)'></td></tr>
                      <tr><td>Nama siswa</td><td> : <input class=field type=text name='nama' maxlength='30' value='$r[nm_siswa]'></td></tr>
                      <tr><td></td><td> : <img id=preview src='../foto_siswa/$r[foto_siswa]' width=100 height=50></td></tr>
                      <tr><td>Foto siswa</td><td> : <input type=file name=fupload class=input accept='.jpg, .png'  onchange=tampilkanPreview(this,'preview') ></td></tr>
                      
                      <tr><td></td><td style='color:red'>*File tipe jpg or png</td></tr>
                      <tr><td></td><td> * kosongkan jika tidak ingin diubah</td></tr>";

                        if ($r[jenis_kelamin]=='L'){
                          echo "<tr><td valign='top'>Jenis Kelamin</td>
                                <td> : <input type=radio name='jenis' value='L' checked>Laki-Laki
                                     <input type=radio name='jenis' value='P'> Perempuan</td></tr>";
                        }
                        else{
                          echo "<tr><td valign='top'>Jenis Kelamin</td>
                                <td> : <input type=radio name='jenis' value='L'>Laki-Laki  
                                     <input type=radio name='jenis' value='P' checked>Perempuan</td></tr>";
                        }

                      echo "
                      <tr><td>No Telp</td><td> : <input class=field type=text name=telepon maxlength=12 value='$r[no_telp]' onkeypress='return hanyaAngka(event)'></td></tr>
                      <tr><td>Email</td><td> : <input class=field type=email name=email value='$r[email]'></td></tr>
                      <tr><td>Agama</td>
                      <td>: <select name='agama' class=field>
                      <option value=$r[agama] selected> $r[agama]</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name='tempat_lahir' value='$r[tempat_lhr]'></td></tr>

                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text readonly id='tanggal_siswa' name=tgl_siswa value='$r[tgl_lahir]'></td></tr>
                      <tr><td>Hobi</td>
                      <td>: <select name='hobi' class=field>
                      <option value=$r[hobby] selected> $r[hobby] </option>
                      <option value=Kesenian>Kesenian</option>
                      <option value=Olahraga>Olahraga</option>
                      <option value=Organisasi>Organisasi</option>
                      <option value=Lain-Lain>Lain-Lain</option>
                      </select></td></tr>
                      <tr><td>Ket. Kegemaran</td><td> : <input class=field type=text name=kegemaran value='$r[ket_hobi]'></td></tr>

                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat rows=4>$r[alamat]</textarea></td></tr>
                      
                      <tr><td>Transportasi Ke Sekolah</td>
                      <td>: <select name='trans' class=field>
                      <option value=$r[transportasi] selected> $r[transportasi] </option>
                      <option value=Umum>Transportasi Umum</option>
                      <option value=Pribadi>Transportasi Pribadi</option>
                      </select></td></tr>

                      <tr><td>Golongan Darah</td>
                      <td>: <select name='darah' class=field>
                      <option value=$r[gol_darah] selected> $r[gol_darah] </option>
                      <option value=A>A</option>
                      <option value=B>B</option>
                      <option value=AB>AB</option>
                      <option value=O>O</option>
                      </select></td></tr>
                      
                      <tr><td>Tinggi Badan</td><td> : <input class=tfield type=text name=tinggi value='$r[tinggi]' maxlength=3 onkeypress='return hanyaAngka(event)'> Cm</td></tr>
                      
                      <tr><td>Berat Badan</td><td> : <input class=tfield type=text name=berat maxlength=3 value='$r[berat]' onkeypress='return hanyaAngka(event)'> Kg</td></tr>
                      
                      <tr><td>Anak Ke</td><td> : <input class=tfield type=text name=anak maxlength=2 value='$r[anak_ke]' onkeypress='return hanyaAngka(event)'></td></tr>
                      ";
                      if ($stat == 'XII') {
                        echo "<tr><td>Status Siswa</td>
                      <td>: <select name='status_siswa' class=field>
                      <option value=$r[status_siswa] selected> $r[status_siswa] </option>
                      <option value=lulus>Lulus</option>
                      <option value=aktif>Aktif</option>
                      </select></td></tr>";
                      }
                      if ($_SESSION['leveluser'] == 'admin') {
                        echo "<tr><td>Password Siswa</td><td> : <input class=field type=text name=pass size=30 value='$r[pass_siswa]' maxlength=8></td></tr>";
                      }
                      
                      echo "
                    </table>  
              </div>

              <div class='col-lg-4'>
                    <table>
                      <tr><td>Nama Ayah</td><td> : <input class=field type=text name=nm_ayah value='$r[nm_ayah]'></td></tr>
                      
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name=tmp_ayah value='$r[tmp_lhr_ayah]'></td></tr>
                      
                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text id='tanggal' name=tgl_ayah value='$r[tgl_lhr_ayah]'></td></tr>
                      
                      <tr><td>Agama</td>
                      <td>: <select name='agama_ayah' class=field>
                      <option value=$r[agama_ayah] selected> $r[agama_ayah]</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan_ayah value='$r[pendidikan_ayah]'></td></tr>
                      
                      <tr><td>Pekerjaan</td><td> : <input class=field type=text name=pekerjaan_ayah value='$r[pekerjaan_ayah]'></td></tr>
                      
                      <tr><td>Penghasilan</td><td> : <input class=field type=text name=penghasilan_ayah id=peng_ayah value='$r[penghasilan_ayah]'></td></tr>

                      <tr><td>No Telpon</td><td> : <input class=field type=text name=telp_ayah maxlength=12 value='$r[no_telp_ayah]' onkeypress='return hanyaAngka(event)'></td></tr>
                      
                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat_ayah rows=3>$r[alamat_ayah]</textarea></td></tr>

                      <tr><td>Status Hidup</td>
                      <td>: <select name='status_ayah' class=field>
                      <option value=$r[status_hidup_ayah] selected> $r[status_hidup_ayah]</option>
                      <option value=Meniggal>Meninggal</option>
                      <option value=Hidup>Hidup</option>
                      </select></td></tr>
                      </table>

                      <hr>
                      <table>
                      <tr><td>Nama ibu</td><td> : <input class=field type=text name=nm_ibu value='$r[nm_ibu]'></td></tr>
                      
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name=tmp_ibu value='$r[tmp_lhr_ibu]'></td></tr>
                      
                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text id='tanggal_ibu' name=tgl_ibu value='$r[tgl_lhr_ibu]'></td></tr>
                      
                      <tr><td>Agama</td>
                      <td>: <select name='agama_ibu' class=field>
                      <option value=$r[agama_ibu] selected> $r[agama_ibu]</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan_ibu value='$r[pendidikan_ibu]'></td></tr>
                      
                      <tr><td>Pekerjaan</td><td> : <input class=field type=text name=pekerjaan_ibu value='$r[pekerjaan_ibu]'></td></tr>
                      
                      <tr><td>Penghasilan</td><td> : <input class=field type=text name=penghasilan_ibu id=peng_ibu value='$r[penghasilan_ibu]'></td></tr>
                      
                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat_ibu rows=3>$r[alamat_ibu]</textarea></td></tr>

                    </table>  

                    <hr>
                      <table>
                      <tr><td>Nama wali</td><td> : <input class=field type=text name=nm_wali value='$r[nm_wali]'></td></tr>
                      
                      <tr><td>Tempat Lahir</td><td> : <input class=field type=text name=tmp_wali value='$r[tmp_lhr_wali]'></td></tr>
                      
                      <tr><td>Tanggal Lahir</td><td> : <input class=field type=text id='tanggal_wali' name=tgl_wali value='$r[tgl_lhr_wali]'></td></tr>
                      
                      <tr><td>Agama</td>
                      <td>: <select name='agama_wali' class=field>
                      <option value=$r[agama_wali] selected> $r[agama_wali]</option>
                      <option value=Islam>Islam</option>
                      <option value=Kristen>Kristen</option>
                      <option value=Hindu>Hindu</option>
                      <option value=Budha>Budha</option>
                      <option value=Kong-Hu-Chu>Kong-Hu-Chu</option>
                      </select></td></tr>

                      <tr><td>Pendidikan</td><td> : <input class=field type=text name=pendidikan_wali value='$r[pendidikan_wali]'></td></tr>
                      
                      <tr><td>Pekerjaan</td><td> : <input class=field type=text name=pekerjaan_wali value='$r[pekerjaan_wali]'></td></tr>
                      
                      <tr><td>Penghasilan</td><td> : <input class=field type=text name=penghasilan_wali id=peng_wali value='$r[penghasilan_wali]'></td></tr>
                      
                      <tr><td>No Telpon</td><td> : <input class=field type=text name=telp_wali maxlength=12 value='$r[no_telp_wali]' onkeypress='return hanyaAngka(event)'></td></tr>
                      
                      <tr><td valign=top>Alamat</td><td>: <textarea class=field name=alamat_wali rows=3>$r[alamat_wali]</textarea></td></tr>

                    </table>
                </div>
            </div>

              <table width=100% cellpadding=0>
                    <tr><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
              </table>
            </form></div>";
      
}elseif($_GET[module]=='aksieditsiswa'){
   $nisn = $_POST[nisn];
  $nama = $_POST[nama];
  $file_size  = $_FILES[fupload][size];
  $max_size = 1000000; // 1MB
  $lokasi_file = $_FILES[fupload][tmp_name];
  $nama_f   = $_FILES[fupload][name];

  $acak      = "SMKN2-";
  $nama_file = ($acak.$nisn.substr($nama_f, -4));

  $jenis = $_POST[jenis];
  $tel = $_POST[telepon];
  $email = $_POST[email];
  $agama = $_POST[agama];
  $tempat_lahir = $_POST[tempat_lahir];
  $stat = $_POST[status_siswa];
  $pass = $_POST[pass];

  $tgl=$_POST[tgl_siswa];
  
  $alamat = $_POST[alamat];
  $hobi = $_POST[hobi];
  $ket_hobi = $_POST[kegemaran];
  $trans = $_POST[trans];
  $darah = $_POST[darah];
  $tinggi = $_POST[tinggi];
  $berat = $_POST[berat];
  $anak = $_POST[anak];

  $ayah = $_POST[nm_ayah];
  $tmp_ayah = $_POST[tmp_ayah];
  $tgl_ayah = $_POST[tgl_ayah];
  $agama_ayah = $_POST[agama_ayah];
  $pendidikan_ayah = $_POST[pendidikan_ayah];
  $pekerjaan_ayah = $_POST[pekerjaan_ayah];
  $penghasilan_ayah = $_POST[penghasilan_ayah];
  $alamat_ayah = $_POST[alamat_ayah];
  $status_ayah = $_POST[status_ayah];
  $telp_ayah = $_POST[telp_ayah];

  $ibu = $_POST[nm_ibu];
  $tmp_ibu = $_POST[tmp_ibu];
  $tgl_ibu = $_POST[tgl_ibu];
  $agama_ibu = $_POST[agama_ibu];
  $pendidikan_ibu = $_POST[pendidikan_ibu];
  $pekerjaan_ibu = $_POST[pekerjaan_ibu];
  $penghasilan_ibu = $_POST[penghasilan_ibu];
  $alamat_ibu = $_POST[alamat_ibu];

  $wali = $_POST[nm_wali];
  $tmp_wali = $_POST[tmp_wali];
  $tgl_wali = $_POST[tgl_wali];
  $agama_wali = $_POST[agama_wali];
  $pendidikan_wali = $_POST[pendidikan_wali];
  $pekerjaan_wali = $_POST[pekerjaan_wali];
  $penghasilan_wali = $_POST[penghasilan_wali];
  $alamat_wali = $_POST[alamat_wali];
  $telp_wali = $_POST[telp_wali];

  $eror   = false;
  //type file yang bisa diupload
  $file_type  = array('jpg','png');
  //cari extensi file dengan menggunakan fungsi explode
  $explode  = explode('.',$nama_file);
  $extensi  = $explode[count($explode)-1];

 if (empty($lokasi_file)) {
    $ubah = mysql_query("UPDATE siswa SET nisn_siswa = '$nisn', 
                                           nm_siswa = '$nama', 
                                           jenis_kelamin = '$jenis', 
                                           tgl_lahir = '$tgl', 
                                           tempat_lhr = '$tempat_lahir', 
                                           agama = '$agama', 
                                           no_telp = '$tel', 
                                           hobby = '$hobi', 
                                           ket_hobi = '$ket_hobi', 
                                           email = '$email', 
                                           alamat = '$alamat', 
                                           transportasi = '$trans' , 
                                           gol_darah = '$darah', 
                                           tinggi = '$tinggi', 
                                           berat = '$berat', 
                                           anak_ke = '$anak', 
                                           nm_ayah = '$ayah', 
                                           tgl_lhr_ayah = '$tgl_ayah', 
                                           tmp_lhr_ayah = '$tmp_ayah', 
                                           agama_ayah = '$agama_ayah', 
                                           pendidikan_ayah = '$pendidikan_ayah', 
                                           pekerjaan_ayah = '$pekerjaan_ayah', 
                                           penghasilan_ayah = '$penghasilan_ayah', 
                                           alamat_ayah = '$alamat_ayah', 
                                           status_hidup_ayah = '$status_ayah', 
                                           no_telp_ayah = '$telp_ayah', 
                                           nm_ibu = '$ibu', 
                                           tgl_lhr_ibu = '$tgl_ibu', 
                                           tmp_lhr_ibu = '$tmp_ibu', 
                                           agama_ibu = '$agama_ibu', 
                                           pendidikan_ibu = '$pendidikan_ibu', 
                                           pekerjaan_ibu = '$pekerjaan_ibu', 
                                           penghasilan_ibu = '$penghasilan_ibu', 
                                           alamat_ibu = '$alamat_ibu', 
                                           nm_wali = '$wali', 
                                           tgl_lhr_wali = '$tgl_wali', 
                                           tmp_lhr_wali = '$tmp_wali', 
                                           agama_wali = '$agama_wali', 
                                           pendidikan_wali = '$pendidikan_wali', 
                                           pekerjaan_wali = '$pekerjaan_wali', 
                                           penghasilan_wali = '$penghasilan_wali', 
                                           alamat_wali = '$alamat_wali', 
                                           no_telp_wali = '$telp_wali', 
                                           pass_siswa = '$pass', 
                                           status_siswa = '$stat'
                                           WHERE id_siswa = '$_POST[id]'");
  }if(!in_array($extensi,$file_type)){
    $eror   = true;
    $pesan .= '- Type file yang anda upload tidak sesuai file harus bertipe jpg atau png<br />';
  }
  if($file_size > $max_size){
    $eror   = true;
    $pesan .= '- Ukuran file melebihi batas maximum<br />';
  }
  //check ukuran file apakah sudah sesuai

  if($eror == true){
    echo "<script> 
            onload = function(){
              alert('$pesan');onclick=self.history.back()
            return false;
            }
          </script>\n";
  }else {
    $d = '../foto_siswa/'.$nama_file;
      unlink ("$d");
    move_uploaded_file($lokasi_file,"../foto_siswa/$nama_file");
    $ubah = mysql_query("UPDATE siswa SET nisn_siswa = '$nisn', 
                                           nm_siswa = '$nama', 
                                           foto_siswa = '$nama_file',
                                           jenis_kelamin = '$jenis', 
                                           tgl_lahir = '$tgl', 
                                           tempat_lhr = '$tempat_lahir', 
                                           agama = '$agama', 
                                           no_telp = '$tel', 
                                           hobby = '$hobi', 
                                           ket_hobi = '$ket_hobi', 
                                           email = '$email', 
                                           alamat = '$alamat', 
                                           transportasi = '$trans', 
                                           gol_darah = '$darah', 
                                           tinggi = '$tinggi', 
                                           berat = '$berat', 
                                           anak_ke = '$anak', 
                                           nm_ayah = '$ayah', 
                                           tgl_lhr_ayah = '$tgl_ayah', 
                                           tmp_lhr_ayah = '$tmp_ayah', 
                                           agama_ayah = '$agama_ayah', 
                                           pendidikan_ayah = '$pendidikan_ayah', 
                                           pekerjaan_ayah = '$pekerjaan_ayah', 
                                           penghasilan_ayah = '$penghasilan_ayah', 
                                           alamat_ayah = '$alamat_ayah', 
                                           status_hidup_ayah = '$status_ayah', 
                                           no_telp_ayah = '$telp_ayah', 
                                           nm_ibu = '$ibu', 
                                           tgl_lhr_ibu = '$tgl_ibu', 
                                           tmp_lhr_ibu = '$tmp_ibu', 
                                           agama_ibu = '$agama_ibu', 
                                           pendidikan_ibu = '$pendidikan_ibu', 
                                           pekerjaan_ibu = '$pekerjaan_ibu', 
                                           penghasilan_ibu = '$penghasilan_ibu', 
                                           alamat_ibu = '$alamat_ibu', 
                                           nm_wali = '$wali', 
                                           tgl_lhr_wali = '$tgl_wali', 
                                           tmp_lhr_wali = '$tmp_wali', 
                                           agama_wali = '$agama_wali', 
                                           pendidikan_wali = '$pendidikan_wali', 
                                           pekerjaan_wali = '$pekerjaan_wali', 
                                           penghasilan_wali = '$penghasilan_wali', 
                                           alamat_wali = '$alamat_wali', 
                                           no_telp_wali = '$telp_wali', 
                                           pass_siswa = '$pass', 
                                           status_siswa = '$stat' 
                                           WHERE id_siswa = '$_POST[id]'");
  }

  if ($ubah) {
    header('location:siswa.html'); 
  }else{
    echo "Data gagal diubah. <br>".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif($_GET[module]=='hapussiswa'){
  $hapus=mysql_query("SELECT * FROM siswa WHERE id_siswa='$_GET[id]'");
    $r=mysql_fetch_array($hapus);
  $d = '../foto_siswa/'.$r[foto_siswa];
  unlink ("$d");
  mysql_query("DELETE FROM siswa WHERE id_siswa='$_GET[id]'");
  header('location:siswa.html');
}

?>

