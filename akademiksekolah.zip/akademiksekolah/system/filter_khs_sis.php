<?php
  $kel=$_GET['kelas'];
  $sem=$_GET['semester'];
  $tah=$_GET['tahun'];

    header("location:media.php?module=tampilkankhs&ke=$kel&se=$sem&ta=$tah");
?>