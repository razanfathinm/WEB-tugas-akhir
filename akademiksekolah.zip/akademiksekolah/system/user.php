
<?php

if ($_GET[module]=='user'){ 
  echo "<div class='panel-heading'>
                Manajemen ADMIN
                </div>
                <div class='panel-body'>
          <input class=button-submit type=button value='Tambah ADMIN' 
          onclick=\"window.location.href='media.php?module=tambahuser';\">
          <table class='data' width=100% cellpadding=6>
      <tr>
        <th class='data' width=30px>No</th>
        <th class='data'>Username</th>
        <th class='data'>Nama ADMIN</th>
        <th class='data' align='center' width='110px;'>Action</th>
      </tr>"; 
    $tampil=mysql_query("SELECT * FROM user ORDER BY id_user DESC");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
  if(($no % 2)==0){
      $warna="#ffffff";
      }
      else{
      $warna="#E1E1E1";
      }
       echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
        <td class='data'>$r[username]</td>
        <td class='data'>$r[nama_lengkap]</td>
        <td class='data' align=center><a class=button-action href=media.php?module=edituser&id=$r[id_user]>Edit</a> | 
                 <a class=button-hapus href=media.php?module=hapususer&id=$r[id_user] onClick=\"return confirm('Anda yakin menghapus $r[nama_lengkap]?')\">Hapus</a>
        </td>
      </tr>";
      $no++;
    }
    echo "</table></div>";
  
}elseif($_GET[module]=='tambahuser'){
  echo "<div class='panel-heading'>
                Tambah ADMIN
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksitambahuser' onSubmit='return validasi_use()'>
          <table>
          <tr><td>Nama Admin</td><td> <input class=field type=text name='nama_admin'></td></tr>
          <tr><td>Username</td><td> <input class=field type=text name='nama_user'></td></tr>
          <tr><td>Password</td><td> <input style='width: 250px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' class='form-password' type='password' name=pass maxlength=8></td></tr>
            <tr><td></td><td><input type='checkbox' class='form-checkbox'> Show password</td></tr>
          <tr><td></td><td><input class=button-submit type=submit name=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksitambahuser'){
  $user_nama = $_POST[nama_user];
  $pass = $_POST[pass];
  $nama_admin = $_POST[nama_admin];
  $cekdata = mysql_query("SELECT * from user WHERE username='$user_nama' AND password='$pass'");
  if (mysql_num_rows($cekdata)>0) {
    echo "<script> 
            onload = function(){
              alert('User telah ada didalam database!');onclick=self.history.back()
            return false;
            }
          </script>\n";
  }else{
  mysql_query("INSERT INTO user(username, nama_lengkap, password, level) VALUES('$user_nama', '$nama_admin', '$pass', 'admin')");
  header('location:user.html');
}
  
}elseif($_GET[module]=='edituser'){
  $edit=mysql_query("SELECT * FROM user WHERE id_user='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<div class='panel-heading'>
                Edit user
                </div>
                <div class='panel-body'>
          <form name='myform' method=POST action='media.php?module=aksiedituser' onSubmit='return validasi_use()'>
          <input type=hidden name=id value='$r[id_user]'>
          <table>
          <tr><td>Nama user</td><td> <input class=field type=text name='nama_admin' value='$r[nama_lengkap]'></td></tr>
          <tr><td>Username</td><td> <input class=field type=text name='nama_user' value='$r[username]'></td></tr>
          <tr><td>Password Siswa</td><td> <input style='width: 250px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' class='form-password' type='password' name=pass value='$r[password]' maxlength=8></td></tr>
            <tr><td></td><td><input type='checkbox' class='form-checkbox'> Show password</td></tr>
          <tr><td></td><td><input class=button-submit type=submit value=Update>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
      
}elseif($_GET[module]=='aksiedituser'){
  mysql_query("UPDATE user SET username = '$_POST[nama_user]', nama_lengkap = '$_POST[nama_admin]', password = '$_POST[pass]' WHERE id_user = '$_POST[id]'");
  echo "<script> alert('Data Berhasil diubah');window.location='user.html'</script>\n";
  
}elseif($_GET[module]=='hapususer'){
  mysql_query("DELETE FROM user WHERE id_user='$_GET[id]'");
  header('location:user.html');
}

?>