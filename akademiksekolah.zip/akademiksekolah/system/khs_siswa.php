<?php

if ($_GET[module]=='khs_siswa'){ 
  $khs=mysql_query("SELECT * FROM khs where id_siswa=$_SESSION[id] AND id_kelas=$_GET[ke] AND semester='$_GET[se]' AND thn_ajaran='$_GET[ta]'");
    $r = mysql_fetch_array($khs);
    echo "<div class='panel-heading'>
                Manajemen KHS
                </div>
                <div class='panel-body'>";
  echo "  <div align=center>
            <table class='data' width=100% cellpadding=6>
            <form action='filter_khs_sis.php' name=myform method=GET onSubmit='return valid_khs()'>
            
              <tr align=center>
                <td>
                Kelas : 
                  <select name=kelas class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT * from kelas a
                                          JOIN detail_kelas b ON b.id_kelas=a.id_kelas
                                          WHERE b.id_siswa=$_SESSION[id]");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_kelas]==$w[id_kelas]){
                        echo "<option value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                      }
                       else{
                        echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                      }
                    }
                      echo "
                  </select>
                Semester : 
                  <select name=semester class=kfield>
                    <option value=0 selected> Pilih Semester </option>";
                    $l = mysql_query("SELECT DISTINCT semester from khs WHERE id_siswa=$_SESSION[id]");
                    while($d=mysql_fetch_array($l)){
                      echo "<option value=$d[semester]>$d[semester]</option>";
                    }
                      echo "
                  </select> 
                  Tahun Ajaran : 
                  <select name=tahun id=tahun class=kfield>
                    <option value=0 selected> Pilih Tahun </option>";
                    $k = mysql_query("SELECT DISTINCT thn_ajaran from khs WHERE id_siswa=$_SESSION[id]");
                    while($c=mysql_fetch_array($k)){
                        echo "<option value=$c[thn_ajaran]>$c[thn_ajaran]</option>";
                      
                    }
                      echo "
                  </select> 
                  <input class=button-submit type=submit name=submit value='Tampilkan'></td>
              </tr>
             </form>
            </table>
            </div>";
        echo "</tbody></table></div>";
  
}elseif ($_GET[module]=='tampilkankhs'){ 

    $tam=mysql_query("SELECT * FROM khs a
                        JOIN siswa b ON b.id_siswa=a.id_siswa
                        JOIN kelas c ON c.id_kelas=a.id_kelas
                        JOIN jurusan d ON d.id_jurusan=a.id_jurusan where a.id_siswa=$_SESSION[id] AND a.id_kelas=$_GET[ke] AND a.semester='$_GET[se]' AND a.thn_ajaran='$_GET[ta]'");
    $t = mysql_fetch_array($tam);
    $rata=mysql_query("SELECT AVG (nilai) AS rata FROM khs WHERE id_siswa=$_SESSION[id] AND id_kelas=$_GET[ke] AND semester='$_GET[se]' AND thn_ajaran='$_GET[ta]'");
    $tara = mysql_fetch_array($rata);
    echo "<div class='panel-heading'>
                KHS Siswa
                </div>
                <div class='panel-body'>";
  echo "<div align=left style='margin-left:50px;'>
            <div><h3>Nama : $t[nm_siswa]</h3></div>
            <div><h3>Kelas : $t[nm_kelas]</h3></div>
            <div><h3>Jurusan : $t[nm_jurusan]</h3></div>
            </div>";
            echo "
          <div align=center>
            <table class='data' width=75% cellpadding=6>
                <tr>
                  <th class='data' width=30px>No</th>
                  <th class='data'>Mata Pelajaran</th>
                  <th class='data' width=100px>Nilai</th>
                </tr>";
                    $kas = mysql_query("SELECT * from khs a
                                          JOIN mapel b ON b.id_mapel=a.id_mapel where a.id_siswa=$_SESSION[id] AND a.id_kelas=$_GET[ke] AND a.semester='$_GET[se]' AND a.thn_ajaran='$_GET[ta]'");
                    
                    $no = 1;
                    while ($r=mysql_fetch_array($kas)){
                       if(($no % 2)==0){
                          $warna="#ffffff";
                          }
                          else{
                          $warna="#E1E1E1";
                          }
                           echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
                            <td class='data'>$r[nm_mapel]</td>
                            <td class='data' align=center>$r[nilai]</td>
            </td>
          </tr>";
          $no++;
        }
        echo "
          <tr>
          <td colspan=2 align=right>Rata-Rata</td> <td align=center>$tara[rata]</td>
          </tr>
        </table>
        </div>
          <div align=center>
          <input class=button-exit type=button value='Cetak KHS' 
          onclick=\"window.open('cetakkhssiswa.php?id=$_SESSION[id]&se=$_GET[se]&th=$_GET[ta]');\">
          </div>
        </div>";
  
}
?>