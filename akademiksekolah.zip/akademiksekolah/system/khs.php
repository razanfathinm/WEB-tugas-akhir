<?php

if ($_GET[module]=='khs'){ 
  $khs=mysql_query("SELECT * FROM khs where id_kelas=$_GET[ke] AND semester='$_GET[se]' AND thn_ajaran='$_GET[ta]'");
    $r = mysql_fetch_array($khs);
    echo "<div class='panel-heading'>
                Manajemen KHS
                </div>
                <div class='panel-body'>";
  echo "<span style='float:left'>
          <input class=button-exit style='padding=30px;' type=button value='Tambahkan Siswa Kedalam Data KHS' 
          onclick=\"window.location.href='media.php?module=tambah_khs_siswa';\"></span><br>
            <div align=center style='padding-top:20px;'>
            <table class='data' width=100% cellpadding=6>
            <form action='filter_khs.php' name=myform method=GET onSubmit='return valid_khs()'>
            
              <tr align=center>
                <td>
                Kelas : 
                  <select name=kelas class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT * from kelas order by nm_kelas");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_kelas]==$w[id_kelas]){
                        echo "<option value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                      }
                       else{
                        echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                      }
                    }
                      echo "
                  </select>
                Semester : 
                  <select name=semester class=kfield>
                    <option value=0 selected> Pilih Semester </option>";
                    $l = mysql_query("SELECT DISTINCT semester from khs");
                    while($d=mysql_fetch_array($l)){
                      if ($r[semester]==$d[semester]){
                        echo "<option value=$d[semester] selected>$d[semester]</option>";
                      }
                       else{
                        echo "<option value=$d[semester]>$d[semester]</option>";
                      }
                    }
                      echo "
                  </select> 
                  Tahun Ajaran : 
                  <select name=tahun class=kfield>
                    <option value=0 selected> Pilih Tahun </option>";
                    $k = mysql_query("SELECT DISTINCT thn_ajaran from khs");
                    while($c=mysql_fetch_array($k)){
                      if ($r[thn_ajaran]==$c[thn_ajaran]){
                        echo "<option value=$c[thn_ajaran] selected>$c[thn_ajaran]</option>";
                      }
                       else{
                        echo "<option value=$c[thn_ajaran]>$c[thn_ajaran]</option>";
                      }
                    }
                      echo "
                  </select> 
                  <input class=button-cetak type=submit name=submit value='Tampilkan'></td>
              </tr>
             </form>
            </table>
            </div>";
            echo "
            <table id='data' class='display' width=100% cellpadding=0>
              <thead>
                <tr>
                  <th class='data' width=20px>No</th>
                  <th class='data'>NISN</th>
                  <th class='data'>Nama Siswa</th>";

                  if($_SESSION[leveluser]=='admin' || $_SESSION[leveluser]=='tu'){ 
                  echo "<th class='data nosorting' width=90px>Action</th>";
                  } echo "  
                </tr>
              </thead>
              <tbody>";
                    $kas = mysql_query("SELECT DISTINCT a.id_siswa, a.semester, a.thn_ajaran, b.nisn_siswa, b.nm_siswa from khs a
                                          JOIN siswa b ON b.id_siswa=a.id_siswa where a.id_kelas=$_GET[ke] AND a.semester='$_GET[se]' AND a.thn_ajaran='$_GET[ta]'");
                    
                    $no = 1;
                    while ($i=mysql_fetch_array($kas)){
                       echo "<tr class='data'><td class='data'>$no</td>
                            <td class='data'>$i[nisn_siswa]</td>
                            <td class='data'>$i[nm_siswa]</td>
                            <td class='data' align=center><a class=button-action href=media.php?module=tampilkhs&id=$i[id_siswa]&se=$i[semester]&th=$i[thn_ajaran]>Lihat KHS</a>
            </td>
          </tr>";
          $no++;
        }
        echo "</tbody></table></div>";
  
}elseif ($_GET[module]=='tambah_khs_siswa'){
  $ks=mysql_query("SELECT * FROM detail_kelas a
                    JOIN kelas b ON a.id_kelas=b.id_kelas
                    JOIN jurusan c ON c.id_jurusan=b.id_jurusan where a.id_kelas=$_GET[ke] AND a.tahun_ajaran='$_GET[ta]'");
    $r=mysql_fetch_array($ks);

    echo "<div class='panel-heading'>
                Manajemen KHS Siswa
                </div>
                <div class='panel-body'>";
  echo "<div align=center>
            <table class='data' width=100% cellpadding=6>
            <form action='filter_tam_khs.php' name=myform method=GET onSubmit='return valid_khs_tam()'>
              <tr align=center>
                <td>
                Kelas : 
                  <select name=kelas class=kfield>
                    <option value=0 selected> Pilih Kelas </option>";
                    $kel = mysql_query("SELECT * from kelas order by nm_kelas");
                    while($w=mysql_fetch_array($kel)){
                      if ($r[id_kelas]==$w[id_kelas]){
                        echo "<option value=$w[id_kelas] selected>$w[nm_kelas]</option>";
                      }
                       else{
                        echo "<option value=$w[id_kelas]>$w[nm_kelas]</option>";
                      }
                    }
                      echo "
                  </select>

                  Tahun Ajaran : 
                  <select name=tahun class=kfield>
                    <option value=0 selected> Pilih Tahun </option>";
                    $k = mysql_query("SELECT DISTINCT tahun_ajaran from detail_kelas");
                    while($c=mysql_fetch_array($k)){
                      if ($r[tahun_ajaran]==$c[tahun_ajaran]){
                        echo "<option value=$c[tahun_ajaran] selected>$c[tahun_ajaran]</option>";
                      }
                       else{
                        echo "<option value=$c[tahun_ajaran]>$c[tahun_ajaran]</option>";
                      }
                    }
                      echo "
                  </select> 
                  <input class=button-action type=submit name=submit value='Tampilkan'></td>
              </tr>
             </form>
            </table>
            </div>";

          echo "
          <div style='font-size:16px; '> Jurusan  : $r[nm_jurusan]</div>
          <table class='data' width=100% cellpadding=6>
          <tr><th colspan=4 align=center>$r[nm_kelas]</th></tr>
      <tr>
        <th class='data' width=30px>No</th>
        <th class='data'>NISN Kelas</th>
        <th class='data'>Nama Siswa</th>
        <th class='data' align='center' width='100px;'>Action</th>
      </tr>"; 


    $tampil=mysql_query("SELECT * from siswa a
                            join detail_kelas b ON a.id_siswa = b.id_siswa
                            join kelas c ON c.id_kelas = b.id_kelas
                            where b.id_kelas = '$_GET[ke]' AND b.tahun_ajaran='$_GET[ta]'");
    $no=1;
    while ($t=mysql_fetch_array($tampil)){
     if(($no % 2)==0){
      $warna="#ffffff";
      }
      else{
      $warna="#E1E1E1";
      }
       echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
        <td class='data'>$t[nisn_siswa]</td>
        <td class='data'>$t[nm_siswa]</td>
        <td class='data' align=center><a class=button-hapus href=media.php?module=tambahkhs&id=$t[id_siswa]&th=$t[tahun_ajaran]>Tambah KHS</a>
        </td>
      </tr>";
      $no++;
    }
    echo "</table></div>";
  
}elseif ($_GET[module]=='tambahkhs'){ 
  echo "<div class='panel-heading'>
                Tambah KHS
                </div>
                <div class='panel-body'>";

      $khs=mysql_query("SELECT * FROM siswa a 
                          JOIN detail_kelas b ON a.id_siswa=b.id_siswa
                          JOIN kelas c ON c.id_kelas=b.id_kelas
                          JOIN jurusan d ON d.id_jurusan=c.id_jurusan where b.id_siswa='$_GET[id]' AND b.tahun_ajaran='$_GET[th]'");
      $q=mysql_fetch_array($khs);
  echo " <table>
          <tr>
          <td style='font-size:18px; font-weight:bold;'> Input Nilai KHS Untuk</td> <td style='font-size:18px; font-weight:bold;'> : $q[nm_siswa]</td>
          </tr>
          <tr>
          <td style='font-size:18px; font-weight:bold;'> Kelas </td><td style='font-size:18px; font-weight:bold;'> : $q[nm_kelas]</td>
          </tr>
          <tr>
          <td style='font-size:18px; font-weight:bold;'> Jurusan</td> <td style='font-size:18px; font-weight:bold;'> : $q[nm_jurusan]</td>
          </tr>
          </table>
          <hr>
          <form name='myform' method=POST action='media.php?module=aksitambahkhs' onSubmit='return validasi_khs()' enctype='multipart/form-data'>
          <input type=hidden name=id_sis value='$q[id_siswa]'>
          <input type=hidden name=id_kls value='$q[id_kelas]'>
          <input type=hidden name=id_jur value='$q[id_jurusan]'>
          <table>

          <tr>
            <td  style='padding-right:90px;'>Tahun Ajaran </td>
            <td> <input type=text readonly class=field name=tahun value='$_GET[th]'> </td></tr>

          <tr><td>Semester</td>
          <td  style='padding-right:90px;'><select name='semester' class=field>
          <option value=ganjil selected> Ganjil </option>
          <option value=genap>Genap</option>
          </select></td></tr>

          <tr>
          <td  style='padding-right:90px;'>Mata Pelajaran</td><td> 
              <select name=mapel id=mapel class=field>
                <option value=''> Pilih Mapel </option>";
                  $map=mysql_query("SELECT DISTINCT a.id_mapel, a.nm_mapel FROM mapel a
                                        INNER JOIN jadwal b ON b.id_mapel=a.id_mapel
                                        INNER JOIN kelas c ON c.id_kelas=b.id_kelas
                                        where c.id_kelas=$q[id_kelas] AND b.t_ajaran='$_GET[th]'");
                    while($mp=mysql_fetch_array($map)){
                      echo "<option value=$mp[id_mapel]>$mp[nm_mapel]</option>";
                    }
                      echo "</select></td></tr>
          <tr><td  style='padding-right:90px;'>Nilai</td> <td> <input class=tfield type=text name=nilai maxlength='3' onkeypress='return hanyaAngka(event)'></td></tr>

          <tr><td></td><td colspan=2><input class=button-submit type=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
  
}elseif ($_GET[module]=='editkhs'){ 
 echo "<div class='panel-heading'>
                Manajemen KHS
                </div>
                <div class='panel-body'>";
      $ss=mysql_query("SELECT * FROM siswa a 
                          JOIN detail_kelas b ON a.id_siswa=b.id_siswa
                          JOIN kelas c ON c.id_kelas=b.id_kelas
                          JOIN jurusan d ON d.id_jurusan=c.id_jurusan 
                          JOIN khs e ON e.id_siswa=a.id_siswa 
                          JOIN mapel f ON f.id_mapel=e.id_mapel where e.id_khs='$_GET[id]'");
      $q=mysql_fetch_array($ss);
      $khs=mysql_query("SELECT * FROM khs where id_khs='$_GET[id]'");
      $r=mysql_fetch_array($khs);
  echo "  <table style='font-size:16px'>
            <tr><td>Nama Siswa </td> <td> : $q[nm_siswa]</td> </tr>
            <tr><td>Kelas </td> <td> : $q[nm_kelas]</td> </tr>
            <tr><td>Jurusan </td> <td> : $q[nm_jurusan]</td> </tr>
          </table>
          <form name='myform' method=POST action='media.php?module=aksieditkhs' onSubmit='return validasi_khs()' enctype='multipart/form-data'>
          <input type=hidden name=id value='$r[id_khs]'>
          <input type=hidden name=id_sis value='$r[id_siswa]'>
          <input type=hidden name=id_kls value='$r[id_kelas]'>
          <input type=hidden name=id_jur value='$r[id_jurusan]'>
          <table>

          <tr><td>Semester</td> <td><input type=text readonly name=semester class=field value='$r[semester]'></td></tr>
          <tr><td>Tahun Ajaran</td> <td><input type=text readonly name=tahun class=field value='$r[thn_ajaran]'></td></tr>

          <tr>
          <td>Mata Pelajaran</td><td> 
              <select name=mapel id=mapel class=field>
                <option value=''> Pilih Mapel </option>";
                  $map=mysql_query("SELECT DISTINCT a.id_mapel, a.nm_mapel FROM mapel a
                                        INNER JOIN jadwal b ON b.id_mapel=a.id_mapel
                                        INNER JOIN kelas c ON c.id_kelas=b.id_kelas
                                        where c.id_kelas=$r[id_kelas] AND b.t_ajaran='$r[thn_ajaran]'");
                    while($w=mysql_fetch_array($map)){
                if ($r[id_mapel]==$w[id_mapel]){
                  echo "<option value=$w[id_mapel] selected>$w[nm_mapel]</option>";
                }
                else{
                  echo "<option value=$w[id_mapel]>$w[nm_mapel]</option>";
                }
              }
            echo "</select></td></tr>
          <tr><td>Nilai</td> <td> <input type=text name=nilai value=$r[nilai] maxlength='3' class=tfield onkeypress='return hanyaAngka(event)'></td></tr>

          <tr><td></td><td><input type=submit value=Update class=button-submit>
                            <input type=button class=button-exit value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
  
}elseif($_GET[module]=='aksieditkhs'){
  $kel = $_POST[id_kls];
  $sis = $_POST[id_sis];
  $jur = $_POST[id_jur];
  $sem = $_POST[semester];
  $mapel = $_POST[mapel];
  $tahun = $_POST[tahun];
  $nilai = $_POST[nilai];
  $ubah = mysql_query("UPDATE khs SET id_mapel = '$mapel', id_jurusan = '$jur', id_siswa = '$sis', id_kelas = '$kel', semester = '$sem', thn_ajaran = '$tahun', nilai = '$nilai' WHERE id_khs = '$_POST[id]'");
  

  if ($ubah) {
    echo "<script> alert('Data Berhasil diubah');window.location='media.php?module=tampilkhs&id=$sis&se=$sem&th=$tahun'</script>\n";
  }else{
    echo "Data gagal diubah".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  
}elseif($_GET[module]=='aksitambahkhs'){
  $sis = $_POST[id_sis];
  $kls = $_POST[id_kls];
  $jur = $_POST[id_jur];
  $mapel = $_POST[mapel];
  $tahun = $_POST[tahun];
  $semes = $_POST[semester];
  $nilai = $_POST[nilai];

  $cekdata = mysql_query("SELECT * from khs WHERE id_mapel='$mapel' AND id_jurusan='$jur' AND id_siswa='$sis' AND id_kelas='$kls' AND semester='$semes' AND thn_ajaran='$tahun'");
    
    if (mysql_num_rows($cekdata)>0) {
      echo "<script> 
        onload = function(){
          alert('Siswa telah memiliki KSH Mata Pelajaran ini! ');onclick=self.history.back()
        return false;
        }
      </script>\n";

    }else {
  $insert = mysql_query("INSERT INTO khs(id_mapel,id_jurusan,id_siswa,id_kelas,semester,thn_ajaran,nilai) 
                                                                VALUES('$mapel',
                                                                        '$jur',
                                                                        '$sis',
                                                                        '$kls',
                                                                        '$semes',
                                                                        '$tahun',
                                                                        '$nilai')");

  if ($insert) {
    echo "<script> alert('Data Berhasil Disimpan');window.location='khs.html'</script>\n";
  }else{
    echo "Data gagal disimpan".mysql_error();
    echo " <input type=button value=Kembali onclick=self.history.back()>";
  }
  }
}elseif ($_GET[module]=='tampilkhs'){ 

    $tam=mysql_query("SELECT * FROM khs a
                        JOIN siswa b ON b.id_siswa=a.id_siswa
                        JOIN kelas c ON c.id_kelas=a.id_kelas
                        JOIN jurusan d ON d.id_jurusan=a.id_jurusan
                        JOIN mapel e ON e.id_mapel=a.id_mapel where b.id_siswa=$_GET[id]");
    $t = mysql_fetch_array($tam);
    $rata=mysql_query("SELECT AVG (nilai) AS rata FROM khs WHERE id_siswa=$_GET[id] AND semester='$_GET[se]' AND thn_ajaran='$_GET[th]'");
    $tara = mysql_fetch_array($rata);
    echo "<div class='panel-heading'>
                Manajemen KHS Siswa
                </div>
                <div class='panel-body'>";
  echo "<table>
          <tr><td><h3>Nama</h3></td><td><h3> : $t[nm_siswa]</h3></td> </tr>
          <tr>  <td><h3>Kelas</h3></td><td><h3> : $t[nm_kelas]</h3></td></tr>
           <tr> <td><h3>Jurusan</h3></td><td><h3> : $t[nm_jurusan]</h3></td></tr>    
        </table>
            <span style='padding-bottom:20px;'>
          <input class=button-submit type=button value='Tambah Nilai Mapel' 
          onclick=\"window.location.href='media.php?module=tambahnilaikhs&id=$_GET[id]&se=$_GET[se]&th=$_GET[th]';\">
          <input class=button-exit type=button value='Cetak KHS' 
          onclick=\"window.open('cetakkhssiswa.php?id=$_GET[id]&se=$_GET[se]&th=$_GET[th]');\">
          </span>";
            echo "
            <table class='data' width=100% cellpadding=6>
              <tr>
                <th class='data' width=20px>No</th>
                <th class='data'>Mata Pelajaran</th>
                <th class='data'>Nilai</th>
                <th class='data' align='center' width='110px;'>Action</th>
              </tr>"; 
            $tampil=mysql_query("SELECT * from khs a
                                          JOIN mapel b ON b.id_mapel=a.id_mapel where a.id_siswa=$_GET[id] AND a.semester='$_GET[se]' AND a.thn_ajaran='$_GET[th]'");
            $no=1;
            while ($r=mysql_fetch_array($tampil)){
          if(($no % 2)==0){
              $warna="#ffffff";
              }
              else{
              $warna="#E1E1E1";
              }
               echo "<tr class='data' bgcolor=$warna><td class='data'>$no</td>
                <td class='data'>$r[nm_mapel]</td>
                            <td class='data' align=center>$r[nilai]</td>
                            <td class='data' align=center><a class=button-action href=media.php?module=editkhs&id=$r[id_khs]>Edit</a> | 
                     <a class=button-hapus href=media.php?module=hapuskhs&id=$r[id_khs]&kd=$t[id_siswa]&s=$t[semester]&t=$t[thn_ajaran] onClick=\"return confirm('Anda yakin menghapus KHS Mapel $r[nm_mapel]?')\">Hapus</a>
              </td>
              </tr>";
              $no++;
            }
            echo "<tr class='data'>
                <td class='data' align=right colspan=2>Rata-Rata</td> <td class='data' align=center>$tara[rata]</td> <td class='data'></td>
                </tr>
            </table></div>";
  
}elseif ($_GET[module]=='tambahnilaikhs'){ 
  echo "<div class='panel-heading'>
                Tambah KHS
                </div>
                <div class='panel-body'>";

      $khs=mysql_query("SELECT * FROM siswa a 
                          JOIN detail_kelas b ON a.id_siswa=b.id_siswa
                          JOIN kelas c ON c.id_kelas=b.id_kelas
                          JOIN jurusan d ON d.id_jurusan=c.id_jurusan 
                          JOIN khs e ON e.id_siswa=a.id_siswa where e.id_siswa='$_GET[id]' AND e.semester='$_GET[se]' AND e.thn_ajaran='$_GET[th]'");
      $q=mysql_fetch_array($khs);
  echo " <table>
          <tr>
          <td style='font-size:18px; font-weight:bold;'> Input Nilai KHS Untuk</td> <td style='font-size:18px; font-weight:bold;'> : $q[nm_siswa]</td>
          </tr>
          <tr>
          <td style='font-size:18px; font-weight:bold;'> Kelas </td><td style='font-size:18px; font-weight:bold;'> : $q[nm_kelas]</td>
          </tr>
          <tr>
          <td style='font-size:18px; font-weight:bold;'> Jurusan</td> <td style='font-size:18px; font-weight:bold;'> : $q[nm_jurusan]</td>
          </tr>
          </table>
          <hr>
          <form name='myform' method=POST action='media.php?module=aksitambahkhs' onSubmit='return validasi_khs()' enctype='multipart/form-data'>
          <input type=hidden name=id_sis value='$q[id_siswa]'>
          <input type=hidden name=id_kls value='$q[id_kelas]'>
          <input type=hidden name=id_jur value='$q[id_jurusan]'>
          <table>

          <tr><td style='padding-right:90px;'>Semester</td> <td> <input class=field type=text readonly name=semester value='$q[semester]'></td></tr>

          <tr>
            <td  style='padding-right:90px;'>Tahun Ajaran </td> <td><input type=text readonly name=tahun value='$q[thn_ajaran]' class=field></td></tr>

          <tr>
          <td  style='padding-right:90px;'>Mata Pelajaran</td><td> 
              <select name=mapel id=mapel class=field>
                <option value=''> Pilih Mapel </option>";
                  $map=mysql_query("SELECT DISTINCT a.id_mapel, a.nm_mapel FROM mapel a
                                        INNER JOIN jadwal b ON a.id_mapel=b.id_mapel
                                        INNER JOIN kelas c ON c.id_kelas=b.id_kelas
                                        where c.id_kelas=$q[id_kelas]");
                    while($mp=mysql_fetch_array($map)){
                      echo "<option value=$mp[id_mapel]>$mp[nm_mapel]</option>";
                    }
                      echo "</select></td></tr>
          <tr><td  style='padding-right:90px;'>Nilai</td> <td> <input class=tfield type=text name=nilai maxlength='3' onkeypress='return hanyaAngka(event)'></td></tr>

          <tr><td></td><td colspan=2><input class=button-submit type=submit value=Simpan>
                            <input class=button-exit type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form></div>";
  
}elseif($_GET[module]=='hapuskhs'){
  mysql_query("DELETE FROM khs WHERE id_khs='$_GET[id]' and id_siswa='$_GET[kd]'");
  echo "<script> alert('Data Berhasil dihapus');window.location='media.php?module=tampilkhs&id=$_GET[kd]&se=$_GET[s]&th=$_GET[t]'</script>\n";
}
?>