<?php
include "/config/koneksi.php";
$ambil_data = mysql_query("select * from berita where id_berita='$_GET[id]'");
$hasil_data = mysql_fetch_array($ambil_data);
?>
	<div id="latest">
     <div><h2><?=$hasil_data['jdl_berita'];?></h2> 
     <h5>By  <?=$hasil_data['penulis'];?> </h5></div> 
     <hr>
      <img src='gambar_berita/<?=$hasil_data['foto_berita'];?>' 
      width=440  hspace=10 border=0 align=left style='padding: 15px;'> 
     <h5 style="padding:10px;">Diposkan pada <?=$hasil_data['tgl_berita'];?> </h5>
      <p style="text-align:justify;"><?=$hasil_data['isi_berita'];?></p>
      </div>
      <div style="clear:both;"></div>
