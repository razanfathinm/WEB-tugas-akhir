<!DOCTYPE html>
<html>
<head>
	<title>Login</title>

	<link rel="stylesheet" type="text/css" href="style/style.css" />
</head>
<body>
<?php
	session_start();	
  	error_reporting(0);
  	include "config/koneksi.php";

if ($_GET['module']=='login'){
	if (!$_SESSION['namauser'] == ''){
		echo "<script> 
		          onload = function(){
		          alert('Anda Telah Login, Silahkan Logout Terlebih Dahulu!');window.location='home'
		          return false;
		              }
		          </script>\n";
	}else {	
		echo "<div id='loginForm'>
				<div class='headLoginForm'>Login Area</div>
					<div class='fieldLogin'>
						<form method=POST name='formku' onSubmit='return validasi_log()' action=cek_login.php>
						<label>Username</label><br>
						<input style='width: 230px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' type='text' class='login' name='id_user' autofocus><br>
						<label>Level</label><br>
						<select style='width: 230px; padding: 4px; color: #222;  background: #f4f6f9;  border: 1px solid #ccc; border-radius: 3px; margin:4px 0px 9px 0px' name=level class='login'>
							<option value='0' selected>&nbsp; &nbsp; - &nbsp; &nbsp; Pilih Level &nbsp; &nbsp; - &nbsp; &nbsp;</option>
							<option value='admin'>Admin</option>
							<option value='guru'>Guru</option>
							<option value='tu'>Tata Usaha</option>
							<option value='siswa'>Siswa</option>
						</select><br>
						<label>Password</label><br>
						<input style='width: 230px; padding: 4px; color: #222;  background: #f4f6f9;  margin-top: 0px; border: 1px solid #ccc; border-radius: 3px;' type='password' class='login' name='password'><br>
						<input type='submit' class=button-su value='Login'>
						</form>
					</div>
			</div>";  
	}
}
?>

<!-- validasi login-->
<script language='javascript'>
    function validasi_log(){
        var id         = formku.id_user.value;
        var level 		= formku.level.value;
        var pass         = formku.password.value;
        var pesan = '';
        
        if (id == '') {
            pesan = '-Username tidak boleh kosong\n';
        }
        if (level == 0) {
            pesan += '-Silahkan pilih level terlebih dahulu\n';
        }
        if (pass == '') {
            pesan += '-Password tidak boleh kosong\n';
        }
        
        if (pesan != '') {
            alert('Maaf, ada kesalahan : \n'+pesan);
            return false;
        }
    return true
    }
</script>
</body>
</html>
