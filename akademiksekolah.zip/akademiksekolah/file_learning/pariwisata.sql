-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 21, 2016 at 02:59 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pariwisata`
--

-- --------------------------------------------------------

--
-- Table structure for table `konsultasi`
--

CREATE TABLE IF NOT EXISTS `konsultasi` (
  `id_konsultasi` int(3) NOT NULL AUTO_INCREMENT,
  `judul_konsultasi` varchar(100) DEFAULT NULL,
  `isi_konsultasi` text,
  PRIMARY KEY (`id_konsultasi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `konsultasi`
--

INSERT INTO `konsultasi` (`id_konsultasi`, `judul_konsultasi`, `isi_konsultasi`) VALUES
(1, 'Konsultasi Liburan Bersama Kami', 'Kami memberikan konsultasi untuk tujuan liburan anda. sebisa mungkin kami memberikan pelayanan yang memuaskan untuk member kami. silahkan datang ke kantor kami jika anda ingin melakukan konsultasi.');

-- --------------------------------------------------------

--
-- Table structure for table `paket_liburan`
--

CREATE TABLE IF NOT EXISTS `paket_liburan` (
  `id_paket` int(200) NOT NULL AUTO_INCREMENT,
  `tanggal_keberangkatan` date DEFAULT NULL,
  `tempat_liburan` varchar(100) DEFAULT NULL,
  `harga_paket` varchar(20) DEFAULT NULL,
  `keterangan_paket` text,
  PRIMARY KEY (`id_paket`),
  KEY `tempat_liburan` (`tempat_liburan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `paket_liburan`
--

INSERT INTO `paket_liburan` (`id_paket`, `tanggal_keberangkatan`, `tempat_liburan`, `harga_paket`, `keterangan_paket`) VALUES
(1, '2016-01-23', '4', '1000000', 'perjalanan dilaksanakan selama 3 hari.\r\nfasilitas yang di dapatkan adalah\r\n\r\nmakan sehari 3 kali\r\nsnorkling\r\npenginapan\r\n\r\nperjalanan di mulai dari bandar lampung.\r\n'),
(2, '2016-01-30', '2', '500000', 'perjalanan selama 2 hari mendapatkan fasilitas penginapan, perjalanan menggunakan perahu, makan sehari 3x dan snorkling.\r\nperjalanan di mulai dari bandar lampung.');

-- --------------------------------------------------------

--
-- Table structure for table `sponsor`
--

CREATE TABLE IF NOT EXISTS `sponsor` (
  `id_sponsor` int(3) NOT NULL AUTO_INCREMENT,
  `nama_sponsor` varchar(20) DEFAULT NULL,
  `gambar_sponsor` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_sponsor`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `sponsor`
--

INSERT INTO `sponsor` (`id_sponsor`, `nama_sponsor`, `gambar_sponsor`) VALUES
(1, NULL, 'images/sponsor.png'),
(2, NULL, 'images/sponsor.png'),
(3, NULL, 'images/sponsor.png'),
(4, NULL, 'images/sponsor.png'),
(5, NULL, 'images/sponsor.png'),
(6, NULL, 'images/sponsor.png');

-- --------------------------------------------------------

--
-- Table structure for table `user_admin`
--

CREATE TABLE IF NOT EXISTS `user_admin` (
  `id_admin` int(1) NOT NULL AUTO_INCREMENT,
  `nama_admin` varchar(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `user_admin`
--

INSERT INTO `user_admin` (`id_admin`, `nama_admin`, `username`, `password`) VALUES
(4, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `wisata`
--

CREATE TABLE IF NOT EXISTS `wisata` (
  `id_wisata` int(200) NOT NULL AUTO_INCREMENT,
  `tempat_wisata` varchar(100) DEFAULT NULL,
  `keterangan` text,
  `gambar` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_wisata`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `wisata`
--

INSERT INTO `wisata` (`id_wisata`, `tempat_wisata`, `keterangan`, `gambar`) VALUES
(1, 'Gigi Hiu', 'ini adalah contoh saja silahkan anda browsing sendiri untuk mendapatkan informasi', 'images/destination_1.jpg'),
(2, 'Pulau Pahawang', 'ini adalah contoh saja silahkan anda browsing sendiri untuk mendapatkan informasi', 'images/destination_2.jpg'),
(3, 'Pantai Mutun', 'ini adalah contoh saja silahkan anda browsing sendiri untuk mendapatkan informasi', 'images/destination_3.jpg'),
(4, 'Teluk Kiluan', 'ini adalah contoh saja silahkan anda browsing sendiri untuk mendapatkan informasi', 'images/destination_4.jpg'),
(5, 'Pulau Pisang', 'ini adalah contoh saja silahkan anda browsing sendiri untuk mendapatkan informasi', 'images/destination_5.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
