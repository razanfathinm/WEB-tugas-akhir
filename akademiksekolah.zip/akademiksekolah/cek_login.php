<?php
error_reporting(0);
include "config/koneksi.php";

function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['id_user']);
$pass     = anti_injection($_POST['password']);
$level 	  =$_POST['level'];

if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  echo "<script>window.alert('Binggo!!!!!');
        window.location=('login.html')</script>";

}if ($level=='admin'){
$login=mysql_query("SELECT * FROM user
			WHERE username='$username' AND password='$pass' AND level='$level'");
$cocok=mysql_num_rows($login);
$r=mysql_fetch_array($login);

if ($cocok > 0){
	session_start();
	$_SESSION[user]     	= $r[username];
  	$_SESSION[namauser]     = $r[nama_lengkap];
  	$_SESSION[passuser]     = $r[password];
  	$_SESSION[leveluser]    = $r[level];

  	header('location:system/home');
} else {
echo "<script>window.alert('Username atau Password anda salah.');
        window.location=('login.html')</script>";
}

}elseif ($level=='guru'){
$login=mysql_query("SELECT * FROM karyawan
			WHERE nip='$username' AND pass_karyawan='$pass' AND status='guru'");
$cocok=mysql_num_rows($login);
$r=mysql_fetch_array($login);

if ($cocok > 0){
	session_start();
  	$_SESSION[id]  			= $r[id_karyawan];
  	$_SESSION[nip]  		= $r[nip];
	$_SESSION[passuser]     = $r[pass_karyawan];
	$_SESSION[namauser]     = $r[nm_karyawan];
  	$_SESSION[leveluser]    = $r[status];

	header('location:system/home');
}else {
echo "<script>window.alert('Username dan Password anda salah atau account anda belum di aktifkan.');
        window.location=('login.html')</script>";
}

}elseif ($level=='tu'){
$login=mysql_query("SELECT * FROM karyawan
			WHERE nip='$username' AND pass_karyawan='$pass' AND status='tu'");
$cocok=mysql_num_rows($login);
$r=mysql_fetch_array($login);

if ($cocok > 0){
	session_start();
  	$_SESSION[id]  			= $r[id_karyawan];
  	$_SESSION[nip]  		= $r[nip];
	$_SESSION[passuser]     = $r[pass_karyawan];
	$_SESSION[namauser]     = $r[nm_karyawan];
  	$_SESSION[leveluser]    = $r[status];

	header('location:system/home');
}else {
echo "<script>window.alert('Username dan Password anda salah atau account anda belum di aktifkan.');
        window.location=('login.html')</script>";
}

}elseif ($level=='siswa'){
$login=mysql_query("SELECT * FROM siswa
			WHERE nisn_siswa='$username' AND pass_siswa='$pass' AND status_siswa='aktif'");
$cocok=mysql_num_rows($login);
$r=mysql_fetch_array($login);

if ($cocok > 0){
	session_start();
  	$_SESSION[id]  			= $r[id_siswa];
  	$_SESSION[nisn]  		= $r[nisn_siswa];
	$_SESSION[passuser]     = $r[pass_siswa];
	$_SESSION[namauser]     = $r[nm_siswa];
  	$_SESSION[leveluser]    = $r[status_siswa];

	header('location:system/home');
}else {
echo "<script>window.alert('Username dan Password anda salah atau account anda belum di aktifkan.');
        window.location=('login.html')</script>";
}

}
?>