-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2017 at 04:12 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_akademik`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE IF NOT EXISTS `alumni` (
  `id_alumni` int(10) NOT NULL,
  `nisn_alumni` varchar(10) NOT NULL,
  `nm_alumni` varchar(30) NOT NULL,
  `foto_alumni` varchar(250) DEFAULT NULL,
  `kelamin_alumni` char(1) DEFAULT NULL,
  `email_alumni` varchar(100) DEFAULT NULL,
  `no_telp_alumni` varchar(13) DEFAULT NULL,
  `tmplhr_alumni` varchar(50) DEFAULT NULL,
  `tgllhr_alumni` date DEFAULT NULL,
  `agama_alumni` varchar(20) DEFAULT NULL,
  `alamat_alumni` text,
  `status_alumni` varchar(50) DEFAULT NULL,
  `keterangan_alumni` text
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`id_alumni`, `nisn_alumni`, `nm_alumni`, `foto_alumni`, `kelamin_alumni`, `email_alumni`, `no_telp_alumni`, `tmplhr_alumni`, `tgllhr_alumni`, `agama_alumni`, `alamat_alumni`, `status_alumni`, `keterangan_alumni`) VALUES
(32, '3456345634', 'asdfasdasdg', NULL, 'L', 'adisus10@gmail.com', '453452345', '', '1900-01-01', '0', '', '0', ''),
(33, '3456345643', 'sdghsd', NULL, 'L', 'adisus10@gmail.com', '56745656', '', '1900-01-01', '0', 'asfga', '0', '');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
  `id_berita` int(5) NOT NULL,
  `id_kategori` int(5) NOT NULL,
  `jdl_berita` varchar(50) NOT NULL,
  `penulis` varchar(30) DEFAULT NULL,
  `tgl_berita` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `foto_berita` varchar(250) NOT NULL,
  `isi_berita` text
) ENGINE=MyISAM AUTO_INCREMENT=11159 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id_berita`, `id_kategori`, `jdl_berita`, `penulis`, `tgl_berita`, `foto_berita`, `isi_berita`) VALUES
(11153, 11129, 'Marching Band', 'admin345', '2017-01-21 23:18:46', 'KJIKJI.jpg', 'Dimulai pada tanggal 02 Mei awal perdana SMKN2 Tebo menampilkan marching band . 2mei? Iya hari pendidikan adalah hari dimana team GPM.DRUM COORPS SMKN2 TEBO baru saja launching pertama kali,melatih mental tampil sederhana mungkin dan seadanya mungkin karena team kami baru saja dibentuk tanggal 15 Febuari 2016 dan 3bulan setelah menjalankan latihan setiap hari rabu dan sabtu kami harus tampil di hari pendidikan.\r\n\r\nTanggal 17 Agustus? Kami hanya bisa menguji mental kami di penurunan bendera , Tanggal 18 Agustus? Kami mencoba uji mental di Kabupaten Tebo, tampil pertama kali di depan bupati beserta ibu, memakai costum baru,menunjukan inilah team baru kami, inilah team kami yang ada di SMKN2 Kab.Tebo\r\n\r\n20 agustus? Kami mengikuti pawai di Rimbo Bujang,memakai costum baru,dan berusaha tampil semaksimal mungkin dan sebagus mungkin,hanya 1 pikiran kami di team "TIDAK AKAN BIKIN MALU NAMA SEKOLAH"\r\n\r\n Pada acara karnaval memperingati hari kemerdekaan tepat nya pada tanggal 20 Agustus 2016 SMKN 2 TEBO  berhasil merebutkan juara pertama tingkat kecamatan . tentu saja itu membuat Kami dan  semua masyarakat yang ada di SMKN 2 TEBOmerasa bangga. Semangat terusss... '),
(11152, 11130, 'Ayo Magang Ke Jepang!', 'admin', '2017-01-21 23:03:04', 'camera.png', ' Magang Jepang adalah suatu program belajar sambil praktek kerja yang di lakukan bagi para lulusan SMK sederajat di Negara  Jepang. Program ini dilaksanakan oleh kerjasama antara Pemerintah Republik Indonesia dengan Pemerintah Jepang yang disebut dengan Program IM JAPAN  yang di selenggarakan oleh Disosnakertrans  propinsi di seluruh Indonesia. Program pemagangan ini pun dilaksanakan oleh Perusahaan-perusahaan dan atau LPK (Lembaga Pelatihan Kerja) swasta yang sudah mendapatkan izin dari Kementerian RI Bidang Lattas Pemagangan, dalam hal ini LPK KANTANNA SAKURA yang personil  kepengurusannya  adalah alumni Japan dan beberapa pendidik di SMK N 2 Kab.Tebo Siap memberangkatkan para alumnus SMK  untuk ikut magang. Perusahaan ataupun  LPK yang bisa mengirimkan Pemagang Ke Jepang biasa di sebut dengan Sending Organization (SO). Dan di Indonesia ini selain Dinsosnakertrans RI ada juga sekitar 92 Sending Organization (SO) yang bisa mendidik dan mengirimkan  anda ke Jepang Sebagai Pemagang (Trainee) \r\n\r\nPERSYARATAN  DAN PROSEDUR PROGRAM MAGANG JEPANG\r\n\r\nâ€¢ PERSYARATAN UMUM CALON TRAINEE JAPAN\r\n\r\n1. USIA ANTARA 19-27 TAHUN,\r\n\r\nUsia produktif menurut perusahaan jepang adalah antara 20-27 tahun, akan tetapi kesempatan untuk ke jepang sudah bisa di raih dari umur 18 tahun, dan bagi umur 30 tahun ke atas pada dasarnya masih ada kesempatan untuk magang ke jepang,  tetapi  mungkin agak kecil kesempatan tersebut, karena sebagian besar perusahaan jepang biasanya lebih cenderung mengambil yang usianya masih muda. Maka bagi teman-teman yang merasa usianya masih produktif alangkah baiknya tidak menyia-nyiakan kesempatan yang ada. Dan bagi yang usianya lebih pun tetap ada kesempatan.\r\n\r\n2. FISIK JASMANI/KESEMAPTAAN/KESEHATAN\r\n\r\nUntuk mengikuti program magang ke Jepang , fisik yang sempurna adalah syarat mutlak yang harus di miliki oleh calon pemagang. Badan anda adalah aset yang sangat besar yang bisa membuat anda mendapatkan hasil yang cukup besar. Maka jagalah dan sayangilah badan anda yang bagus dan sempurna itu. Jangan sampai karena kecerobohan-kecerobohan yang di lakukan membuat anda merusak fisik anda menjadi cacat yang akhirnya akan menjadikan penyesalan yang tiada arti. Masa muda memang terkadang adalah masa yang labil, dimana di situ faktor lingkungan menjadi penentu sikap anda, maka pandai-pandailah menyikapi keadaan sehingga dalam lingkungan seperti apapun anda harus menjadi yang terbaik dan bisa menjaga diri.\r\n\r\nContoh kecilnya adalah : tatto dan tindik..\r\n\r\nKarena Dalam syarat menjadi pemagang Jepang tatto dan tindik tidaklah di perbolehkan, maka sayangilah badan anda,,,Selanjutnya di samping fisik yang kuat dan sempurna, yang tidak kalah pentingnya adalah kesehatan. Dalam program magang  jepang tidak mungkin mau menerima orang yang sakit baik jasmani maupun rohani, terutama adalah penyakit yang menular.  Karena dalam program ini di bagian medical cek up nya akan sangat teliti. Jadi sebisa mungkin jagalah kesehatan anda. Janganlah mengkonsumsi makanan atau minuman atau obat-obatan yang anda sendiri sudah tau kalau itu tidak baik dan malah akan merusak. Bahkan akan menimbulkan penyakit, contoh seperti narkoba, minuman keras dll. Jadi intinya, sayangilah diri anda untuk menggapai masa depan yang cerahâ€¦\r\n\r\n \r\n\r\n3. DOKUMEN PRIBADI HARUS LENGKAP\r\n\r\nâ€¢ Ijazah Minimal SMK Sederajat/Kejar Paket C\r\n\r\nâ€¢ Dokumen pribadi seperti KTP, KK, AKTE, IJAZAH dan dokumen yang lain harus sama dalam penulisan Nama, Tanggal Lahir, Dan Tempat Lahir. Tidak boleh ada perbedaan baik huruf atau pun angka di dalam dokumen tersebut, karena dokumen tersebut adalah dasar yang di pakai untuk pengurusan Pasport, Visa, Dan Dokument Yang Lain untuk syarat ke Jepang. Jadi harus benar-benar fix dan tidak boleh ada kesalahan. Maka bagi temen-teman yang ingin magang ke Jepang, dari sekarang silahkan cek seluruh Dokumen pribadi anda dan pastikan  semua singkron dan tidak ada kesalahan.\r\n\r\nâ€¢ PROSEDUR UMUM MAGANG KE JEPANG\r\n\r\n1. SELEKSI AWAL MELIPUTI  :\r\n\r\nâ€¢ Seleksi Administrasi (Dokument Pribadi)\r\n\r\nSetelah mendaftarkan diri , yang pertama di perhatikan adalah kelengkapan dokument pribadi  anda seperti yg telah di jelaskan di atas, semua dokumen  pribadi anda harus lengkap dan singkron satu sama lain, seperti KTP, KK, AKTE, IJAZAH dll.\r\n\r\nâ€¢  Pemeriksaan Kesemaptaan Tubuh\r\n\r\nMeliputi pemeriksaan FISIK yang meliputi Tinggi Badan, Berat Badan, Cacat Tubuh, Fungsi Organ Tubuh. Di sinilah anda akan merasa bahwa tubuh anda adalah aset yang sangat berharga, maka sayangilah dan peliharalah dengan baik.\r\n\r\nâ€¢ Test Bahasa Jepang Dasar\r\n\r\nDi sinilah fungsi LPK KANTANNA SAKURA akan terasa karena untuk mengikuti seleksi Program Magang Jepang  paling tidak siswa harus sudah mengetahui dasar dari bahasa jepang dan kebudayaan jepang.\r\n\r\nâ€¢ Test Psiko Dan Matematika\r\n\r\nTugas LPK KANTANNA SAKURA bukan hanya mengajari bahasa jepang saja tapi termasuk semua hal yang berkaitan dengan Program Magang Jepang , dan di LPK KANTANNA SAKURA yang ada di SMKN 2 Tebo semua di ajarkan termasuk psikotest dan matematika.\r\n\r\nâ€¢ Wawancara Dengan User Dari Jepang\r\n\r\nNah.. seleksi yang ini lumayan harus memerlukan persiapan yang prima untuk menghadapinya, karena di sini bisa jadi adalah penentu keberhasilan anda. Pihak perusahaan penerima dari jepang akan langsung memilih anda sebagai pemagang di Perusahaanya,  oleh karena itu anda harus benar-benar maksimal di hadapan mereka. Dan itupun akan kita latih selama di LPK supaya tidak terlalu nerves dalam melaksanakan seleksi di tahap ini.  Semangatâ€¦.\r\n\r\nâ€¢ Kesehatan (Medical Ceck Up)\r\n\r\nIni adalah test terakhir dan penentu keberhasilan anda, mau sebagus apapun hasil test sebelumnya,  kalau di medicalnya jelek pasti akan gagal, karena tidak mungkin pihak perusahaan pengirim(sending organisasi) akan mengirimkan orang yang sakit untuk sampai ke Jepang. Karena sangat beresiko, maka jagalah kesehatan anda dari sekarangâ€¦\r\n\r\nContok penyakit yang sulit untuk di tolerir biasanya penyakit yang menular seperti : Hepatitis, tbc, aids dan penyakit menular yang lainâ€¦.\r\n\r\n2. MASA PENDIDIKAN PRA PEMBERANGKATAN KE JEPANG\r\n\r\nSetelah semua seleksi terlewati dan hasilnya adalah ok/lolos.., maka tahap berikutnya ada masa pendidikan pra-pemberangkatan di daerah (untuk program IM JAPAN) ataupun di Perusahaan Pengirim ke Jepang (sending organisasi). Di sini adalah masa pemantapan bahasa Jepang dan sikap anda. Jadi jangan senang dulu setelah lolos seleksi awal, karena di masa ini kemampuan anda benar-benar di pertaruhkan. Dan sikap anda juga benar-benar di perhatikan. Kalau di masa ini anda tidak  bisa mengikuti pendidikan bahasa Jepang dengan baik ataupun sikap anda di anggap jelek maka konsekwensinya adalah bisa di cancel  ataupun di pulangkan kembali ke tahap awal. Maka harus tetap hati-hati dan semangat dalam belajar dan harus menjaga sikap sebaik mungkin dan meminimalisasi kesalahan .\r\n\r\n3. TERBANG KE JEPANG\r\n\r\nInilah masa yang paling indah dan masa paling di tunggu tentunya â€œterbang ke negeri sakuraâ€, wah.. semua calon pemagang jepang pasti mendambakan masa ini ya..  Tapi ingat, jangan senang dulu. di sini adalah babak awal  anda untuk meraih masa depan yang bagus, tetapi di balik itu ternyata anda punya tanggung jawab yang sangat besar di sini, yaitu untuk menjaga nama baik lembaga yang mendidik anda, perusahaan yang memberangkatkan anda dan tentunya menjaga nama baik negara tercinta kita ini. Maka tetaplah santun dan jaga ketenangan ya..  tunjukkan bahwa negara kita adalah negara yang santun dan berwibawaâ€¦ semangat. Ganbatte minna san.....(SÎ²) '),
(11150, 11127, 'Diklat Moda Daring Online', 'admin345', '2017-01-21 23:15:36', 'diklat.png', 'Berdasarkan hasil rapat koordinasi dengan Dinas Pendidikan Bidang PPTK hari Kamis, 25 Agustus 2016 perihal Guru Pembelajar, berkaitan dengan hal tersebut maka kami beritahukan sebagai berikut :\r\n \r\n1. Kepada para Guru yang Nilai Merah 1 â€“ 5 mengikuti Diklat Moda Daring (Online ), Nilai Merah 6 â€“ 7 mengikuti Diklat Model Campuran (Moda Daring dan Tatap Muka ).\r\n3. Berkenaan dengan ini maka masing-masing guru untuk mempersiapkan diri dengan berlatih TIK ( Teknologi\r\n4. Informasi Komputer ) dan Mempersiapkan perangkat TIK yaitu PC/Laptop yang ada web camnya, atau Smart Phone Android/ios (front Camera) yang bisa digunakan untuk model streaming atau video call serta jaringan pendukungnya.\r\n5. Diklat ini rencananya di laksanakan tanggal 7 September 2016.\r\n6. Jadwal akan tertera pada akun GPO nya masing-masing PTK atau Guru setelah login (belum punya akun? silahkan klik disini untuk membuat akun GP).\r\n7. Mengingat waktu yang sudah mendesak mohon setiap PTK untuk segera berlatih login akunnya masing-masing dan pastikan setiap PTK sudah memegang akun GPO nya sendiri-sendiri apabila belum memiliki akun segera menghubungi koordinator Gugusnya masing-masing. Bila Koordinator Gugus/KKG mengalami kesulitan bisa konsultasi langsung ke UPTD.\r\n8. Kepada Guru yang Nilainya Merah 8-10 akan mengikuti diklat Tatap Muka penuh (jadwal menyusul) '),
(11151, 11127, 'Gebyar TIK 2016', 'admin345', '2017-01-21 23:01:15', 'Gebyar TIK 2016.jpg', 'Gebyar TIK diselenggarakan sebagai bentuk apresiasi dan penghargaan kepada Sekolah dan Guru SD/MI, SMP/MTs, SMA/MA/SMK yang berdedikasi memajukan pendidikan di Kabupaten Tebo pada khususnya dan di Provinsi Jambi pada umumnya dengan mengembangkan dan memanfaatkan TIK untuk pendidikan pada pendidikan dasar dan menengah. Adapun gelar Gebyar TIK yang pada puncak final di selenggarakan di Provinsi Jambi mulai pada tanggal 5 s.d. 8 September 2016 ini bertujuan untuk mengaplikasikan Teknologi TIK dalam bidang Pendidikan, wadah kreatifitas dan unjuk potensi TIK Guru/Sekolah se-Provinsi Jambi, mendorong dan meningkatkan pengembangan dan pemanfaatan TIK di Sekolah, serta menumbuhkan kesadaran pendayagunaan teknologi yang tepat-guna.\r\n\r\nUntuk seleksi calon peserta lomba ini diselenggarakan di Dinas Dikbudpora Kabupaten Tebo yang mana akan dipilih 17 (tujuh belas) orang yang terdiri dari guru dan peserta didik terbaik yang akan dikirimkan untuk mengikuti final Gebyar TIK Jambi tahun 2016 yang terbagi dalam beberapa kategori lomba sebagai berikut:\r\n1. Blog Guru Guru SD-SMA (1 peserta)\r\n2. Blog Siswa Siswa SMA Sederajat (1 peserta)\r\n3. Media Animasi Guru SD-SMA (1 peserta)\r\n4.  Media Presentasi Guru SD-SMA (1 peserta)\r\n5. Media Video Guru SD-SMA (1 peserta)\r\n6. Media Mobile Edukasi Guru SD-SMA (1 peserta)\r\n7. Web SD SD (1 peserta)\r\n8. Web SMP SMP (1 peserta)\r\n9. Web SMA SMA (1 peserta)\r\n10. Kuis Kihajar SD Siswa SD Sederajat (1 peserta)\r\n11. Kuis Kihajar SMP Siswa SMP / Sederajat (1 peserta)\r\n12. Kuis Kihajar SMA Siswa SMA / Sederajat (1 peserta)\r\n13. Film Pendek Guru Guru SD-SMA (2 peserta dalam 1 kelompok)\r\n14. Film Pendek Siswa Siswa SMA / Sederajat (2 peserta dalam 1 kelompok)\r\n15. Seminar - Guru TIK SMA/SMK (1 peserta)\r\n \r\nUntuk download surat edaran Dinas Dikbudpora Tebo serta formulir pendaftaran danpetunjuk teknis seleksi Gebyar TIK Kabupaten Tebo Tahun 2016 dapat diunduh pada Menu E-Learning. Formulir pendaftaran yang telah diisi lengkap dan telah ditandatangani oleh Kepala Sekolah serta bahan lomba disampaikan kepada Panitia Seleksi Gebyar TIK Kabupaten Tebo Tahun 2016, Bidang Dikmen Dinas Dikbudpora Tebo (Bpk. Guruh Puji Raharjo, S.Pd) diterima paling lambat sampai dengan hari Kamis, 31 Agustus 2016. Demikian informasi yang kami sampaikan atas perhatiannya diucapkan terimakasih.');

-- --------------------------------------------------------

--
-- Table structure for table `detail_kelas`
--

CREATE TABLE IF NOT EXISTS `detail_kelas` (
  `id_kelas` int(5) DEFAULT NULL,
  `id_siswa` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_kelas`
--

INSERT INTO `detail_kelas` (`id_kelas`, `id_siswa`) VALUES
(5, 12);

-- --------------------------------------------------------

--
-- Table structure for table `detail_mapel`
--

CREATE TABLE IF NOT EXISTS `detail_mapel` (
  `id_karyawan` int(5) DEFAULT NULL,
  `id_mapel` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_mapel`
--

INSERT INTO `detail_mapel` (`id_karyawan`, `id_mapel`) VALUES
(8, 11),
(9, 16);

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE IF NOT EXISTS `jadwal` (
  `id_jadwal` int(5) NOT NULL,
  `id_karyawan` int(5) DEFAULT NULL,
  `id_kelas` int(5) DEFAULT NULL,
  `id_mapel` int(5) DEFAULT NULL,
  `hari` varchar(20) DEFAULT NULL,
  `jam` varchar(30) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id_jadwal`, `id_karyawan`, `id_kelas`, `id_mapel`, `hari`, `jam`) VALUES
(39, 8, 6, 11, 'Selasa', '07:00 - 08:00 '),
(40, 8, 6, 18, 'Rabu', '07:00 - 08:00 '),
(41, 9, 6, 16, 'Kamis', '11:05 - 13:05 ');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE IF NOT EXISTS `jurusan` (
  `id_jurusan` int(5) NOT NULL,
  `nm_jurusan` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id_jurusan`, `nm_jurusan`) VALUES
(2, 'Multimedia'),
(3, 'Akutansi'),
(6, 'Administrasi Perkantoran'),
(7, 'Teknik Mesin'),
(8, 'Teknik Sepeda Motor'),
(9, 'Teknik Kendaraan Ringan');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `id_karyawan` int(5) NOT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `nm_karyawan` varchar(30) DEFAULT NULL,
  `foto_karyawan` varchar(250) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `jabatan` varchar(150) NOT NULL,
  `email_karyawan` varchar(100) DEFAULT NULL,
  `no_telp_karyawan` varchar(13) DEFAULT NULL,
  `agama_karyawan` varchar(30) DEFAULT NULL,
  `pend_karyawan` varchar(100) DEFAULT NULL,
  `jenis_kel_karyawan` char(1) DEFAULT NULL,
  `tmp_lhr_karyawan` varchar(50) DEFAULT NULL,
  `tgl_lhr_karyawan` date DEFAULT NULL,
  `alamat_karyawan` text,
  `pass_karyawan` varchar(8) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nip`, `nm_karyawan`, `foto_karyawan`, `status`, `jabatan`, `email_karyawan`, `no_telp_karyawan`, `agama_karyawan`, `pend_karyawan`, `jenis_kel_karyawan`, `tmp_lhr_karyawan`, `tgl_lhr_karyawan`, `alamat_karyawan`, `pass_karyawan`) VALUES
(8, '31246235757342354215', 'Jhon Susanto', 'adi.jpg', 'guru', 'Wali Kelas', 'adisus10@gmail.com', '082372394930', 'Islam', 'S1 Teknik Matematika', 'L', 'Medan', '1990-10-17', 'Condongcatur medan surakarta', 'dadanice'),
(9, '34563456456345643564', 'Santoso', 'dokter-1.jpg', 'guru', 'Guru Biasa', 'ari@gmail.com', '0831243255', 'Islam', '', 'P', '', '1900-01-01', '', '45643564'),
(10, '67854673456234513123', 'Tuti Ira Wati', NULL, 'tu', '', 'tuti@ymail.com', '081232', '0', '', 'P', '', '1900-01-01', '', '34513123');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(5) NOT NULL,
  `nm_kategori` varchar(30) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11136 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nm_kategori`) VALUES
(11127, 'berita'),
(11128, 'jurusan'),
(11129, 'kegiatan'),
(11130, 'info sekolah');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE IF NOT EXISTS `kelas` (
  `id_kelas` int(5) NOT NULL,
  `nm_kelas` varchar(50) NOT NULL,
  `id_jurusan` int(5) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nm_kelas`, `id_jurusan`) VALUES
(5, 'X Akutansi 1', 3),
(6, 'X Multimedia 2', 2),
(7, 'X Akutansi 2', 3),
(11, 'XI Akutansi 1', 3),
(12, 'XII Akutansi 1', 3);

-- --------------------------------------------------------

--
-- Table structure for table `khs`
--

CREATE TABLE IF NOT EXISTS `khs` (
  `id_khs` int(10) NOT NULL,
  `id_mapel` int(5) DEFAULT NULL,
  `id_jurusan` int(5) DEFAULT NULL,
  `id_siswa` int(10) DEFAULT NULL,
  `id_kelas` int(5) DEFAULT NULL,
  `semester` varchar(10) DEFAULT NULL,
  `thn_ajaran` varchar(10) DEFAULT NULL,
  `nilai` varchar(3) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `khs`
--

INSERT INTO `khs` (`id_khs`, `id_mapel`, `id_jurusan`, `id_siswa`, `id_kelas`, `semester`, `thn_ajaran`, `nilai`) VALUES
(8, 11, 3, 12, 5, 'genap', '2011-2012', '89'),
(9, 15, 3, 12, 5, 'genap', '2011-2012', '80');

-- --------------------------------------------------------

--
-- Table structure for table `learning`
--

CREATE TABLE IF NOT EXISTS `learning` (
  `id_learning` int(10) NOT NULL,
  `nm_learning` varchar(50) DEFAULT NULL,
  `file_learning` varchar(250) DEFAULT NULL,
  `id_karyawan` int(5) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `learning`
--

INSERT INTO `learning` (`id_learning`, `nm_learning`, `file_learning`, `id_karyawan`) VALUES
(3, 'bahasa itu indah', 'krs.pdf', 8),
(4, 'Corel Draw Itu Keren', 'aji scan.pdf', 8);

-- --------------------------------------------------------

--
-- Table structure for table `mapel`
--

CREATE TABLE IF NOT EXISTS `mapel` (
  `id_mapel` int(5) NOT NULL,
  `nm_mapel` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mapel`
--

INSERT INTO `mapel` (`id_mapel`, `nm_mapel`) VALUES
(11, 'Matematika'),
(15, 'Bahasa Indonesia'),
(16, 'Design Grafis'),
(17, 'IPS'),
(18, 'Bahasa Inggris'),
(22, 'IPA');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `id_siswa` int(10) NOT NULL,
  `nisn_siswa` varchar(10) DEFAULT NULL,
  `nm_siswa` varchar(30) DEFAULT NULL,
  `foto_siswa` varchar(250) NOT NULL,
  `jenis_kelamin` char(1) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `tempat_lhr` varchar(50) DEFAULT NULL,
  `agama` varchar(20) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `hobby` varchar(30) DEFAULT NULL,
  `ket_hobi` text NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `alamat` text,
  `transportasi` varchar(30) DEFAULT NULL,
  `gol_darah` char(1) DEFAULT NULL,
  `tinggi` int(3) DEFAULT NULL,
  `berat` int(3) DEFAULT NULL,
  `anak_ke` char(2) DEFAULT NULL,
  `nm_ayah` varchar(30) DEFAULT NULL,
  `tgl_lhr_ayah` date DEFAULT NULL,
  `tmp_lhr_ayah` varchar(20) NOT NULL,
  `agama_ayah` varchar(20) DEFAULT NULL,
  `pendidikan_ayah` varchar(50) DEFAULT NULL,
  `pekerjaan_ayah` varchar(50) DEFAULT NULL,
  `penghasilan_ayah` varchar(20) DEFAULT NULL,
  `alamat_ayah` text,
  `status_hidup_ayah` varchar(20) DEFAULT NULL,
  `no_telp_ayah` varchar(13) DEFAULT NULL,
  `nm_ibu` varchar(30) DEFAULT NULL,
  `tgl_lhr_ibu` date DEFAULT NULL,
  `tmp_lhr_ibu` varchar(50) DEFAULT NULL,
  `agama_ibu` varchar(20) DEFAULT NULL,
  `pendidikan_ibu` varchar(50) DEFAULT NULL,
  `pekerjaan_ibu` varchar(50) DEFAULT NULL,
  `penghasilan_ibu` varchar(20) DEFAULT NULL,
  `alamat_ibu` text NOT NULL,
  `nm_wali` varchar(30) DEFAULT NULL,
  `tgl_lhr_wali` date DEFAULT NULL,
  `tmp_lhr_wali` varchar(100) DEFAULT NULL,
  `agama_wali` varchar(20) DEFAULT NULL,
  `pendidikan_wali` varchar(50) DEFAULT NULL,
  `pekerjaan_wali` varchar(50) DEFAULT NULL,
  `penghasilan_wali` varchar(20) DEFAULT NULL,
  `alamat_wali` text,
  `no_telp_wali` varchar(13) DEFAULT NULL,
  `pass_siswa` varchar(8) NOT NULL,
  `status_siswa` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nisn_siswa`, `nm_siswa`, `foto_siswa`, `jenis_kelamin`, `tgl_lahir`, `tempat_lhr`, `agama`, `no_telp`, `hobby`, `ket_hobi`, `email`, `alamat`, `transportasi`, `gol_darah`, `tinggi`, `berat`, `anak_ke`, `nm_ayah`, `tgl_lhr_ayah`, `tmp_lhr_ayah`, `agama_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `alamat_ayah`, `status_hidup_ayah`, `no_telp_ayah`, `nm_ibu`, `tgl_lhr_ibu`, `tmp_lhr_ibu`, `agama_ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `alamat_ibu`, `nm_wali`, `tgl_lhr_wali`, `tmp_lhr_wali`, `agama_wali`, `pendidikan_wali`, `pekerjaan_wali`, `penghasilan_wali`, `alamat_wali`, `no_telp_wali`, `pass_siswa`, `status_siswa`) VALUES
(12, '3456673567', 'Adi Susanto', 'adi.jpg', 'L', '1997-01-01', 'dhjdf', 'Islam', '3462', 'Kesenian', 'sdgfsd', 'adisus10@gmail.com', 'sdhsdhdf', 'sdfhg', 'A', 123, 23, '3', 'dfshsd', '2002-02-07', 'sdfh', 'Islam', 'sarjanbna', 'asfg', '2333', 'sdfhsdf', 'Hidup', '3454', '', '0000-00-00', '', '', '', '', '', '', 'sdfsdfg', '2001-02-01', 'asdfas', 'Islam', 'sarjana', 'asfga', '4354', 'dsfhgsdg', '234523', 'dada345', 'aktif'),
(31, '1111111111', 'Ridwan Mas', 'dokter.jpg', 'P', '1998-11-11', 'Medan', 'Islam', '081231231321', 'Kesenian', 'Tari Jaipong', 'adisus10@gmail.com', 'Masjid Rumahan', 'Mobil Merci', 'O', 156, 157, '2', 'Mas Aji', '1991-03-07', 'Jawa Tengah', '0', 'S1 Tehnik Pertambangan', 'Tani', '100000', 'Medan', 'Meninggal', '0812323', '', '0000-00-00', '', '0', '', '', '', '', '', '0000-00-00', '', '0', '', '', '', '', '', 'Ri111111', 'aktif');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `nama_lengkap` varchar(20) NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `nama_lengkap`, `password`, `level`) VALUES
(1, 'admin', 'Administrator', 'dada123', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`id_alumni`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id_berita`), ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `detail_kelas`
--
ALTER TABLE `detail_kelas`
  ADD KEY `id_kelas` (`id_kelas`), ADD KEY `id_siswa` (`id_siswa`);

--
-- Indexes for table `detail_mapel`
--
ALTER TABLE `detail_mapel`
  ADD KEY `id_karyawan` (`id_karyawan`), ADD KEY `id_mapel` (`id_mapel`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id_jadwal`), ADD KEY `id_karyawan` (`id_karyawan`), ADD KEY `id_kelas` (`id_kelas`), ADD KEY `id_mapel` (`id_mapel`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`), ADD KEY `id_jurusan` (`id_jurusan`);

--
-- Indexes for table `khs`
--
ALTER TABLE `khs`
  ADD PRIMARY KEY (`id_khs`), ADD KEY `id_mapel` (`id_mapel`), ADD KEY `id_jurusan` (`id_jurusan`), ADD KEY `id_siswa` (`id_siswa`), ADD KEY `id_kelas` (`id_kelas`);

--
-- Indexes for table `learning`
--
ALTER TABLE `learning`
  ADD PRIMARY KEY (`id_learning`), ADD KEY `id_karyawan` (`id_karyawan`);

--
-- Indexes for table `mapel`
--
ALTER TABLE `mapel`
  ADD PRIMARY KEY (`id_mapel`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alumni`
--
ALTER TABLE `alumni`
  MODIFY `id_alumni` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id_berita` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11159;
--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id_jadwal` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id_jurusan` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id_karyawan` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11136;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `khs`
--
ALTER TABLE `khs`
  MODIFY `id_khs` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `learning`
--
ALTER TABLE `learning`
  MODIFY `id_learning` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `mapel`
--
ALTER TABLE `mapel`
  MODIFY `id_mapel` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_kelas`
--
ALTER TABLE `detail_kelas`
ADD CONSTRAINT `detail_kelas_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `detail_kelas_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `detail_mapel`
--
ALTER TABLE `detail_mapel`
ADD CONSTRAINT `detail_mapel_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `detail_mapel_ibfk_2` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jadwal`
--
ALTER TABLE `jadwal`
ADD CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `jadwal_ibfk_2` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `jadwal_ibfk_3` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kelas`
--
ALTER TABLE `kelas`
ADD CONSTRAINT `kelas_ibfk_1` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`) ON DELETE CASCADE;

--
-- Constraints for table `khs`
--
ALTER TABLE `khs`
ADD CONSTRAINT `khs_ibfk_1` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `khs_ibfk_2` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `khs_ibfk_3` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `khs_ibfk_4` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `learning`
--
ALTER TABLE `learning`
ADD CONSTRAINT `learning_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
